<?php
/**
|--------------------------------------------------------------------------
| endpoint تنظیمات نمایش کارت‌ها (راند ۲۰)
|--------------------------------------------------------------------------
| GET  ?action=get  → تعاریف + تنظیمات فعلی
| POST ?action=save → ذخیرهٔ تنظیمات {settings:{key:mode|bool}}
|--------------------------------------------------------------------------
*/

require_once __DIR__ . '/admin-guard.php';
require_once __DIR__ . '/card-display.php';

melkinoRequireAdminJson();

$action = strtolower(trim((string)($_GET['action'] ?? '')));

if ($action === 'get') {
    melkinoAdminJson([
        'success'  => true,
        'defs'     => melkinoCardDisplayDefs(),
        'settings' => melkinoCardDisplaySettings(),
    ]);
}

if ($action === 'save') {
    $data = melkinoAdminJsonBody();
    $map = is_array($data['settings'] ?? null) ? $data['settings'] : [];
    $ok = melkinoSaveCardDisplay($map);
    melkinoAdminJson([
        'success' => $ok,
        'message' => $ok ? 'تنظیمات نمایش کارت‌ها ذخیره شد.' : 'ذخیره ناموفق بود.',
    ]);
}

melkinoAdminJson(['success' => false, 'message' => 'عمل نامعتبر'], 400);
