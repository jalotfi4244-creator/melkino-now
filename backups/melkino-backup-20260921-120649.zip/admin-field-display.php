<?php
/**
|--------------------------------------------------------------------------
| endpoint سیستم مدیریت فیلدهای نمایشی (راند ۲۹)
|--------------------------------------------------------------------------
| GET  ?action=get&target=home|details   → registry + تنظیمات + meta + نمونه‌ها
| POST ?action=save&target=…             → اعتبارسنجی + ذخیره (+تاریخچه)
| POST ?action=restore&target=…          → بازگردانی آخرین تنظیمات
| POST ?action=set_preview               → draft پیش‌نمایش در session ادمین
| POST ?action=clear_preview             → پاک کردن draft پیش‌نمایش
|
| امنیت: admin-guard (session ادمین) + CSRF روی همهٔ عمل‌های تغییردهنده.
|--------------------------------------------------------------------------
*/

require_once __DIR__ . '/admin-guard.php';
require_once __DIR__ . '/field-display.php';

melkinoRequireAdminJson();

$action = strtolower(trim((string)($_GET['action'] ?? '')));
$target = (string)($_GET['target'] ?? $_POST['target'] ?? 'home');
if (!in_array($target, ['home', 'details'], true)) {
    $target = 'home';
}

if ($action === 'get') {
    global $pdo;

    $samples = [];
    try {
        if ($pdo instanceof PDO) {
            $st = $pdo->query(
                "SELECT id, title, property_type, transaction_type
                 FROM ads
                 WHERE status = 'published'
                 ORDER BY created_at DESC
                 LIMIT 15"
            );
            foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $row) {
                $samples[] = [
                    'id'      => (string)$row['id'],
                    'title'   => (string)$row['title'],
                    'type'    => (string)($row['property_type'] ?? ''),
                    'tr'      => (string)($row['transaction_type'] ?? ''),
                ];
            }
        }
    } catch (Throwable $e) {
        // بدون نمونه هم پنل کار می‌کند
    }

    if ($target === 'details') {
        $settings = melkinoFdDetailsSettings();
        melkinoAdminJson([
            'success'  => true,
            'target'   => 'details',
            'defs'     => $settings['defs'],
            'config'   => $settings['config'],
            'meta'     => $settings['meta'],
            'samples'  => $samples,
            'has_history' => !empty(melkinoFdStored('details')['history']),
        ]);
    }

    $settings = melkinoFdHomeSettings();
    melkinoAdminJson([
        'success'  => true,
        'target'   => 'home',
        'defs'     => $settings['defs'],
        'fields'   => $settings['fields'],
        'meta'     => $settings['meta'],
        'samples'  => $samples,
        'has_history' => !empty(melkinoFdStored('home')['history']),
    ]);
}

if (in_array($action, ['save', 'restore', 'set_preview', 'clear_preview'], true)) {
    // همهٔ عمل‌های تغییردهنده: CSRF اجباری (هدر X-CSRF-Token توسط shim پنل اضافه می‌شود)
    melkinoCsrfCheck();
}

if ($action === 'save') {
    $data = melkinoAdminJsonBody();
    $payload = is_array($data['payload'] ?? null) ? $data['payload'] : $data;
    $adminId = !empty($_SESSION['admin_id']) ? (int)$_SESSION['admin_id'] : null;
    $adminName = (string)($_SESSION['admin_username'] ?? '');
    $res = melkinoFdSave($target, $payload, $adminId, $adminName);
    melkinoAdminJson([
        'success' => (bool)$res['success'],
        'message' => $res['success']
            ? 'تنظیمات ذخیره شد و بلافاصله روی سایت اعمال می‌شود.'
            : 'ذخیره انجام نشد.',
        'errors'  => $res['errors'] ?? [],
        'meta'    => $res['meta'] ?? null,
        'has_history' => true,
    ], $res['success'] ? 200 : 422);
}

if ($action === 'restore') {
    $adminId = !empty($_SESSION['admin_id']) ? (int)$_SESSION['admin_id'] : null;
    $res = melkinoFdRestore($target, $adminId);
    melkinoAdminJson([
        'success' => (bool)$res['success'],
        'message' => (string)($res['message'] ?? ''),
    ]);
}

if ($action === 'set_preview') {
    $data = melkinoAdminJsonBody();
    $draft = is_array($data['draft'] ?? null) ? $data['draft'] : null;
    $adId = trim((string)($data['ad_id'] ?? ''));
    if ($draft === null) {
        melkinoAdminJson(['success' => false, 'message' => 'draft نامعتبر'], 400);
    }
    if (!isset($_SESSION['fd_preview']) || !is_array($_SESSION['fd_preview'])) {
        $_SESSION['fd_preview'] = [];
    }
    $_SESSION['fd_preview'][$target] = $draft;
    $_SESSION['fd_preview'][$target . '_ad'] = $adId;
    melkinoAdminJson(['success' => true]);
}

if ($action === 'clear_preview') {
    unset($_SESSION['fd_preview'][$target], $_SESSION['fd_preview'][$target . '_ad']);
    melkinoAdminJson(['success' => true]);
}

melkinoAdminJson(['success' => false, 'message' => 'عمل نامعتبر'], 400);
