<?php
session_start();
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/db_helpers.php';
require_once __DIR__ . '/auth.php';
// نکته: قبلاً این فایل db_helpers.php را require نمی‌کرد؛ یعنی
// melkinoUpsertUser() اصلاً تعریف نشده بود و هر فراخوانی این
// endpoint با خطای «تابع تعریف‌نشده» رد می‌خورد.

/* ------------------------------------------------------------------
   راند ۳۰ — حذف/بازکردن شمارهٔ تماس کاربر توسط ادمین
   ------------------------------------------------------------------
   تنها مسیر مجاز برای تغییر شمارهٔ ثبت‌شدهٔ کاربر.
   - فقط ادمین (سشن سروری) + CSRF
   - phone = NULL و phone_verified = 0 و phone_locked = 0
   - یک ردیف لاگ در admin_phone_audit ثبت می‌شود:
     admin_id, admin_username, user_id, action, old_phone, new_phone,
     ip_address, created_at
------------------------------------------------------------------ */
// بدنهٔ درخواست یک‌بار خوانده می‌شود (php://input در برخی SAPIها دوبار خواندنی نیست)
$rawBody30 = (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') ? (string)file_get_contents('php://input') : '';
$body30 = json_decode($rawBody30, true);

if (($_GET['action'] ?? '') === 'clear_phone' || (is_array($body30) && ($body30['action'] ?? '') === 'clear_phone')) {
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
        http_response_code(405);
        echo json_encode(['success' => false, 'message' => 'روش مجاز نیست'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    if (empty($_SESSION['is_admin'])) {
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    $body = is_array($body30 ?? null) ? $body30 : $_POST;
    melkinoCsrfCheck();

    $targetUserId = (int)($body['user_id'] ?? 0);
    if ($targetUserId <= 0) {
        echo json_encode(['success' => false, 'message' => 'user_id نامعتبر است.'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    if (function_exists('melkinoEnsureUserProfileColumns')) {
        melkinoEnsureUserProfileColumns();
    }

    try {
        // ساخت جدول لاگ در صورت نبود (idempotent)
        $pdo->exec(
            "CREATE TABLE IF NOT EXISTS admin_phone_audit (
                id INT AUTO_INCREMENT PRIMARY KEY,
                admin_id INT NULL,
                admin_username VARCHAR(100) NULL,
                user_id INT NOT NULL,
                action VARCHAR(50) NOT NULL,
                old_phone VARCHAR(30) NULL,
                new_phone VARCHAR(30) NULL,
                ip_address VARCHAR(45) NULL,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_apa_user (user_id),
                INDEX idx_apa_created (created_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
        );

        $st = $pdo->prepare('SELECT id, phone, name, telegram_id FROM users WHERE id = ? LIMIT 1');
        $st->execute([$targetUserId]);
        $target = $st->fetch(PDO::FETCH_ASSOC);
        if (!$target) {
            http_response_code(404);
            echo json_encode(['success' => false, 'message' => 'کاربر پیدا نشد.'], JSON_UNESCAPED_UNICODE);
            exit;
        }
        $oldPhone = trim((string)($target['phone'] ?? ''));

        $pdo->prepare('UPDATE users SET phone = NULL, phone_verified = 0, phone_locked = 0, updated_at = NOW() WHERE id = ?')
            ->execute([$targetUserId]);

        $pdo->prepare(
            'INSERT INTO admin_phone_audit (admin_id, admin_username, user_id, action, old_phone, new_phone, ip_address, created_at)
             VALUES (?, ?, ?, ?, ?, NULL, ?, NOW())'
        )->execute([
            (int)($_SESSION['admin_id'] ?? 0) ?: null,
            (string)($_SESSION['admin_username'] ?? ''),
            $targetUserId,
            'clear_phone',
            $oldPhone !== '' ? $oldPhone : null,
            substr((string)($_SERVER['REMOTE_ADDR'] ?? ''), 0, 45),
        ]);

        echo json_encode([
            'success'   => true,
            'message'   => 'شمارهٔ تماس کاربر حذف و قفل آن باز شد.',
            'user_id'   => $targetUserId,
            'old_phone' => $oldPhone,
        ], JSON_UNESCAPED_UNICODE);
    } catch (Throwable $e) {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'خطا در حذف شماره: ' . $e->getMessage()], JSON_UNESCAPED_UNICODE);
    }
    exit;
}

if (($_GET['action'] ?? '') === 'list') {
    if (empty($_SESSION['is_admin'])) {
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    // ستون‌های پروفایل را در صورت نیاز اضافه می‌کنیم (فقط اگر نباشند)
    if (function_exists('melkinoEnsureUserProfileColumns')) {
        melkinoEnsureUserProfileColumns();
    }

    // تلاش برای خواندن تمام ستون‌ها؛ در صورت نبودِ ستونی، به کوئری ساده برمی‌گردیم
    try {
        $rows = $pdo->query(
            "SELECT id, telegram_id, bale_id, username, name, phone, is_active,
                    first_login, last_login, login_count, created_at,
                    last_ip, last_platform, user_agent, photo_url, language_code,
                    phone_verified, phone_locked
               FROM users
              ORDER BY last_login DESC"
        )->fetchAll(PDO::FETCH_ASSOC);
    } catch (Throwable $e) {
        $rows = $pdo->query(
            "SELECT id, telegram_id, username, name, phone, is_active,
                    first_login, last_login, login_count, created_at
               FROM users
              ORDER BY last_login DESC"
        )->fetchAll(PDO::FETCH_ASSOC);
    }

    echo json_encode(['success' => true, 'users' => $rows], JSON_UNESCAPED_UNICODE);
    exit;
}

if (($_GET['action'] ?? '') === 'history') {
    if (empty($_SESSION['is_admin'])) {
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    $uid = (int)($_GET['user_id'] ?? 0);
    if ($uid <= 0) {
        echo json_encode(['success' => false, 'message' => 'شناسه نامعتبر'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    // راند ۳۳: SELECT پویا از ستون‌های موجود — روی جدول قدیمی (بدون
    // bale_id/username/name/ip_address) هم تاریخچه بدون خطا برمی‌گردد و
    // روی جدول جدید همهٔ شناسه‌ها کامل ارسال می‌شوند.
    if (function_exists('melkinoEnsureLoginEventsSchema')) {
        melkinoEnsureLoginEventsSchema($pdo);
    }
    try {
        $leCols33 = [];
        foreach ($pdo->query('SHOW COLUMNS FROM login_events')->fetchAll(PDO::FETCH_ASSOC) as $c33) {
            $leCols33[strtolower((string)$c33['Field'])] = true;
        }
        $want33 = ['id', 'telegram_id', 'bale_id', 'username', 'name', 'ip_address', 'ip', 'user_agent', 'platform', 'language_code', 'created_at'];
        $sel33 = array_values(array_filter($want33, function ($c) use ($leCols33) {
            return isset($leCols33[$c]);
        }));
        if (!$sel33) {
            $sel33 = ['id'];
        }
        $st = $pdo->prepare('SELECT `' . implode('`,`', $sel33) . '` FROM login_events WHERE user_id=? ORDER BY created_at DESC LIMIT 200');
        $st->execute([$uid]);
        $events33 = $st->fetchAll(PDO::FETCH_ASSOC);
    } catch (Throwable $e) {
        $events33 = [];
    }
    echo json_encode(['success' => true, 'events' => $events33], JSON_UNESCAPED_UNICODE);
    exit;
}

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'روش مجاز نیست'], JSON_UNESCAPED_UNICODE);
    exit;
}

$p = json_decode($rawBody30 !== '' ? $rawBody30 : (string)file_get_contents('php://input'), true);
if (!is_array($p)) $p = [];

$phone = trim((string)($p['phone'] ?? ''));
$rawInitData = (string)($p['init_data'] ?? '');

// نکته‌ی امنیتی مهم: قبلاً هر مقدار telegram_id/username/name که
// کلاینت خودش می‌فرستاد مستقیماً پذیرفته می‌شد — یعنی هرکسی می‌تونست
// مستقیم به این endpoint درخواست بزنه و ادعا کنه فلان آی‌دی تلگرام
// رو داره. حالا فقط initData خام رو می‌گیریم و با امضای رمزنگاری‌شده‌ی
// تلگرام (که فقط خودِ تلگرام می‌تونه درست بسازدش) تأییدش می‌کنیم.
$tg = '';
$name = '';
$u = '';

if ($rawInitData !== '') {
    $verified = melkinoVerifyTelegramInitData($rawInitData);
    if ($verified !== null) {
        $tg = $verified['id'];
        $u = $verified['username'];
        $name = trim($verified['first_name'] . ' ' . $verified['last_name']);
    }
}

if ($tg === '' && $phone === '') {
    http_response_code(422);
    echo json_encode(['success' => false, 'message' => 'اطلاعات هویتی معتبر ارسال نشد.'], JSON_UNESCAPED_UNICODE);
    exit;
}

$ip = $_SERVER['REMOTE_ADDR'] ?? null;
$ua = substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 1000);

$providedToken = trim((string)($_COOKIE['melkino_access_token'] ?? ''));
$identity = melkinoUpsertUser($tg, $phone, $name, $u, $providedToken);
$uid = $identity['id'];

if ($uid && ($tg !== '' || $phone !== '')) {
    // راند ۳۳: INSERT تطبیقی با ستون‌های موجود — روی جدول قدیمی از ستون ip
    // استفاده می‌کند تا ثبت شماره هرگز به‌خاطر تاریخچه شکست نخورد.
    if (function_exists('melkinoEnsureLoginEventsSchema')) {
        melkinoEnsureLoginEventsSchema($pdo);
    }
    try {
        $leCols33 = [];
        foreach ($pdo->query('SHOW COLUMNS FROM login_events')->fetchAll(PDO::FETCH_ASSOC) as $c33) {
            $leCols33[strtolower((string)$c33['Field'])] = true;
        }
        $map33 = [
            'user_id'     => $uid,
            'telegram_id' => $tg !== '' ? $tg : null,
            'username'    => $u,
            'name'        => $name,
            'ip_address'  => $ip,
            'ip'          => $ip,
            'user_agent'  => $ua,
        ];
        $cols33 = [];
        $vals33 = [];
        foreach ($map33 as $c33 => $v33) {
            if (isset($leCols33[$c33])) {
                $cols33[] = '`' . $c33 . '`';
                $vals33[] = $v33;
            }
        }
        if ($cols33) {
            $le = $pdo->prepare('INSERT INTO login_events (' . implode(',', $cols33) . ') VALUES (' . implode(',', array_fill(0, count($cols33), '?')) . ')');
            $le->execute($vals33);
        }
    } catch (Throwable $e) {
        // ثبت تاریخچه حیاتی نیست؛ جریان ثبت شماره نباید بخاطر آن متوقف شود
    }
}

$existingPhone = '';

if (!empty($identity['trusted'])) {
    if ($tg !== '') {
        $_SESSION['reg_telegram_id'] = $tg;
    }
    if ($name !== '') {
        $_SESSION['user_name'] = $name;
    }
    $existingPhone = $phone;
    if ($uid) {
        $row = $pdo->prepare('SELECT phone FROM users WHERE id=?');
        $row->execute([$uid]);
        $fromDb = trim((string)$row->fetchColumn());
        if ($fromDb !== '') $existingPhone = $fromDb;
    }
    if ($existingPhone !== '') {
        $_SESSION['user_phone'] = $existingPhone;
    }
    if (!empty($identity['token'])) {
        setcookie('melkino_access_token', $identity['token'], time() + 31536000, '/', '', false, true);
    }
}

echo json_encode([
    'success' => !empty($identity['trusted']),
    'status' => $identity['status'],
    'user_id' => $uid,
    'phone' => $existingPhone,
], JSON_UNESCAPED_UNICODE);
