<?php
require_once __DIR__ . '/includes/ads.php';

$id = (int)($_GET['id'] ?? 0);
$to = $_GET['to'] ?? '';

if ($id > 0) {
  recordAdClick($id);
}

$to = filter_var($to, FILTER_VALIDATE_URL) ? $to : (SITE_URL . '/home.php');
header('Location: ' . $to);
exit;
