<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/ads.php';
requireAdmin();

$id = (int)($_GET['id'] ?? 0);
if ($id > 0) deleteAd($id);

header('Location: index.php?tab=ads');
exit;
