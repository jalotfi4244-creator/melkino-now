<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/ads.php';
requireAdmin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  header('Location: index.php?tab=ads');
  exit;
}

$id = !empty($_POST['id']) ? (int)$_POST['id'] : null;
$imageName = null;

// اگر ویرایش است، تصویر قبلی را نگه دار مگر تصویر جدیدی آپلود شود
if ($id) {
  $existing = getAd($id);
  $imageName = $existing['image'] ?? null;
}

// آپلود تصویر جدید (اختیاری)
if (!empty($_FILES['image']['name']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
  $allowed = ['jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp'];
  $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
  if (isset($allowed[$ext]) && $_FILES['image']['size'] <= 5 * 1024 * 1024) {
    $newName = 'ad_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
    $dest = UPLOADS_DIR . '/ads/' . $newName;
    if (move_uploaded_file($_FILES['image']['tmp_name'], $dest)) {
      // حذف تصویر قبلی در صورت وجود
      if ($imageName) {
        $old = UPLOADS_DIR . '/ads/' . basename($imageName);
        if (is_file($old)) @unlink($old);
      }
      $imageName = 'ads/' . $newName;
    }
  }
}

$data = [
  'title' => trim($_POST['title'] ?? ''),
  'description' => trim($_POST['description'] ?? ''),
  'image' => $imageName,
  'link_url' => trim($_POST['link_url'] ?? ''),
  'badge_text' => trim($_POST['badge_text'] ?? '') ?: 'تبلیغات',
  'position' => (int)($_POST['position'] ?? 3),
  'repeat_every' => (int)($_POST['repeat_every'] ?? 0),
  'sort_order' => (int)($_POST['sort_order'] ?? 0),
  'active' => isset($_POST['active']) ? 1 : 0,
];

if ($data['title'] === '') {
  header('Location: index.php?tab=ads&error=' . urlencode('عنوان تبلیغ الزامی است'));
  exit;
}

saveAd($data, $id);
header('Location: index.php?tab=ads&ok=1');
exit;
