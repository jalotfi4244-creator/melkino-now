<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/ads.php';
require_once __DIR__ . '/../includes/user_auth.php';
requireAdmin();

$general = generalSettings();
$tab = $_GET['tab'] ?? 'dash';

$TABS = [
  'dash' => ['label' => 'داشبورد', 'icon' => '📊'],
  'props' => ['label' => 'آگهی‌ها', 'icon' => '📋'],
  'reqs' => ['label' => 'درخواست‌ها', 'icon' => '📩'],
  'users' => ['label' => 'کاربران', 'icon' => '👤'],
  'ads' => ['label' => 'تبلیغات', 'icon' => '📣'],
  'onboard' => ['label' => 'صفحات هدایت', 'icon' => '🚀'],
  'general' => ['label' => 'عمومی', 'icon' => '🧩'],
  'themes' => ['label' => 'تم‌ها', 'icon' => '🎨'],
  'social' => ['label' => 'شبکه‌ها', 'icon' => '🌐'],
  'contact' => ['label' => 'تماس', 'icon' => '📞'],
  'support' => ['label' => 'پشتیبانی', 'icon' => '🎧'],
  'password' => ['label' => 'تغییر رمز', 'icon' => '🔑'],
];

// آماری برای داشبورد
$pStats = db()->query("SELECT
    COUNT(*) total,
    SUM(deal_type='sale') sale,
    SUM(deal_type='rent') rent,
    SUM(status='available') available,
    SUM(status='pending') pending,
    SUM(vip=1) vip,
    COALESCE(SUM(views),0) views
  FROM properties")->fetch();
$reqCount = (int)db()->query("SELECT COUNT(*) c FROM requests")->fetch()['c'];
$reqNew = (int)db()->query("SELECT COUNT(*) c FROM requests WHERE status='new'")->fetch()['c'];
$usersCount = (int)db()->query("SELECT COUNT(*) c FROM app_users")->fetch()['c'];
$msgNew = (int)db()->query("SELECT COUNT(*) c FROM messages WHERE status='new'")->fetch()['c'];
$adsCount = (int)db()->query("SELECT COUNT(*) c FROM ads")->fetch()['c'];
$adsActive = (int)db()->query("SELECT COUNT(*) c FROM ads WHERE active=1")->fetch()['c'];
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>پنل مدیریت ملکینو</title>
<script src="https://cdn.tailwindcss.com"></script>
<link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/style.css">
</head>
<body>
<div class="adm-root">
  <header class="adm-header">
    <div class="adm-header-inner">
      <div class="adm-title">⚙️ پنل مدیریت ملکینو</div>
      <div class="flex items-center gap-2">
        <a href="<?= SITE_URL ?>/home.php" class="adm-hbtn" title="بازگشت به سایت">🏠</a>
        <a href="logout.php" class="adm-hbtn" title="خروج">🚪</a>
      </div>
    </div>
  </header>

  <div class="adm-wrap">
    <!-- تب‌ها -->
    <nav class="adm-nav">
      <?php foreach ($TABS as $id => $t): ?>
        <a href="?tab=<?= $id ?>" class="adm-tab <?= $tab === $id ? 'active' : '' ?>">
          <span><?= $t['icon'] ?></span> <span><?= $t['label'] ?></span>
        </a>
      <?php endforeach; ?>
    </nav>

    <?php if ($tab === 'dash'): ?>
      <!-- ========== داشبورد ========== -->
      <div class="adm-hero mb-4">
        <div class="adm-hero-orbs"><i></i><i></i><i></i><i></i><i></i></div>
        <div class="relative">
          <div class="adm-hero-label">MELKINO CONTROL CENTER</div>
          <h2>مرکز کنترل ملکینو</h2>
          <p>مدیریت آگهی‌ها، درخواست‌ها، کاربران و تبلیغات در یک پنل واحد.</p>
          <a href="?tab=props" class="adm-hero-btn">پنل مدیریت آگهی‌ها</a>
          <a href="?tab=ads" class="adm-hero-btn" style="border-color:var(--gold);color:var(--gold-light)">📣 مدیریت تبلیغات</a>
        </div>
      </div>
      <div class="grid grid-cols-2 md:grid-cols-4 gap-3">
        <?php
        $cards = [
          ['icon' => '📋', 'num' => (int)$pStats['total'], 'title' => 'کل آگهی‌ها', 'sub' => (int)$pStats['sale'] . ' فروش • ' . (int)$pStats['rent'] . ' اجاره'],
          ['icon' => '🧩', 'num' => (int)$pStats['available'], 'title' => 'آگهی‌های منتشرشده', 'sub' => 'قابل مشاهده برای کاربران'],
          ['icon' => '⏳', 'num' => (int)$pStats['pending'], 'title' => 'در انتظار تایید', 'sub' => 'نیاز به بررسی مدیر'],
          ['icon' => '⭐', 'num' => (int)$pStats['vip'], 'title' => 'فایل‌های VIP', 'sub' => 'آگهی‌های ویژه'],
          ['icon' => '📩', 'num' => $reqCount, 'title' => 'درخواست‌ها', 'sub' => $reqNew . ' درخواست جدید'],
          ['icon' => '👥', 'num' => $usersCount, 'title' => 'کاربران', 'sub' => 'کاربران شناسایی‌شده اپ'],
          ['icon' => '🎧', 'num' => $msgNew, 'title' => 'پیام‌های پشتیبانی', 'sub' => 'پیام‌های خوانده‌نشده'],
          ['icon' => '📣', 'num' => $adsActive, 'title' => 'تبلیغات فعال', 'sub' => 'از مجموع ' . $adsCount . ' تبلیغ'],
        ];
        foreach ($cards as $c): ?>
          <div class="adm-card adm-stat p-4 relative overflow-hidden">
            <div class="text-[22px]"><?= $c['icon'] ?></div>
            <div class="font-black text-[24px] mt-1" style="color:var(--text-primary)"><?= toFaDigits($c['num']) ?></div>
            <div class="font-bold text-[13px] mt-0.5" style="color:var(--text-primary)"><?= e($c['title']) ?></div>
            <div class="text-[11px] mt-0.5" style="color:var(--text-muted)"><?= e($c['sub']) ?></div>
          </div>
        <?php endforeach; ?>
      </div>

    <?php elseif ($tab === 'ads'): ?>
      <!-- ========== مدیریت تبلیغات ========== -->
      <?php include __DIR__ . '/tabs/ads_tab.php'; ?>

    <?php elseif ($tab === 'props'): ?>
      <?php include __DIR__ . '/tabs/props_tab.php'; ?>

    <?php elseif ($tab === 'reqs'): ?>
      <?php include __DIR__ . '/tabs/reqs_tab.php'; ?>

    <?php elseif ($tab === 'users'): ?>
      <?php include __DIR__ . '/tabs/users_tab.php'; ?>

    <?php elseif ($tab === 'general'): ?>
      <?php include __DIR__ . '/tabs/general_tab.php'; ?>

    <?php elseif ($tab === 'contact'): ?>
      <?php include __DIR__ . '/tabs/contact_tab.php'; ?>

    <?php elseif ($tab === 'social'): ?>
      <?php include __DIR__ . '/tabs/social_tab.php'; ?>

    <?php elseif ($tab === 'channels'): ?>
      <?php include __DIR__ . '/tabs/channels_tab.php'; ?>

    <?php elseif ($tab === 'support'): ?>
      <?php include __DIR__ . '/tabs/support_tab.php'; ?>

    <?php elseif ($tab === 'password'): ?>
      <?php include __DIR__ . '/tabs/password_tab.php'; ?>

    <?php else: ?>
      <!-- ========== سایر بخش‌ها: فاز بعدی ========== -->
      <div class="adm-card p-8 text-center">
        <div class="text-[40px] mb-3"><?= $TABS[$tab]['icon'] ?? '🚧' ?></div>
        <h3 class="font-black text-[18px]" style="color:var(--text-primary)"><?= e($TABS[$tab]['label'] ?? '') ?></h3>
        <p class="text-[13px] mt-2" style="color:var(--text-muted)">این بخش در فاز بعدی تبدیل پروژه به PHP پیاده‌سازی می‌شود.</p>
      </div>
    <?php endif; ?>
  </div>
</div>
</body>
</html>
