<?php
require_once __DIR__ . '/../includes/auth.php';

if (isAdmin()) {
  header('Location: index.php');
  exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $pass = (string)($_POST['password'] ?? '');
  if ($pass === '') {
    $error = 'رمز عبور را وارد کنید';
  } elseif (adminLogin($pass)) {
    header('Location: index.php');
    exit;
  } else {
    $error = 'رمز عبور اشتباه است';
  }
}

$general = generalSettings();
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>ورود به پنل مدیریت ملکینو</title>
<script src="https://cdn.tailwindcss.com"></script>
<link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/style.css">
</head>
<body>
<div class="adm-login">
  <div class="w-full max-w-md">
    <div class="text-center mb-6">
      <div class="w-20 h-20 mx-auto rounded-full flex items-center justify-center font-black text-4xl mb-4" style="background:linear-gradient(135deg,var(--gold-light,#F1D477),var(--gold,#D4AF37) 60%,var(--gold-dark,#B98F19));color:var(--mk-dark-b,#0B3E3A);box-shadow:0 12px 30px color-mix(in srgb, var(--gold) 45%, transparent)">
        <?= e($general['logoLetter'] ?: 'م') ?>
      </div>
      <div class="text-[12px] tracking-[.25em] font-extrabold" style="color:var(--gold-light,#E5B842)">MELKINO ADMIN</div>
      <h1 class="text-white font-black text-[26px] mt-1">پنل مدیریت ملکینو</h1>
      <p class="text-[13px] mt-1" style="color:rgba(255,255,255,.6)">ورود فقط برای تیم مدیریت</p>
    </div>
    <form method="post" class="rounded-[28px] p-6" style="background:rgba(255,255,255,.06);border:1px solid rgba(212,175,55,.3);backdrop-filter:blur(14px)">
      <label class="block text-[13px] font-bold mb-2" style="color:rgba(255,255,255,.8)">🔑 رمز عبور پنل</label>
      <input type="password" name="password" placeholder="••••••••••" dir="ltr"
        class="w-full rounded-2xl px-4 py-4 text-[15px] text-white outline-none"
        style="background:rgba(0,0,0,.25);border:1.5px solid rgba(255,255,255,.15);text-align:left" autofocus>
      <?php if ($error): ?>
        <p class="text-[13px] mt-2.5 font-bold" style="color:#F87171"><?= e($error) ?></p>
      <?php endif; ?>
      <button type="submit" class="w-full mt-4 py-4 rounded-2xl font-black text-[15px]" style="background:linear-gradient(135deg,var(--gold-light,#F1D477),var(--gold,#D4AF37) 60%,var(--gold-dark,#B98F19));color:var(--mk-dark-b,#0B3E3A);box-shadow:0 12px 28px color-mix(in srgb, var(--gold) 40%, transparent)">
        ورود به پنل مدیریت
      </button>
      <a href="<?= SITE_URL ?>/home.php" class="block text-center text-[12.5px] mt-4" style="color:rgba(255,255,255,.55)">بازگشت به ملکینو ←</a>
    </form>
  </div>
</div>
</body>
</html>
