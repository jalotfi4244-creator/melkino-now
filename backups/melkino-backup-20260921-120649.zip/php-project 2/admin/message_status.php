<?php
require_once __DIR__ . '/../includes/auth.php';
requireAdmin();

$id = (int)($_POST['id'] ?? 0);
$status = $_POST['status'] ?? 'new';
$valid = ['new', 'read', 'answered', 'archived'];
if ($id > 0 && in_array($status, $valid)) {
  db()->prepare('UPDATE messages SET status = ? WHERE id = ?')->execute([$status, $id]);
}
header('Location: index.php?tab=support');
exit;
