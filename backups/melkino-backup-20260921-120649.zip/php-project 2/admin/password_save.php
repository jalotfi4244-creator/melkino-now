<?php
require_once __DIR__ . '/../includes/auth.php';
requireAdmin();

$current = $_POST['current'] ?? '';
$new1 = $_POST['new1'] ?? '';
$new2 = $_POST['new2'] ?? '';

if (!checkAdminPassword($current)) {
  header('Location: index.php?tab=password&error=' . urlencode('رمز فعلی اشتباه است'));
  exit;
}
if (strlen($new1) < 4 || $new1 !== $new2) {
  header('Location: index.php?tab=password&error=' . urlencode('رمز جدید نامعتبر یا تکرار آن اشتباه است'));
  exit;
}

setAdminHash(hashAdminPassword($new1));
header('Location: index.php?tab=password&ok=1');
exit;
