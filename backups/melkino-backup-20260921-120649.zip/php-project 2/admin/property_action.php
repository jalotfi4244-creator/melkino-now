<?php
require_once __DIR__ . '/../includes/auth.php';
requireAdmin();

$id = (int)($_GET['id'] ?? 0);
$do = $_GET['do'] ?? '';

if ($id > 0) {
  switch ($do) {
    case 'approve': db()->prepare("UPDATE properties SET status='available' WHERE id=?")->execute([$id]); break;
    case 'reject': db()->prepare("UPDATE properties SET status='rejected' WHERE id=?")->execute([$id]); break;
    case 'sold': db()->prepare("UPDATE properties SET status='sold' WHERE id=?")->execute([$id]); break;
    case 'vip': db()->prepare('UPDATE properties SET vip = 1 - vip WHERE id=?')->execute([$id]); break;
    case 'featured': db()->prepare('UPDATE properties SET featured = 1 - featured WHERE id=?')->execute([$id]); break;
    case 'delete':
      $stmt = db()->prepare('SELECT all_images FROM properties WHERE id=?');
      $stmt->execute([$id]);
      $row = $stmt->fetch();
      if ($row) {
        foreach (j_decode($row['all_images'], []) as $img) {
          $path = UPLOADS_DIR . '/' . ltrim($img, '/');
          if (is_file($path)) @unlink($path);
        }
      }
      db()->prepare('DELETE FROM properties WHERE id=?')->execute([$id]);
      break;
  }
}

$qs = http_build_query(['tab' => 'props', 'pstatus' => $_GET['pstatus'] ?? 'all', 'pq' => $_GET['pq'] ?? '']);
header('Location: index.php?' . $qs);
exit;
