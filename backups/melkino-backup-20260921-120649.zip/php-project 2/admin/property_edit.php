<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
requireAdmin();

$id = (int)($_GET['id'] ?? 0);
$stmt = db()->prepare('SELECT * FROM properties WHERE id = ?');
$stmt->execute([$id]);
$p = $stmt->fetch();
if (!$p) { header('Location: index.php?tab=props'); exit; }

$ok = false;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  db()->prepare(
    'UPDATE properties SET title=?, description=?, price=?, rent_price=?, mortgage_price=?, area=?, land_area=?,
     rooms=?, floor=?, address=?, neighborhood=?, city=?, status=?, vip=?, featured=? WHERE id=?'
  )->execute([
    trim($_POST['title']), trim($_POST['description']), parsePriceInput($_POST['price']),
    parsePriceInput($_POST['rent_price']), parsePriceInput($_POST['mortgage_price']),
    (int)$_POST['area'], (int)$_POST['land_area'], (int)$_POST['rooms'], (int)$_POST['floor'],
    trim($_POST['address']), trim($_POST['neighborhood']), trim($_POST['city']),
    $_POST['status'], isset($_POST['vip']) ? 1 : 0, isset($_POST['featured']) ? 1 : 0, $id,
  ]);
  $ok = true;
  $stmt->execute([$id]);
  $p = $stmt->fetch();
}

function parsePriceInput($v) {
  $v = preg_replace('/[^\d]/', '', (string)$v);
  return $v === '' ? 0 : (int)$v;
}

$statusLabels = STATUS_LABELS();
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>ویرایش آگهی</title>
<script src="https://cdn.tailwindcss.com"></script>
<link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/style.css">
</head>
<body>
<div class="adm-root">
  <header class="adm-header"><div class="adm-header-inner"><div class="adm-title">✏️ ویرایش آگهی</div><a href="index.php?tab=props" class="adm-hbtn">← بازگشت</a></div></header>
  <div class="adm-wrap">
    <div class="adm-card p-5" style="max-width:560px;margin:0 auto">
      <?php if ($ok): ?><div class="badge badge-success mb-3">تغییرات ذخیره شد</div><?php endif; ?>
      <form method="post" class="space-y-3">
        <div class="form-group"><label>عنوان</label><input class="form-input" name="title" value="<?= e($p['title']) ?>"></div>
        <div class="form-group"><label>توضیحات</label><textarea class="form-textarea" name="description" rows="3"><?= e($p['description']) ?></textarea></div>
        <div class="row-half">
          <div class="form-group"><label>قیمت</label><input class="form-input" name="price" value="<?= (int)$p['price'] ?>"></div>
          <div class="form-group"><label>اجاره ماهانه</label><input class="form-input" name="rent_price" value="<?= (int)$p['rent_price'] ?>"></div>
        </div>
        <div class="row-half">
          <div class="form-group"><label>ودیعه/رهن</label><input class="form-input" name="mortgage_price" value="<?= (int)$p['mortgage_price'] ?>"></div>
          <div class="form-group"><label>متراژ</label><input class="form-input" name="area" value="<?= (int)$p['area'] ?>"></div>
        </div>
        <div class="row-half">
          <div class="form-group"><label>متراژ زمین</label><input class="form-input" name="land_area" value="<?= (int)$p['land_area'] ?>"></div>
          <div class="form-group"><label>اتاق</label><input class="form-input" name="rooms" value="<?= (int)$p['rooms'] ?>"></div>
        </div>
        <div class="form-group"><label>طبقه</label><input class="form-input" name="floor" value="<?= (int)$p['floor'] ?>"></div>
        <div class="form-group"><label>آدرس</label><input class="form-input" name="address" value="<?= e($p['address']) ?>"></div>
        <div class="row-half">
          <div class="form-group"><label>محله</label><input class="form-input" name="neighborhood" value="<?= e($p['neighborhood']) ?>"></div>
          <div class="form-group"><label>شهر</label><input class="form-input" name="city" value="<?= e($p['city']) ?>"></div>
        </div>
        <div class="form-group">
          <label>وضعیت</label>
          <select class="form-select" name="status">
            <?php foreach ($statusLabels as $k => $v): ?><option value="<?= $k ?>" <?= $p['status'] === $k ? 'selected' : '' ?>><?= e($v) ?></option><?php endforeach; ?>
          </select>
        </div>
        <label class="amen-check"><input type="checkbox" name="vip" <?= $p['vip'] ? 'checked' : '' ?>> فایل VIP</label>
        <label class="amen-check"><input type="checkbox" name="featured" <?= $p['featured'] ? 'checked' : '' ?>> آگهی ویژه</label>
        <button type="submit" class="btn-gold w-full py-3.5 rounded-2xl text-sm mt-3">ذخیره تغییرات</button>
      </form>
    </div>
  </div>
</div>
</body>
</html>
