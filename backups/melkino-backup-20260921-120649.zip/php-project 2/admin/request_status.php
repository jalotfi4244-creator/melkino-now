<?php
require_once __DIR__ . '/../includes/auth.php';
requireAdmin();

$id = (int)($_POST['id'] ?? 0);
$status = $_POST['status'] ?? 'new';
$valid = ['new', 'inprogress', 'contacted', 'done', 'closed'];
if ($id > 0 && in_array($status, $valid)) {
  db()->prepare('UPDATE requests SET status = ? WHERE id = ?')->execute([$status, $id]);
}
$qs = http_build_query(['tab' => 'reqs', 'rstatus' => $_POST['rstatus'] ?? 'all']);
header('Location: index.php?' . $qs);
exit;
