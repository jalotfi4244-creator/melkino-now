<?php
require_once __DIR__ . '/../includes/auth.php';
requireAdmin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: index.php'); exit; }

$key = $_POST['settings_key'] ?? '';
$allowedKeys = ['general', 'contact', 'social', 'channels'];
if (!in_array($key, $allowedKeys)) { header('Location: index.php'); exit; }

$current = getSetting($key, []);
$booleanFields = [
  'general' => ['logoInHeader', 'logoInOnboarding', 'autoPublish', 'showVipOnHome'],
  'social' => ['showInContact', 'showInProfile'],
  'channels' => ['autoPostOnApprove'],
];

foreach ($_POST as $k => $v) {
  if (in_array($k, ['settings_key'])) continue;
  $current[$k] = $v;
}
foreach (($booleanFields[$key] ?? []) as $bf) {
  $current[$bf] = isset($_POST[$bf]);
}

// آپلود لوگو (فقط برای general)
if ($key === 'general' && !empty($_FILES['logo']['name']) && $_FILES['logo']['error'] === UPLOAD_ERR_OK) {
  $ext = strtolower(pathinfo($_FILES['logo']['name'], PATHINFO_EXTENSION));
  if (in_array($ext, ['jpg', 'jpeg', 'png', 'webp', 'svg'])) {
    $newName = 'logo_' . time() . '.' . $ext;
    if (move_uploaded_file($_FILES['logo']['tmp_name'], UPLOADS_DIR . '/branding/' . $newName)) {
      $current['logoUrl'] = 'branding/' . $newName;
    }
  }
}

setSetting($key, $current);
header('Location: index.php?tab=' . urlencode($_POST['back_tab'] ?? $key) . '&ok=1');
exit;
