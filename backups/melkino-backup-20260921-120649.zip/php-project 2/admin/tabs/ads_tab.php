<?php
/** این فایل داخل admin/index.php اینکلود می‌شود */
$allAds = getAllAds();
$editId = isset($_GET['edit']) ? (int)$_GET['edit'] : null;
$editAd = $editId ? getAd($editId) : null;
$ok = isset($_GET['ok']);
$error = $_GET['error'] ?? '';
?>
<div class="grid grid-cols-1 lg:grid-cols-5 gap-4">

  <!-- فرم افزودن / ویرایش -->
  <div class="lg:col-span-2">
    <div class="adm-card p-5">
      <h3 class="font-black text-[16px] mb-1" style="color:var(--text-primary)">
        <?= $editAd ? '✏️ ویرایش تبلیغ' : '➕ افزودن تبلیغ جدید' ?>
      </h3>
      <p class="text-[12px] mb-4" style="color:var(--text-muted)">
        تبلیغ بین کارت‌های آگهی در صفحه اصلی، بعد از موقعیت مشخص‌شده نمایش داده می‌شود.
      </p>

      <?php if ($ok): ?><div class="badge badge-success mb-3">تغییرات با موفقیت ذخیره شد</div><?php endif; ?>
      <?php if ($error): ?><div class="badge badge-danger mb-3"><?= e($error) ?></div><?php endif; ?>

      <form method="post" action="ads_save.php" enctype="multipart/form-data" class="space-y-3">
        <?php if ($editAd): ?><input type="hidden" name="id" value="<?= (int)$editAd['id'] ?>"><?php endif; ?>

        <div class="form-group">
          <label>عنوان تبلیغ *</label>
          <input type="text" name="title" class="form-input" required value="<?= e($editAd['title'] ?? '') ?>" placeholder="مثلاً: تخفیف ویژه مشاوران املاک آریا">
        </div>

        <div class="form-group">
          <label>توضیح کوتاه</label>
          <textarea name="description" class="form-textarea" rows="2" placeholder="یک جمله کوتاه درباره تبلیغ"><?= e($editAd['description'] ?? '') ?></textarea>
        </div>

        <div class="form-group">
          <label>لینک مقصد (با کلیک کاربر به این آدرس می‌رود)</label>
          <input type="url" name="link_url" class="form-input" dir="ltr" value="<?= e($editAd['link_url'] ?? '') ?>" placeholder="https://...">
        </div>

        <div class="form-group">
          <label>تصویر تبلیغ</label>
          <?php if (!empty($editAd['image'])): ?>
            <img src="<?= e(propertyImageUrl($editAd['image'])) ?>" style="width:100%;height:120px;object-fit:cover;border-radius:14px;margin-bottom:8px">
          <?php endif; ?>
          <input type="file" name="image" accept="image/png,image/jpeg,image/webp" class="form-input">
        </div>

        <div class="row-half">
          <div class="form-group">
            <label>برچسب روی کارت</label>
            <input type="text" name="badge_text" class="form-input" value="<?= e($editAd['badge_text'] ?? 'تبلیغات') ?>">
          </div>
          <div class="form-group">
            <label>ترتیب نمایش (چند تبلیغ هم‌زمان)</label>
            <input type="number" name="sort_order" class="form-input" value="<?= e((string)($editAd['sort_order'] ?? 0)) ?>">
          </div>
        </div>

        <div class="row-half">
          <div class="form-group">
            <label>بعد از کارت شماره</label>
            <input type="number" min="1" name="position" class="form-input" value="<?= e((string)($editAd['position'] ?? 3)) ?>" required>
          </div>
          <div class="form-group">
            <label>تکرار هر چند کارت (۰=فقط یک‌بار)</label>
            <input type="number" min="0" name="repeat_every" class="form-input" value="<?= e((string)($editAd['repeat_every'] ?? 0)) ?>">
          </div>
        </div>

        <label class="amen-check">
          <input type="checkbox" name="active" <?= (!$editAd || !empty($editAd['active'])) ? 'checked' : '' ?>>
          نمایش فعال باشد
        </label>

        <div class="bottom-actions" style="padding-top:6px">
          <button type="submit" class="btn-gold py-3.5 rounded-2xl text-sm btn-primary-full">
            <?= $editAd ? 'ذخیره تغییرات' : 'افزودن تبلیغ' ?>
          </button>
          <?php if ($editAd): ?>
            <a href="?tab=ads" class="btn-secondary py-3.5 rounded-2xl text-sm px-5" style="text-decoration:none;text-align:center">انصراف</a>
          <?php endif; ?>
        </div>
      </form>
    </div>
  </div>

  <!-- فهرست تبلیغات -->
  <div class="lg:col-span-3">
    <div class="adm-card p-5">
      <h3 class="font-black text-[16px] mb-4" style="color:var(--text-primary)">فهرست تبلیغات (<?= toFaDigits(count($allAds)) ?>)</h3>

      <?php if (empty($allAds)): ?>
        <div class="text-center py-10" style="color:var(--text-muted)">هنوز تبلیغی ثبت نشده است.</div>
      <?php endif; ?>

      <div class="space-y-3">
        <?php foreach ($allAds as $ad): ?>
          <div class="card p-3 flex items-center gap-3">
            <?php if (!empty($ad['image'])): ?>
              <img src="<?= e(propertyImageUrl($ad['image'])) ?>" style="width:64px;height:64px;border-radius:12px;object-fit:cover;flex-shrink:0">
            <?php else: ?>
              <div style="width:64px;height:64px;border-radius:12px;background:var(--bg-secondary);flex-shrink:0;display:flex;align-items:center;justify-content:center">📣</div>
            <?php endif; ?>
            <div class="flex-1 min-w-0">
              <div class="font-extrabold text-[14px] truncate" style="color:var(--text-primary)"><?= e($ad['title']) ?></div>
              <div class="text-[11.5px] mt-0.5" style="color:var(--text-muted)">
                بعد از کارت <?= toFaDigits($ad['position']) ?>
                <?= $ad['repeat_every'] > 0 ? '• تکرار هر ' . toFaDigits($ad['repeat_every']) . ' کارت' : '• فقط یک‌بار' ?>
                • <?= toFaDigits($ad['views']) ?> نمایش • <?= toFaDigits($ad['clicks']) ?> کلیک
              </div>
              <span class="badge <?= $ad['active'] ? 'badge-success' : 'badge-danger' ?> mt-1.5"><?= $ad['active'] ? 'فعال' : 'غیرفعال' ?></span>
            </div>
            <div class="flex flex-col gap-1.5 flex-shrink-0">
              <a href="?tab=ads&edit=<?= (int)$ad['id'] ?>" class="option-btn" style="padding:6px 12px">ویرایش</a>
              <a href="ads_toggle.php?id=<?= (int)$ad['id'] ?>" class="option-btn" style="padding:6px 12px"><?= $ad['active'] ? 'خاموش' : 'روشن' ?></a>
              <a href="ads_delete.php?id=<?= (int)$ad['id'] ?>" class="option-btn" style="padding:6px 12px;color:var(--danger)" onclick="return confirm('حذف این تبلیغ؟')">حذف</a>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</div>
