<?php
$ch = getChannelSettings();
?>
<div class="adm-card p-5" style="max-width:600px">
  <h3 class="font-black text-[16px] mb-1" style="color:var(--text-primary)">🤖 اتصال ربات‌ها (تلگرام / بله)</h3>
  <p class="text-[12px] mb-4" style="color:var(--text-muted)">این توکن‌ها برای «ورود خودکار مینی‌اپ» و ارسال آگهی به کانال استفاده می‌شوند.</p>
  <?php if (isset($_GET['ok'])): ?><div class="badge badge-success mb-3">ذخیره شد</div><?php endif; ?>
  <form method="post" action="settings_save.php" class="space-y-3">
    <input type="hidden" name="settings_key" value="channels">
    <input type="hidden" name="back_tab" value="channels">

    <h4 class="font-extrabold text-[13px] mt-2" style="color:var(--gold-dark)">تلگرام</h4>
    <div class="form-group"><label>Bot Token</label><input class="form-input" dir="ltr" name="telegramBotToken" value="<?= e($ch['telegramBotToken']) ?>" placeholder="123456:ABC-DEF..."></div>
    <div class="row-half">
      <div class="form-group"><label>Chat ID کانال</label><input class="form-input" dir="ltr" name="telegramChatId" value="<?= e($ch['telegramChatId']) ?>" placeholder="@channel یا -100..."></div>
      <div class="form-group"><label>یوزرنیم ربات</label><input class="form-input" dir="ltr" name="telegramBotUsername" value="<?= e($ch['telegramBotUsername']) ?>" placeholder="my_bot"></div>
    </div>

    <h4 class="font-extrabold text-[13px] mt-4" style="color:var(--gold-dark)">بله</h4>
    <div class="form-group"><label>Bot Token</label><input class="form-input" dir="ltr" name="baleBotToken" value="<?= e($ch['baleBotToken']) ?>"></div>
    <div class="row-half">
      <div class="form-group"><label>Chat ID کانال</label><input class="form-input" dir="ltr" name="baleChatId" value="<?= e($ch['baleChatId']) ?>"></div>
      <div class="form-group"><label>یوزرنیم ربات</label><input class="form-input" dir="ltr" name="baleBotUsername" value="<?= e($ch['baleBotUsername']) ?>"></div>
    </div>

    <h4 class="font-extrabold text-[13px] mt-4" style="color:var(--gold-dark)">ارسال خودکار به کانال</h4>
    <div class="form-group"><label>آدرس عمومی سایت (برای لینک در پست)</label><input class="form-input" dir="ltr" name="siteUrl" value="<?= e($ch['siteUrl'] ?: SITE_URL) ?>"></div>
    <div class="form-group"><label>قالب متن پست</label><textarea class="form-textarea" name="postTemplate" rows="3" placeholder="{title}&#10;💰 {price}&#10;📍 {neighborhood}&#10;{link}"><?= e($ch['postTemplate']) ?></textarea></div>
    <label class="amen-check"><input type="checkbox" name="autoPostOnApprove" <?= $ch['autoPostOnApprove'] ? 'checked' : '' ?>> ارسال خودکار به کانال هنگام تایید آگهی</label>

    <button type="submit" class="btn-gold w-full py-3.5 rounded-2xl text-sm mt-3">ذخیره تنظیمات</button>
  </form>
</div>
