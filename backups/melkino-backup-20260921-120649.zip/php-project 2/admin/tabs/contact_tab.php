<?php
$c = contactSettings();
?>
<div class="adm-card p-5" style="max-width:560px">
  <h3 class="font-black text-[16px] mb-4" style="color:var(--text-primary)">📞 اطلاعات تماس</h3>
  <?php if (isset($_GET['ok'])): ?><div class="badge badge-success mb-3">ذخیره شد</div><?php endif; ?>
  <form method="post" action="settings_save.php" class="space-y-3">
    <input type="hidden" name="settings_key" value="contact">
    <input type="hidden" name="back_tab" value="contact">
    <div class="row-half">
      <div class="form-group"><label>تلفن ثابت</label><input class="form-input" dir="ltr" name="phone" value="<?= e($c['phone']) ?>"></div>
      <div class="form-group"><label>موبایل</label><input class="form-input" dir="ltr" name="mobile" value="<?= e($c['mobile']) ?>"></div>
    </div>
    <div class="row-half">
      <div class="form-group"><label>واتساپ</label><input class="form-input" dir="ltr" name="whatsapp" value="<?= e($c['whatsapp']) ?>"></div>
      <div class="form-group"><label>ایمیل</label><input class="form-input" dir="ltr" name="email" value="<?= e($c['email']) ?>"></div>
    </div>
    <div class="form-group"><label>آدرس</label><textarea class="form-textarea" name="address" rows="2"><?= e($c['address']) ?></textarea></div>
    <div class="form-group"><label>ساعات کاری</label><input class="form-input" name="hours" value="<?= e($c['hours']) ?>"></div>
    <div class="form-group"><label>لینک نقشه (Google Maps)</label><input class="form-input" dir="ltr" name="mapUrl" value="<?= e($c['mapUrl']) ?>"></div>
    <button type="submit" class="btn-gold w-full py-3.5 rounded-2xl text-sm mt-3">ذخیره تنظیمات</button>
  </form>
</div>
