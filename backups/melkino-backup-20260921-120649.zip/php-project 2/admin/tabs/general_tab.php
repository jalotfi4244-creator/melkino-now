<?php
$g = generalSettings();
?>
<div class="adm-card p-5" style="max-width:560px">
  <h3 class="font-black text-[16px] mb-4" style="color:var(--text-primary)">🧩 تنظیمات عمومی سایت</h3>
  <?php if (isset($_GET['ok'])): ?><div class="badge badge-success mb-3">ذخیره شد</div><?php endif; ?>
  <form method="post" action="settings_save.php" enctype="multipart/form-data" class="space-y-3">
    <input type="hidden" name="settings_key" value="general">
    <input type="hidden" name="back_tab" value="general">
    <div class="row-half">
      <div class="form-group"><label>نام سایت</label><input class="form-input" name="siteName" value="<?= e($g['siteName']) ?>"></div>
      <div class="form-group"><label>شعار (تگ‌لاین)</label><input class="form-input" name="tagline" value="<?= e($g['tagline']) ?>"></div>
    </div>
    <div class="form-group"><label>حرف لوگو (وقتی تصویر آپلود نشده)</label><input class="form-input" name="logoLetter" value="<?= e($g['logoLetter']) ?>" maxlength="2" style="width:80px"></div>
    <div class="form-group">
      <label>آپلود لوگو</label>
      <?php if (!empty($g['logoUrl'])): ?><img src="<?= e(propertyImageUrl($g['logoUrl'])) ?>" style="width:64px;height:64px;object-fit:contain;margin-bottom:8px;border-radius:12px;background:var(--bg-secondary)"><?php endif; ?>
      <input type="file" name="logo" accept="image/*" class="form-input">
    </div>
    <label class="amen-check"><input type="checkbox" name="logoInHeader" <?= $g['logoInHeader'] ? 'checked' : '' ?>> نمایش لوگو در هدر</label>
    <label class="amen-check"><input type="checkbox" name="autoPublish" <?= $g['autoPublish'] ? 'checked' : '' ?>> انتشار خودکار آگهی‌های جدید (بدون تایید ادمین)</label>
    <label class="amen-check"><input type="checkbox" name="showVipOnHome" <?= $g['showVipOnHome'] ? 'checked' : '' ?>> نمایش فایل‌های VIP در صفحه اصلی</label>
    <button type="submit" class="btn-gold w-full py-3.5 rounded-2xl text-sm mt-3">ذخیره تنظیمات</button>
  </form>
</div>
