<?php ?>
<div class="adm-card p-5" style="max-width:440px">
  <h3 class="font-black text-[16px] mb-4" style="color:var(--text-primary)">🔑 تغییر رمز عبور پنل</h3>
  <?php if (isset($_GET['ok'])): ?><div class="badge badge-success mb-3">رمز عبور تغییر کرد</div><?php endif; ?>
  <?php if (isset($_GET['error'])): ?><div class="badge badge-danger mb-3"><?= e($_GET['error']) ?></div><?php endif; ?>
  <form method="post" action="password_save.php" class="space-y-3">
    <div class="form-group"><label>رمز فعلی</label><input type="password" class="form-input" name="current" dir="ltr" required></div>
    <div class="form-group"><label>رمز جدید</label><input type="password" class="form-input" name="new1" dir="ltr" minlength="4" required></div>
    <div class="form-group"><label>تکرار رمز جدید</label><input type="password" class="form-input" name="new2" dir="ltr" minlength="4" required></div>
    <button type="submit" class="btn-gold w-full py-3.5 rounded-2xl text-sm mt-3">تغییر رمز عبور</button>
  </form>
</div>
