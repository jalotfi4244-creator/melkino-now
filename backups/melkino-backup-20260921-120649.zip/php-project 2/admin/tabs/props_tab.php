<?php
/** داخل admin/index.php اینکلود می‌شود */
$pStatus = $_GET['pstatus'] ?? 'all';
$pq = trim($_GET['pq'] ?? '');
$where = [];
$params = [];
if ($pStatus !== 'all') { $where[] = 'status = ?'; $params[] = $pStatus; }
if ($pq !== '') { $where[] = '(title LIKE ? OR code LIKE ? OR neighborhood LIKE ?)'; $qv = "%$pq%"; array_push($params, $qv, $qv, $qv); }
$whereSql = $where ? ('WHERE ' . implode(' AND ', $where)) : '';
$stmt = db()->prepare("SELECT * FROM properties $whereSql ORDER BY created_at DESC LIMIT 60");
$stmt->execute($params);
$plist = $stmt->fetchAll();
$statusLabels = STATUS_LABELS();
$dealBadge = DEAL_BADGE();
?>
<div class="adm-card p-5">
  <div class="flex items-center justify-between mb-4 flex-wrap gap-2">
    <h3 class="font-black text-[16px]" style="color:var(--text-primary)">مدیریت آگهی‌ها (<?= toFaDigits(count($plist)) ?>)</h3>
    <form method="get" class="flex gap-2">
      <input type="hidden" name="tab" value="props">
      <input type="text" name="pq" value="<?= e($pq) ?>" placeholder="جستجو عنوان/کد/محله" class="form-input" style="width:200px;padding:8px 12px;font-size:12.5px">
      <select name="pstatus" onchange="this.form.submit()" class="form-select" style="width:auto;font-size:12.5px">
        <option value="all" <?= $pStatus === 'all' ? 'selected' : '' ?>>همه وضعیت‌ها</option>
        <?php foreach ($statusLabels as $k => $v): ?>
          <option value="<?= $k ?>" <?= $pStatus === $k ? 'selected' : '' ?>><?= e($v) ?></option>
        <?php endforeach; ?>
      </select>
      <button class="option-btn" style="padding:8px 16px">فیلتر</button>
    </form>
  </div>

  <?php if (empty($plist)): ?>
    <div class="text-center py-10" style="color:var(--text-muted)">آگهی‌ای یافت نشد</div>
  <?php endif; ?>

  <div class="space-y-2.5">
    <?php foreach ($plist as $p): $imgs = j_decode($p['images'], []); ?>
      <div class="card p-3 flex items-center gap-3">
        <?php if (!empty($imgs[0])): ?>
          <img src="<?= e(propertyImageUrl($imgs[0])) ?>" style="width:60px;height:60px;border-radius:12px;object-fit:cover;flex-shrink:0">
        <?php else: ?>
          <div style="width:60px;height:60px;border-radius:12px;background:var(--bg-secondary);flex-shrink:0;display:flex;align-items:center;justify-content:center">🏠</div>
        <?php endif; ?>
        <div class="flex-1 min-w-0">
          <div class="font-extrabold text-[13.5px] truncate" style="color:var(--text-primary)"><?= e($p['title']) ?></div>
          <div class="text-[11px] mt-0.5" style="color:var(--text-muted)">
            <span class="font-mono" dir="ltr"><?= e($p['code']) ?></span> • <?= e($dealBadge[$p['deal_type']] ?? $p['deal_type']) ?> • <?= toFaDigits($p['views']) ?> بازدید
          </div>
          <div class="flex items-center gap-1.5 mt-1.5 flex-wrap">
            <span class="badge <?= $p['status'] === 'available' ? 'badge-success' : ($p['status'] === 'rejected' ? 'badge-danger' : 'badge-warning') ?>"><?= e($statusLabels[$p['status']] ?? $p['status']) ?></span>
            <?php if ($p['vip']): ?><span class="badge badge-gold">VIP</span><?php endif; ?>
            <?php if ($p['featured']): ?><span class="badge badge-primary">ویژه</span><?php endif; ?>
          </div>
        </div>
        <div class="flex flex-col gap-1.5 flex-shrink-0" style="min-width:96px">
          <?php if ($p['status'] !== 'available'): ?>
            <a href="property_action.php?id=<?= (int)$p['id'] ?>&do=approve&<?= http_build_query(['pstatus'=>$pStatus,'pq'=>$pq]) ?>" class="option-btn" style="padding:5px 10px;font-size:11.5px">✔ تایید</a>
          <?php endif; ?>
          <?php if ($p['status'] !== 'rejected'): ?>
            <a href="property_action.php?id=<?= (int)$p['id'] ?>&do=reject&<?= http_build_query(['pstatus'=>$pStatus,'pq'=>$pq]) ?>" class="option-btn" style="padding:5px 10px;font-size:11.5px">✕ رد</a>
          <?php endif; ?>
          <a href="property_edit.php?id=<?= (int)$p['id'] ?>" class="option-btn" style="padding:5px 10px;font-size:11.5px">ویرایش</a>
          <a href="property_action.php?id=<?= (int)$p['id'] ?>&do=vip&<?= http_build_query(['pstatus'=>$pStatus,'pq'=>$pq]) ?>" class="option-btn" style="padding:5px 10px;font-size:11.5px"><?= $p['vip'] ? 'حذف VIP' : 'VIP کن' ?></a>
          <a href="property_action.php?id=<?= (int)$p['id'] ?>&do=delete&<?= http_build_query(['pstatus'=>$pStatus,'pq'=>$pq]) ?>" onclick="return confirm('حذف این آگهی؟')" class="option-btn" style="padding:5px 10px;font-size:11.5px;color:var(--danger)">حذف</a>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
</div>
