<?php
$rStatus = $_GET['rstatus'] ?? 'all';
$where = $rStatus !== 'all' ? 'WHERE status = ?' : '';
$stmt = db()->prepare("SELECT * FROM requests $where ORDER BY created_at DESC LIMIT 60");
$stmt->execute($rStatus !== 'all' ? [$rStatus] : []);
$rlist = $stmt->fetchAll();
$REQ_STATUS = ['new' => 'جدید', 'inprogress' => 'در حال پیگیری', 'contacted' => 'تماس گرفته شد', 'done' => 'انجام شد', 'closed' => 'بسته شد'];
$dealTypes = DEAL_TYPES();
$propertyTypes = PROPERTY_TYPES();
?>
<div class="adm-card p-5">
  <div class="flex items-center justify-between mb-4 flex-wrap gap-2">
    <h3 class="font-black text-[16px]" style="color:var(--text-primary)">مدیریت درخواست‌ها (<?= toFaDigits(count($rlist)) ?>)</h3>
    <form method="get" class="flex gap-2">
      <input type="hidden" name="tab" value="reqs">
      <select name="rstatus" onchange="this.form.submit()" class="form-select" style="width:auto;font-size:12.5px">
        <option value="all" <?= $rStatus === 'all' ? 'selected' : '' ?>>همه وضعیت‌ها</option>
        <?php foreach ($REQ_STATUS as $k => $v): ?><option value="<?= $k ?>" <?= $rStatus === $k ? 'selected' : '' ?>><?= e($v) ?></option><?php endforeach; ?>
      </select>
    </form>
  </div>

  <?php if (empty($rlist)): ?>
    <div class="text-center py-10" style="color:var(--text-muted)">درخواستی یافت نشد</div>
  <?php endif; ?>

  <div class="space-y-2.5">
    <?php foreach ($rlist as $r): ?>
      <div class="card p-3.5">
        <div class="flex items-center justify-between gap-2 flex-wrap">
          <div class="font-extrabold text-[13px]" style="color:var(--text-primary)">
            <span class="font-mono text-[11px]" dir="ltr" style="color:var(--primary)"><?= e($r['code'] ?: ('REQ-' . $r['id'])) ?></span>
            • <?= e($r['name']) ?> • <span dir="ltr"><?= toFaDigits($r['phone']) ?></span>
          </div>
          <form method="post" action="request_status.php" class="flex items-center gap-1.5">
            <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
            <input type="hidden" name="rstatus" value="<?= e($rStatus) ?>">
            <select name="status" onchange="this.form.submit()" class="form-select" style="width:auto;font-size:11.5px;padding:6px 10px">
              <?php foreach ($REQ_STATUS as $k => $v): ?><option value="<?= $k ?>" <?= $r['status'] === $k ? 'selected' : '' ?>><?= e($v) ?></option><?php endforeach; ?>
            </select>
          </form>
        </div>
        <div class="text-[11.5px] mt-1.5" style="color:var(--text-muted)">
          <?= $r['deal_type'] === 'invest' ? 'سرمایه‌گذاری' : e($dealTypes[$r['deal_type']] ?? $r['deal_type']) ?>
          • <?= $r['no_priority'] ? 'همه انواع' : e($propertyTypes[$r['property_type']] ?? $r['property_type']) ?>
          <?= $r['location'] ? '• 📍 ' . e($r['location']) : '' ?>
          • فوریت <?= e($r['urgency']) ?>
        </div>
        <?php if ((float)$r['max_price'] > 0 || (float)$r['max_rent'] > 0): ?>
          <div class="text-[11.5px] mt-1" style="color:var(--text-secondary)">
            <?= (float)$r['max_price'] > 0 ? 'بودجه تا ' . formatToman($r['max_price']) : '' ?>
            <?= (float)$r['max_rent'] > 0 ? 'اجاره تا ' . formatToman($r['max_rent']) : '' ?>
          </div>
        <?php endif; ?>
        <?php if (!empty($r['description'])): ?>
          <div class="text-[11.5px] mt-1.5 rounded-xl p-2.5" style="background:var(--surface-soft);color:var(--text-secondary)"><?= e($r['description']) ?></div>
        <?php endif; ?>
      </div>
    <?php endforeach; ?>
  </div>
</div>
