<?php
$s = socialSettings();
?>
<div class="adm-card p-5" style="max-width:560px">
  <h3 class="font-black text-[16px] mb-4" style="color:var(--text-primary)">🌐 شبکه‌های اجتماعی</h3>
  <?php if (isset($_GET['ok'])): ?><div class="badge badge-success mb-3">ذخیره شد</div><?php endif; ?>
  <form method="post" action="settings_save.php" class="space-y-3">
    <input type="hidden" name="settings_key" value="social">
    <input type="hidden" name="back_tab" value="social">
    <div class="form-group"><label>عنوان بخش</label><input class="form-input" name="title" value="<?= e($s['title']) ?>"></div>
    <div class="row-half">
      <div class="form-group"><label>تلگرام</label><input class="form-input" dir="ltr" name="telegram" value="<?= e($s['telegram']) ?>" placeholder="https://t.me/..."></div>
      <div class="form-group"><label>اینستاگرام</label><input class="form-input" dir="ltr" name="instagram" value="<?= e($s['instagram']) ?>" placeholder="https://instagram.com/..."></div>
    </div>
    <div class="row-half">
      <div class="form-group"><label>بله</label><input class="form-input" dir="ltr" name="bale" value="<?= e($s['bale']) ?>"></div>
      <div class="form-group"><label>ایتا</label><input class="form-input" dir="ltr" name="eitaa" value="<?= e($s['eitaa']) ?>"></div>
    </div>
    <div class="form-group"><label>واتساپ</label><input class="form-input" dir="ltr" name="whatsapp" value="<?= e($s['whatsapp']) ?>"></div>
    <label class="amen-check"><input type="checkbox" name="showInContact" <?= $s['showInContact'] ? 'checked' : '' ?>> نمایش در صفحه تماس با ما</label>
    <label class="amen-check"><input type="checkbox" name="showInProfile" <?= $s['showInProfile'] ? 'checked' : '' ?>> نمایش در پروفایل کاربر</label>
    <button type="submit" class="btn-gold w-full py-3.5 rounded-2xl text-sm mt-3">ذخیره تنظیمات</button>
  </form>
</div>
