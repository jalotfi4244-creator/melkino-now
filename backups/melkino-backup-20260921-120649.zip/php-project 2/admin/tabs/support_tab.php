<?php
$mlist = db()->query('SELECT * FROM messages ORDER BY created_at DESC LIMIT 50')->fetchAll();
$msgStatus = ['new' => 'جدید', 'read' => 'خوانده شد', 'answered' => 'پاسخ داده شد', 'archived' => 'بایگانی'];
?>
<div class="adm-card p-5">
  <h3 class="font-black text-[16px] mb-4" style="color:var(--text-primary)">🎧 پیام‌های پشتیبانی (<?= toFaDigits(count($mlist)) ?>)</h3>
  <?php if (empty($mlist)): ?>
    <div class="text-center py-10" style="color:var(--text-muted)">پیامی دریافت نشده است</div>
  <?php endif; ?>
  <div class="space-y-2.5">
    <?php foreach ($mlist as $m): ?>
      <div class="card p-3.5">
        <div class="flex items-center justify-between gap-2 flex-wrap">
          <div class="font-extrabold text-[13px]" style="color:var(--text-primary)"><?= e($m['name']) ?> <span class="font-normal" dir="ltr" style="color:var(--text-muted)">• <?= toFaDigits($m['phone']) ?></span></div>
          <form method="post" action="message_status.php" class="flex items-center gap-1.5">
            <input type="hidden" name="id" value="<?= (int)$m['id'] ?>">
            <select name="status" onchange="this.form.submit()" class="form-select" style="width:auto;font-size:11.5px;padding:6px 10px">
              <?php foreach ($msgStatus as $k => $v): ?><option value="<?= $k ?>" <?= $m['status'] === $k ? 'selected' : '' ?>><?= e($v) ?></option><?php endforeach; ?>
            </select>
          </form>
        </div>
        <?php if (!empty($m['subject'])): ?><div class="text-[12px] font-bold mt-1" style="color:var(--text-secondary)"><?= e($m['subject']) ?></div><?php endif; ?>
        <div class="text-[12px] mt-1.5 rounded-xl p-2.5 leading-6" style="background:var(--surface-soft);color:var(--text-secondary)"><?= nl2br(e($m['message'])) ?></div>
        <div class="text-[10.5px] mt-1.5" style="color:var(--text-muted)"><?= e($m['type']) ?> • <?= toFaDigits(date('Y/m/d H:i', strtotime($m['created_at']))) ?></div>
      </div>
    <?php endforeach; ?>
  </div>
</div>
