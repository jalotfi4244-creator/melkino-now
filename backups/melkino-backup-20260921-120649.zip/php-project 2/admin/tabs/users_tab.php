<?php
$ulist = db()->query('SELECT * FROM app_users ORDER BY last_login DESC LIMIT 60')->fetchAll();
$platformLabel = ['telegram' => '📨 تلگرام', 'bale' => '💬 بله', 'web' => '🌐 وب'];
?>
<div class="adm-card p-5">
  <h3 class="font-black text-[16px] mb-4" style="color:var(--text-primary)">کاربران اپ (<?= toFaDigits(count($ulist)) ?>)</h3>
  <?php if (empty($ulist)): ?>
    <div class="text-center py-10" style="color:var(--text-muted)">هنوز کاربری ثبت نشده است</div>
  <?php endif; ?>
  <div class="space-y-2">
    <?php foreach ($ulist as $u): ?>
      <div class="card p-3 flex items-center gap-3">
        <div style="width:44px;height:44px;border-radius:12px;background:var(--bg-secondary);flex-shrink:0;display:flex;align-items:center;justify-content:center;font-weight:900;color:var(--primary)">
          <?= e(mb_substr($u['name'] ?: 'م', 0, 1)) ?>
        </div>
        <div class="flex-1 min-w-0">
          <div class="font-extrabold text-[13px] truncate" style="color:var(--text-primary)"><?= e($u['name'] ?: 'بدون نام') ?></div>
          <div class="text-[11px] mt-0.5" style="color:var(--text-muted)" dir="ltr">
            <?= e($u['phone'] ?: '—') ?> • <?= $platformLabel[$u['platform']] ?? $u['platform'] ?> • <?= toFaDigits($u['login_count']) ?> ورود
          </div>
        </div>
        <span class="badge <?= $u['status'] === 'blocked' ? 'badge-danger' : 'badge-success' ?>"><?= $u['status'] === 'blocked' ? 'مسدود' : 'فعال' ?></span>
        <a href="user_action.php?id=<?= (int)$u['id'] ?>&do=<?= $u['status'] === 'blocked' ? 'unblock' : 'block' ?>" class="option-btn" style="padding:6px 12px;font-size:11.5px"><?= $u['status'] === 'blocked' ? 'رفع مسدودی' : 'مسدود کن' ?></a>
      </div>
    <?php endforeach; ?>
  </div>
</div>
