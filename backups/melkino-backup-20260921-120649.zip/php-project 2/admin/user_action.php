<?php
require_once __DIR__ . '/../includes/auth.php';
requireAdmin();

$id = (int)($_GET['id'] ?? 0);
$do = $_GET['do'] ?? '';
if ($id > 0 && in_array($do, ['block', 'unblock'])) {
  db()->prepare('UPDATE app_users SET status = ? WHERE id = ?')->execute([$do === 'block' ? 'blocked' : 'active', $id]);
}
header('Location: index.php?tab=users');
exit;
