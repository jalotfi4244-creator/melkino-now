<?php
require_once __DIR__ . '/includes/user_auth.php';
destroyUserSession();
header('Location: ' . SITE_URL . '/home.php');
exit;
