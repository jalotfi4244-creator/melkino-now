<?php
/**
 * تنظیمات اتصال به دیتابیس ملکینو
 * این مقادیر را متناسب با هاست خودتان تغییر بدهید.
 */
define('DB_HOST', 'localhost');
define('DB_NAME', 'melkino');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

/** آدرس پایه سایت (بدون / انتهایی) — برای ساخت لینک تصاویر و ... */
define('SITE_URL', 'http://localhost/melkino');

/** پوشه آپلودها نسبت به ریشه پروژه */
define('UPLOADS_DIR', __DIR__ . '/uploads');
define('UPLOADS_URL', SITE_URL . '/uploads');

/** رمز عبور پیش‌فرض پنل مدیریت (همان مقدار پروژه اصلی Next.js) */
define('DEFAULT_ADMIN_PASSWORD', 'melkinoAdmin');

date_default_timezone_set('Asia/Tehran');
session_start();
