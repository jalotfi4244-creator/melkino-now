<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/cards.php';

$idsParam = $_GET['ids'] ?? '';
$ids = array_filter(array_map('intval', explode(',', $idsParam)));

if (empty($ids)) { exit; }

$placeholders = implode(',', array_fill(0, count($ids), '?'));
$stmt = db()->prepare("SELECT * FROM properties WHERE id IN ($placeholders)");
$stmt->execute(array_values($ids));
$items = $stmt->fetchAll();

// حفظ ترتیب همان چیزی که در localStorage است
$byId = [];
foreach ($items as $it) { $byId[(int)$it['id']] = $it; }
$ordered = [];
foreach ($ids as $id) { if (isset($byId[$id])) $ordered[] = $byId[$id]; }

if (empty($ordered)) {
  echo '<div class="card p-6 text-center" style="color:var(--text-muted)">ملک‌های ذخیره‌شده دیگر موجود نیستند</div>';
  exit;
}
?>
<div class="text-[12px] font-bold mb-3" style="color:var(--text-secondary)"><?= toFaDigits(count($ordered)) ?> ملک ذخیره شده</div>
<div class="space-y-3.5">
  <?php foreach ($ordered as $p) renderPropertyCard($p); ?>
</div>
