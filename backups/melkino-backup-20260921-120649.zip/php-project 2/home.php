<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/ads.php';
require_once __DIR__ . '/includes/cards.php';

$pageTitle = generalSettings()['siteName'] . ' | خانه';
$activeNav = 'home';

// آگهی‌های منتشرشده (جدیدترین‌ها) — معادل fetch("/api/properties?limit=10&sort=newest")
$stmt = db()->prepare("SELECT * FROM properties WHERE status = 'available' ORDER BY created_at DESC LIMIT 10");
$stmt->execute();
$properties = $stmt->fetchAll();

$totalStmt = db()->query("SELECT COUNT(*) c FROM properties WHERE status = 'available'");
$total = (int)$totalStmt->fetch()['c'];

// تبلیغات فعال + ترکیب با فهرست آگهی‌ها
$ads = getActiveAds();
$feed = buildHomeFeed($properties, $ads);

require __DIR__ . '/includes/layout_head.php';
?>
<div class="px-4 pt-4">
  <!-- hero -->
  <div class="rounded-[26px] p-5 relative overflow-hidden mb-4" style="background:linear-gradient(145deg,var(--mk-dark-a,#073737),var(--mk-dark-b,#052D2D) 45%,var(--mk-dark-c,#031D1D));box-shadow:0 12px 32px color-mix(in srgb, var(--primary) 30%, transparent)">
    <div class="relative">
      <div class="flex items-center gap-1.5 text-[12px] font-bold mb-1.5" style="color:var(--gold-light)">✨ اولین پلتفرم ملکی شاهرود</div>
      <h1 class="text-white font-black text-[22px] leading-9">انتخابی فراتر <span class="gold-text">از یک ملک</span></h1>
      <p class="text-[13px] mt-1.5 leading-6" style="color:rgba(255,255,255,.65)">جایی برای پیدا کردن، معرفی و انتخاب ملک مناسب</p>
      <div class="grid grid-cols-2 gap-2 mt-4">
        <a href="<?= SITE_URL ?>/sell.php" class="btn-gold py-3 rounded-2xl text-[13px] text-center">✦ ثبت ملک</a>
        <a href="<?= SITE_URL ?>/request.php" class="py-3 rounded-2xl text-[13px] text-center font-extrabold text-white" style="border:1.5px solid color-mix(in srgb, var(--gold) 55%, transparent)">📩 ثبت درخواست</a>
      </div>
    </div>
  </div>

  <!-- quick actions -->
  <div class="grid grid-cols-3 gap-2.5 mb-5">
    <?php
    $actions = [
      ['href' => 'sell.php', 'icon' => '🏠', 'label' => 'ثبت ملک', 'desc' => 'فروش یا اجاره ملک شما', 'gold' => true],
      ['href' => 'request.php', 'icon' => '📄', 'label' => 'ثبت درخواست', 'desc' => 'ملک دلخواهت را پیدا کن', 'gold' => true],
      ['href' => 'search.php', 'icon' => '🔍', 'label' => 'جستجو', 'desc' => 'جستجوی پیشرفته ملک', 'gold' => false],
      ['href' => 'properties.php', 'icon' => '🗂️', 'label' => 'همه آگهی‌ها', 'desc' => 'مشاهده همه فایل‌ها', 'gold' => false],
      ['href' => 'vip.php', 'icon' => '👑', 'label' => 'فایل‌های VIP', 'desc' => 'منتخب لوکس ملکینو', 'gold' => false],
      ['href' => 'contact.php', 'icon' => '📞', 'label' => 'ارتباط با ما', 'desc' => 'مشاوره رایگان', 'gold' => false],
    ];
    foreach ($actions as $a):
      $iconStyle = $a['gold']
        ? 'background:linear-gradient(135deg,var(--gold-light),var(--gold));color:#1a1405;box-shadow:0 6px 16px color-mix(in srgb, var(--gold) 40%, transparent)'
        : 'background:color-mix(in srgb, var(--primary-light) 12%, transparent);color:var(--primary)';
    ?>
      <a href="<?= SITE_URL ?>/<?= e($a['href']) ?>" class="card p-3.5 text-center transition-all hover:-translate-y-0.5" style="text-decoration:none">
        <div class="w-11 h-11 mx-auto rounded-2xl flex items-center justify-center mb-2" style="<?= $iconStyle ?>"><?= $a['icon'] ?></div>
        <div class="font-extrabold text-[12.5px]" style="color:var(--text-primary)"><?= e($a['label']) ?></div>
        <div class="text-[10px] mt-0.5 leading-4" style="color:var(--text-muted)"><?= e($a['desc']) ?></div>
      </a>
    <?php endforeach; ?>
  </div>

  <!-- published ads (آگهی‌های منتشرشده) -->
  <div class="flex items-center justify-between mb-3">
    <h2 class="font-black text-[16px] flex items-center gap-2" style="color:var(--text-primary)">
      <span class="w-1.5 h-8 rounded-full" style="background:linear-gradient(180deg,var(--gold-light),var(--gold-dark))"></span>
      آگهی‌های منتشر شده
      <span class="badge badge-gold"><?= toFaDigits($total) ?> آگهی</span>
    </h2>
    <a href="<?= SITE_URL ?>/properties.php" class="flex items-center gap-0.5 text-[12px] font-extrabold" style="color:var(--primary)">همه ←</a>
  </div>

  <div class="space-y-3.5">
    <?php if (empty($feed)): ?>
      <div class="card h-72 flex items-center justify-center" style="color:var(--text-muted)">هنوز آگهی‌ای منتشر نشده است</div>
    <?php endif; ?>
    <?php foreach ($feed as $item): ?>
      <?php if ($item['type'] === 'property'): ?>
        <?php renderPropertyCard($item['data']); ?>
      <?php else: ?>
        <?php renderAdCard($item['data']); ?>
      <?php endif; ?>
    <?php endforeach; ?>
  </div>

  <a href="<?= SITE_URL ?>/properties.php" class="btn-secondary w-full py-3.5 rounded-2xl text-sm mt-4 flex items-center justify-center gap-1.5" style="text-decoration:none">
    مشاهده همه آگهی‌ها ←
  </a>
  <div class="h-2"></div>
</div>
<?php require __DIR__ . '/includes/layout_foot.php'; ?>
