<?php
require_once __DIR__ . '/db.php';

/**
 * قابلیت تبلیغات بین کارت‌های صفحه اصلی
 * هر تبلیغ دارای:
 *   position      → بعد از چندمین کارت آگهی، اولین‌بار نمایش داده شود (۱-پایه)
 *   repeat_every  → اگر بزرگ‌تر از صفر باشد، تبلیغ هر n کارت یک‌بار تکرار می‌شود
 *   sort_order    → ترتیب نمایش وقتی چند تبلیغ هم‌زمان روی یک موقعیت بیفتند
 */

function getAllAds(): array {
  return db()->query('SELECT * FROM ads ORDER BY sort_order ASC, id DESC')->fetchAll();
}

function getActiveAds(): array {
  $now = date('Y-m-d H:i:s');
  $stmt = db()->prepare(
    'SELECT * FROM ads
     WHERE active = 1
       AND (starts_at IS NULL OR starts_at <= ?)
       AND (ends_at IS NULL OR ends_at >= ?)
     ORDER BY sort_order ASC, id ASC'
  );
  $stmt->execute([$now, $now]);
  return $stmt->fetchAll();
}

function getAd(int $id): ?array {
  $stmt = db()->prepare('SELECT * FROM ads WHERE id = ?');
  $stmt->execute([$id]);
  $row = $stmt->fetch();
  return $row ?: null;
}

function saveAd(array $data, ?int $id = null): int {
  $fields = [
    'title' => $data['title'] ?? '',
    'description' => $data['description'] ?? '',
    'image' => $data['image'] ?? null,
    'link_url' => $data['link_url'] ?? '',
    'badge_text' => $data['badge_text'] ?: 'تبلیغات',
    'position' => max(1, (int)($data['position'] ?? 3)),
    'repeat_every' => max(0, (int)($data['repeat_every'] ?? 0)),
    'sort_order' => (int)($data['sort_order'] ?? 0),
    'active' => !empty($data['active']) ? 1 : 0,
  ];
  if ($id) {
    $sql = 'UPDATE ads SET title=?, description=?, image=?, link_url=?, badge_text=?, position=?, repeat_every=?, sort_order=?, active=? WHERE id=?';
    db()->prepare($sql)->execute([...array_values($fields), $id]);
    return $id;
  }
  $sql = 'INSERT INTO ads (title, description, image, link_url, badge_text, position, repeat_every, sort_order, active)
          VALUES (?,?,?,?,?,?,?,?,?)';
  db()->prepare($sql)->execute(array_values($fields));
  return (int)db()->lastInsertId();
}

function deleteAd(int $id): void {
  $ad = getAd($id);
  if ($ad && !empty($ad['image'])) {
    $path = UPLOADS_DIR . '/ads/' . basename($ad['image']);
    if (is_file($path)) @unlink($path);
  }
  db()->prepare('DELETE FROM ads WHERE id = ?')->execute([$id]);
}

function toggleAd(int $id): void {
  db()->prepare('UPDATE ads SET active = 1 - active WHERE id = ?')->execute([$id]);
}

function recordAdView(int $id): void {
  db()->prepare('UPDATE ads SET views = views + 1 WHERE id = ?')->execute([$id]);
}

function recordAdClick(int $id): void {
  db()->prepare('UPDATE ads SET clicks = clicks + 1 WHERE id = ?')->execute([$id]);
}

/**
 * ترکیب فهرست آگهی‌ها با تبلیغات فعال بر اساس موقعیت تعریف‌شده
 * خروجی: آرایه‌ای از آیتم‌ها به شکل ['type' => 'property'|'ad', 'data' => ...]
 */
function buildHomeFeed(array $properties, array $ads): array {
  $feed = [];
  foreach ($properties as $i => $p) {
    $feed[] = ['type' => 'property', 'data' => $p];
    $cardNumber = $i + 1; // ۱-پایه
    foreach ($ads as $ad) {
      $pos = (int)$ad['position'];
      $repeat = (int)$ad['repeat_every'];
      $show = false;
      if ($cardNumber === $pos) {
        $show = true;
      } elseif ($repeat > 0 && $cardNumber > $pos && ($cardNumber - $pos) % $repeat === 0) {
        $show = true;
      }
      if ($show) {
        $feed[] = ['type' => 'ad', 'data' => $ad];
        recordAdView((int)$ad['id']);
      }
    }
  }
  return $feed;
}
