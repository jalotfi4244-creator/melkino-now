<?php
require_once __DIR__ . '/functions.php';

/**
 * احراز هویت پنل مدیریت — معادل src/lib/admin-auth.ts
 * رمز عبور پیش‌فرض: melkinoAdmin (قابل تغییر از بخش «تغییر رمز»)
 */

function hashAdminPassword(string $plain): string {
  return hash('sha256', 'melkino-admin-salt:' . $plain);
}

function getAdminHash(): string {
  $stmt = db()->prepare('SELECT value FROM settings WHERE `key` = ?');
  $stmt->execute(['admin_password_hash']);
  $row = $stmt->fetch();
  if ($row && $row['value']) {
    $v = j_decode($row['value'], null);
    if (is_string($v) && $v !== '') return $v;
    // در صورتی که به‌صورت رشته خام (بدون json) ذخیره شده باشد
    $raw = trim($row['value'], '"');
    if ($raw) return $raw;
  }
  return hashAdminPassword(DEFAULT_ADMIN_PASSWORD);
}

function setAdminHash(string $hash): void {
  setSetting('admin_password_hash', $hash);
}

function checkAdminPassword(string $plain): bool {
  return hashAdminPassword($plain) === getAdminHash();
}

function isAdmin(): bool {
  return !empty($_SESSION['is_admin']);
}

function requireAdmin(): void {
  if (!isAdmin()) {
    header('Location: ' . rtrim(dirname($_SERVER['SCRIPT_NAME']), '/') . '/login.php');
    exit;
  }
}

function adminLogin(string $plain): bool {
  if (checkAdminPassword($plain)) {
    $_SESSION['is_admin'] = true;
    session_regenerate_id(true);
    return true;
  }
  return false;
}

function adminLogout(): void {
  unset($_SESSION['is_admin']);
}
