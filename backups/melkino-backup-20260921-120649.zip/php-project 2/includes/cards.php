<?php
require_once __DIR__ . '/functions.php';

/**
 * رندر کارت آگهی — دقیقاً معادل src/components/PropertyCard.tsx
 */
function renderPropertyCard(array $p): void {
  $types = PROPERTY_TYPES();
  $dealBadge = DEAL_BADGE();
  $images = j_decode($p['images'] ?? null, []);
  $img = $images[0] ?? '';
  $imgUrl = propertyImageUrl($img);
  $title = e($p['title']);
  $code = e($p['code']);
  $area = (int)($p['area'] ?? 0);
  $rooms = (int)($p['rooms'] ?? 0);
  ?>
  <a href="<?= SITE_URL ?>/property.php?id=<?= (int)$p['id'] ?>" class="card overflow-hidden block transition-all hover:-translate-y-0.5" style="transition:box-shadow .2s, transform .2s; text-decoration:none">
    <div class="relative h-44 overflow-hidden">
      <?php if ($imgUrl): ?>
        <img src="<?= e($imgUrl) ?>" alt="<?= $title ?>" class="w-full h-full object-cover">
      <?php else: ?>
        <div class="w-full h-full flex items-center justify-center" style="background:var(--bg-secondary);color:var(--text-muted)">بدون تصویر</div>
      <?php endif; ?>
      <div class="absolute inset-0" style="background:linear-gradient(to top, rgba(0,0,0,.45), transparent 45%)"></div>
      <div class="absolute top-2.5 right-2.5 flex gap-1.5">
        <span class="badge" style="background:var(--primary);color:#fff">🏷️ <?= e($dealBadge[$p['deal_type']] ?? $p['deal_type']) ?></span>
        <?php if (!empty($p['vip'])): ?><span class="badge badge-gold">👑 VIP</span><?php endif; ?>
      </div>
      <div class="absolute bottom-2.5 right-2.5 flex items-center gap-1 text-[12px] font-bold text-white">
        📍 <?= e($p['neighborhood'] ?: ($p['city'] ?: 'شاهرود')) ?>
      </div>
      <div class="absolute bottom-2.5 left-2.5 text-[10px] text-white/80 font-mono" dir="ltr"><?= $code ?></div>
    </div>
    <div class="p-4">
      <h3 class="font-black text-[15px] leading-6 line-clamp-1" style="color:var(--text-primary)"><?= $title ?></h3>
      <div class="flex items-center gap-1.5 mt-2 flex-wrap">
        <span class="badge badge-primary"><?= e($types[$p['type']] ?? $p['type']) ?></span>
        <?php if ($area > 0): ?><span class="badge" style="background:var(--bg-secondary);color:var(--text-secondary)"><?= toFaDigits($area) ?> متر</span><?php endif; ?>
        <?php if ($rooms > 0): ?><span class="badge" style="background:var(--bg-secondary);color:var(--text-secondary)"><?= toFaDigits($rooms) ?> اتاق</span><?php endif; ?>
      </div>
      <div class="flex items-end justify-between mt-2.5 pt-2.5" style="border-top:1px solid var(--border-light)">
        <?php if ($p['deal_type'] === 'rent'): ?>
          <div class="space-y-0.5">
            <div class="font-black text-[13px]" style="color:var(--primary)">ودیعه: <?= formatToman($p['mortgage_price']) ?></div>
            <div class="font-black text-[13px]" style="color:var(--primary)">اجاره: <?= formatToman($p['rent_price']) ?></div>
          </div>
        <?php else: ?>
          <div class="font-black text-[14px]" style="color:var(--primary)"><?= formatToman($p['price']) ?></div>
        <?php endif; ?>
        <span class="text-[12px] font-bold" style="color:var(--gold-dark)">🔍 مشاهده جزئیات</span>
      </div>
    </div>
  </a>
  <?php
}

/**
 * رندر کارت تبلیغاتی — قابلیت جدید، هم‌راستا با استایل کارت آگهی
 */
function renderAdCard(array $ad): void {
  $imgUrl = propertyImageUrl($ad['image'] ?? null);
  $link = $ad['link_url'] ?: '#';
  $clickUrl = SITE_URL . '/ad_click.php?id=' . (int)$ad['id'] . '&to=' . urlencode($link);
  ?>
  <a href="<?= e($clickUrl) ?>" target="_blank" rel="noopener sponsored" class="card overflow-hidden block transition-all hover:-translate-y-0.5" style="text-decoration:none; border:1.5px solid color-mix(in srgb, var(--gold) 45%, transparent)">
    <?php if ($imgUrl): ?>
      <div class="relative h-44 overflow-hidden">
        <img src="<?= e($imgUrl) ?>" alt="<?= e($ad['title']) ?>" class="w-full h-full object-cover">
        <div class="absolute top-2.5 right-2.5">
          <span class="badge badge-gold">✦ <?= e($ad['badge_text'] ?: 'تبلیغات') ?></span>
        </div>
      </div>
    <?php endif; ?>
    <div class="p-4">
      <?php if (!$imgUrl): ?>
        <span class="badge badge-gold mb-2" style="display:inline-flex">✦ <?= e($ad['badge_text'] ?: 'تبلیغات') ?></span>
      <?php endif; ?>
      <h3 class="font-black text-[15px] leading-6" style="color:var(--text-primary)"><?= e($ad['title']) ?></h3>
      <?php if (!empty($ad['description'])): ?>
        <p class="text-[12.5px] mt-1.5 leading-6" style="color:var(--text-secondary)"><?= e($ad['description']) ?></p>
      <?php endif; ?>
      <div class="flex items-center justify-between mt-2.5 pt-2.5" style="border-top:1px solid var(--border-light)">
        <span class="text-[11px] font-bold" style="color:var(--text-muted)">تبلیغ</span>
        <span class="text-[12px] font-bold" style="color:var(--gold-dark)">مشاهده ←</span>
      </div>
    </div>
  </a>
  <?php
}
