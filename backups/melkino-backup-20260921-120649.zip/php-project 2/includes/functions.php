<?php
require_once __DIR__ . '/db.php';

/* ===================== اعداد فارسی ===================== */
function toFaDigits($input): string {
  $fa = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
  return preg_replace_callback('/[0-9]/', function ($m) use ($fa) {
    return $fa[(int)$m[0]];
  }, (string)$input);
}

function toEnDigits(string $input): string {
  $fa = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
  $ar = ['٠','١','٢','٣','٤','٥','٦','٧','٨','٩'];
  $input = str_replace($fa, ['0','1','2','3','4','5','6','7','8','9'], $input);
  $input = str_replace($ar, ['0','1','2','3','4','5','6','7','8','9'], $input);
  return $input;
}

/** قیمت کامل تومانی مثل سایت اصلی: ۷,۱۵۰,۰۰۰,۰۰۰ تومان */
function formatToman($n, bool $suffix = true): string {
  $n = (float)$n;
  if (!$n || $n <= 0) return 'توافقی';
  $grouped = number_format($n, 0);
  return toFaDigits($grouped) . ($suffix ? ' تومان' : '');
}

function formatPriceShort($n): string {
  $n = (float)$n;
  if (!$n || $n <= 0) return 'توافقی';
  if ($n >= 1_000_000_000) {
    $b = $n / 1_000_000_000;
    $b = (floor($b) == $b) ? (string)(int)$b : number_format($b, 1);
    return toFaDigits($b) . ' میلیارد';
  }
  if ($n >= 1_000_000) {
    $m = round($n / 1_000_000);
    return toFaDigits(number_format($m, 0)) . ' میلیون';
  }
  return toFaDigits(number_format($n, 0));
}

function formatNumber($n): string {
  if ($n === null) return '—';
  return toFaDigits(number_format((float)$n, 0));
}

/* ===================== طبقه‌بندی‌ها (مثل utils.ts) ===================== */
function PROPERTY_TYPES(): array {
  return [
    'apartment' => 'آپارتمان',
    'villa' => 'ویلا',
    'land' => 'زمین',
    'garden' => 'باغ',
    'office' => 'اداری',
    'commercial' => 'تجاری',
  ];
}

function DEAL_TYPES(): array {
  return [
    'sale' => 'خرید و فروش',
    'presale' => 'پیش فروش',
    'rent' => 'اجاره',
  ];
}

function DEAL_BADGE(): array {
  return [
    'sale' => 'فروش',
    'presale' => 'پیش فروش',
    'rent' => 'اجاره',
    'invest' => 'سرمایه‌گذاری',
  ];
}

function STATUS_LABELS(): array {
  return [
    'available' => 'فعال',
    'pending' => 'در انتظار',
    'rejected' => 'رد شده',
    'sold' => 'فروخته شد',
  ];
}

/* ===================== JSON helpers ===================== */
function j_decode($val, $default = []) {
  if ($val === null || $val === '') return $default;
  if (is_array($val)) return $val;
  $d = json_decode($val, true);
  return $d === null ? $default : $d;
}

/* ===================== تنظیمات سایت (settings key/value) ===================== */
function getSetting(string $key, $default = []) {
  $stmt = db()->prepare('SELECT value FROM settings WHERE `key` = ?');
  $stmt->execute([$key]);
  $row = $stmt->fetch();
  if (!$row) return $default;
  return j_decode($row['value'], $default);
}

function setSetting(string $key, $value): void {
  $json = json_encode($value, JSON_UNESCAPED_UNICODE);
  $stmt = db()->prepare(
    'INSERT INTO settings (`key`, value) VALUES (?, ?)
     ON DUPLICATE KEY UPDATE value = VALUES(value), updated_at = CURRENT_TIMESTAMP'
  );
  $stmt->execute([$key, $json]);
}

function generalSettings(): array {
  $defaults = [
    'siteName' => 'ملکینو',
    'tagline' => 'اولین پلتفرم ملکی شاهرود',
    'logoLetter' => 'م',
    'logoUrl' => '',
    'logoDarkUrl' => '',
    'logoInHeader' => true,
    'logoInOnboarding' => true,
    'autoPublish' => false,
    'showVipOnHome' => true,
    'maxImages' => 8,
  ];
  return array_merge($defaults, getSetting('general', []));
}

function contactSettings(): array {
  $defaults = [
    'phone' => '02332230000',
    'mobile' => '09123730000',
    'whatsapp' => '09123730000',
    'address' => 'شاهرود',
    'hours' => 'شنبه تا پنجشنبه ۹ صبح تا ۹ شب',
    'email' => '',
    'mapUrl' => '',
  ];
  return array_merge($defaults, getSetting('contact', []));
}

function socialSettings(): array {
  $defaults = [
    'telegram' => '', 'instagram' => '', 'bale' => '', 'eitaa' => '', 'whatsapp' => '',
    'showInContact' => true, 'showInProfile' => true, 'title' => 'ما را در شبکه‌های اجتماعی دنبال کنید',
  ];
  return array_merge($defaults, getSetting('social', []));
}

/* ===================== تصویر ملک/آپلود ===================== */
function propertyImageUrl(?string $path): string {
  if (!$path) return '';
  if (str_starts_with($path, 'http://') || str_starts_with($path, 'https://')) return $path;
  return UPLOADS_URL . '/' . ltrim($path, '/');
}

function e(?string $s): string {
  return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8');
}

