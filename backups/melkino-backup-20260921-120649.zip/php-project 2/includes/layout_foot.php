  </main>

  <nav class="bottom-nav">
    <a href="<?= SITE_URL ?>/home.php" class="nav-item <?= $activeNav === 'home' ? 'active' : '' ?>">
      <span class="nav-ic">🏠</span><span>خانه</span>
    </a>
    <a href="<?= SITE_URL ?>/search.php" class="nav-item <?= $activeNav === 'search' ? 'active' : '' ?>">
      <span class="nav-ic">🔍</span><span>جستجو</span>
    </a>
    <a href="<?= SITE_URL ?>/sell.php" class="nav-item nav-center <?= $activeNav === 'sell' ? 'active' : '' ?>">
      <span class="nav-ic">➕</span><span style="margin-top:2px">ثبت</span>
    </a>
    <a href="<?= SITE_URL ?>/favorites.php" class="nav-item <?= $activeNav === 'favorites' ? 'active' : '' ?>">
      <span class="nav-ic">❤️</span><span>علاقه‌ها</span>
    </a>
    <a href="<?= SITE_URL ?>/profile.php" class="nav-item <?= $activeNav === 'profile' ? 'active' : '' ?>">
      <span class="nav-ic">👤</span><span>پروفایل</span>
    </a>
  </nav>
</div>

<script>
function melkinoToggleTheme(){
  var cur = document.documentElement.getAttribute('data-theme') || 'light';
  var next = cur === 'dark' ? 'light' : 'dark';
  document.documentElement.setAttribute('data-theme', next);
  try { localStorage.setItem('melkino_theme', next); } catch(e){}
}

/* ===== ورود خودکار مینی‌اپ تلگرام/بله ===== */
(function(){
  function loadScript(src){
    return new Promise(function(resolve){
      if (document.querySelector('script[src="'+src+'"]')) { resolve(); return; }
      var s = document.createElement('script');
      s.src = src; s.async = true;
      s.onload = function(){ resolve(); };
      s.onerror = function(){ resolve(); };
      document.head.appendChild(s);
    });
  }
  function detectPlatform(){
    var bl = window.Bale && window.Bale.WebApp;
    if (bl && bl.initData) return { platform: 'bale', sdk: bl };
    var tg = window.Telegram && window.Telegram.WebApp;
    if (tg && tg.initData) return { platform: 'telegram', sdk: tg };
    return { platform: 'web' };
  }
  Promise.all([
    loadScript('https://telegram.org/js/telegram-web-app.js'),
    loadScript('https://tapi.bale.ai/miniapp.js'),
  ]).then(function(){
    var d = detectPlatform();
    try { localStorage.setItem('melkino_platform', d.platform); } catch(e){}
    if (d.platform === 'web' || !d.sdk) return;
    try { d.sdk.ready && d.sdk.ready(); d.sdk.expand && d.sdk.expand(); d.sdk.setHeaderColor && d.sdk.setHeaderColor('#031D1D'); } catch(e){}

    var sig = d.platform + ':' + (d.sdk.initData || '').slice(-32);
    try { if (sessionStorage.getItem('melkino_webapp_auth') === sig) return; } catch(e){}

    fetch('<?= SITE_URL ?>/webapp_auth.php', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ platform: d.platform, initData: d.sdk.initData, path: window.location.pathname }),
    }).then(function(r){ return r.json(); }).then(function(res){
      if (res.ok) {
        try { sessionStorage.setItem('melkino_webapp_auth', sig); } catch(e){}
        if (res.data && res.data.phone) { try { localStorage.setItem('melkino_user_phone', res.data.phone); } catch(e){} }
      } else if (res.code === 'no_token') {
        console.warn('[melkino] bot token not configured:', res.error);
      }
    }).catch(function(){});
  });
})();
</script>
</body>
</html>
