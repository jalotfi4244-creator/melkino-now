<?php
/**
 * سرآیند مشترک صفحات — معادل بخش هدر AppShell.tsx
 * قبل از include کردن این فایل باید $pageTitle و $activeNav تعریف شده باشند.
 */
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/user_auth.php';
$appUser = getSessionAppUser();
$general = generalSettings();
$contact = contactSettings();
$pageTitle = $pageTitle ?? $general['siteName'];
$activeNav = $activeNav ?? '';
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title><?= e($pageTitle) ?></title>
<?php if (!empty($general['logoUrl'])): ?>
<link rel="icon" href="<?= e(propertyImageUrl($general['logoUrl'])) ?>">
<?php endif; ?>
<script src="https://cdn.tailwindcss.com"></script>
<link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/style.css">
<script>
(function(){try{var t=localStorage.getItem('melkino_theme')||'light';document.documentElement.setAttribute('data-theme',t);}catch(e){document.documentElement.setAttribute('data-theme','light');}})();
</script>
</head>
<body>
<div class="app-frame">
  <header class="app-header">
    <div class="flex items-center gap-2.5 px-4 py-3">
      <a href="<?= SITE_URL ?>/home.php" class="flex items-center gap-2.5">
        <?php if (!empty($general['logoInHeader']) && !empty($general['logoUrl'])): ?>
          <img src="<?= e(propertyImageUrl($general['logoUrl'])) ?>" alt="" style="width:40px;height:40px;border-radius:16px;object-fit:contain">
        <?php else: ?>
          <div style="width:40px;height:40px;border-radius:16px;background:linear-gradient(135deg,var(--primary-light),var(--primary));display:flex;align-items:center;justify-content:center;color:#fff;font-weight:900;font-size:17px"><?= e($general['logoLetter'] ?: 'م') ?></div>
        <?php endif; ?>
        <div>
          <div class="font-black text-[17px] leading-5" style="color:var(--text-primary)"><?= e($general['siteName']) ?></div>
          <div class="text-[10px] font-semibold" style="color:var(--text-muted)"><?= e($general['tagline']) ?></div>
        </div>
      </a>
      <div class="flex-1"></div>
      <a href="tel:<?= e(preg_replace('/[\s-]/', '', $contact['mobile'] ?: $contact['phone'] ?: '')) ?>" class="icon-btn" title="تماس">📞</a>
      <button onclick="melkinoToggleTheme()" class="icon-btn" title="تم روشن/تاریک" id="themeBtn">🌙</button>
      <a href="<?= SITE_URL ?>/notifications.php" class="icon-btn" title="اعلان‌ها">🔔</a>
      <?php if ($appUser): ?>
        <a href="<?= SITE_URL ?>/profile.php" class="icon-btn" title="حساب کاربری">👤</a>
      <?php else: ?>
        <a href="<?= SITE_URL ?>/login.php" class="icon-btn !w-auto !px-3 gap-1.5 text-[12px] font-extrabold" style="color:var(--primary)">👤 ورود</a>
      <?php endif; ?>
    </div>
  </header>
  <main class="app-content">
