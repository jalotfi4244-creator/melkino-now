<?php
/**
 * موتور تطبیق هوشمند — معادل src/lib/match.ts
 * پیدا کردن نزدیک‌ترین آگهی‌های فعال به یک درخواست
 */

define('MATCH_CURRENT_YEAR', 1405);

function matchInRange(float $v, ?float $min, ?float $max): string {
  if (!$v || $v <= 0) return 'out';
  $lo = ($min && $min > 0) ? $min : 0;
  $hi = ($max && $max > 0) ? $max : 0;
  if (!$lo && !$hi) return 'in';
  if ($lo && $hi) {
    if ($v >= $lo && $v <= $hi) return 'in';
    $span = ($hi - $lo) ?: $hi;
    if ($v >= $lo - $span * 0.2 && $v <= $hi + $span * 0.2) return 'near';
    return 'out';
  }
  if ($lo) {
    if ($v >= $lo) return 'in';
    if ($v >= $lo * 0.85) return 'near';
    return 'out';
  }
  if ($v <= $hi) return 'in';
  if ($v <= $hi * 1.15) return 'near';
  return 'out';
}

/**
 * $req: آرایه درخواست (dealType, propertyType, priorities, noPriority, location, minPrice, maxPrice, ...)
 * $p:   آرایه رکورد ملک از دیتابیس (properties.*)
 * خروجی: ['score'=>int, 'reasons'=>[...]]
 */
function scoreProperty(array $req, array $p): array {
  $score = 0;
  $reasons = [];

  // نوع معامله: ۲۲ امتیاز
  $reqDeal = $req['dealType'] ?? null;
  if ($reqDeal && $reqDeal !== 'all') {
    if ($reqDeal === 'invest') {
      if (in_array($p['deal_type'], ['sale', 'presale'])) { $score += 22; $reasons[] = 'مناسب سرمایه‌گذاری'; }
      else { $score -= 30; $reasons[] = 'مناسب سرمایه‌گذاری نیست'; }
    } elseif ($p['deal_type'] === $reqDeal) {
      $score += 22;
    } else { $score -= 30; $reasons[] = 'نوع معامله متفاوت'; }
  } else { $score += 10; }

  // نوع ملک با اولویت: ۲۰ امتیاز
  $pris = array_values(array_filter($req['priorities'] ?? []));
  if (!empty($req['noPriority']) || empty($pris)) {
    $reqType = $req['propertyType'] ?? null;
    if ($reqType && $reqType !== 'all') {
      if ($p['type'] === $reqType) $score += 20;
      else { $score -= 25; $reasons[] = 'نوع ملک متفاوت'; }
    } else $score += 10;
  } else {
    $idx = array_search($p['type'], $pris);
    if ($idx === 0) { $score += 20; $reasons[] = 'اولویت اول شما'; }
    elseif ($idx === 1) { $score += 14; $reasons[] = 'اولویت دوم شما'; }
    elseif ($idx === 2) { $score += 9; $reasons[] = 'اولویت سوم شما'; }
    else { $score -= 25; $reasons[] = 'خارج از اولویت‌های نوع ملک'; }
  }

  // قیمت: ۲۰ امتیاز
  if ($p['deal_type'] === 'rent') {
    $dep = matchInRange((float)$p['mortgage_price'], $req['minDeposit'] ?? null, $req['maxDeposit'] ?? null);
    $rnt = matchInRange((float)$p['rent_price'], $req['minRent'] ?? null, $req['maxRent'] ?? null);
    if ($dep === 'in') { $score += 10; $reasons[] = 'ودیعه در بازه شما'; } elseif ($dep === 'near') $score += 5;
    if ($rnt === 'in') { $score += 10; $reasons[] = 'اجاره در بازه شما'; } elseif ($rnt === 'near') $score += 5;
    if ($dep === 'out' || $rnt === 'out') $score -= 4;
    if (!empty($req['rahnKamal']) && (float)$p['rent_price'] > 0) $score -= 6;
  } else {
    $r = matchInRange((float)$p['price'], $req['minPrice'] ?? null, $req['maxPrice'] ?? null);
    if ($r === 'in') { $score += 20; $reasons[] = 'قیمت در بازه شما'; }
    elseif ($r === 'near') { $score += 10; $reasons[] = 'قیمت نزدیک به بازه شما'; }
    else { $score -= 8; $reasons[] = 'قیمت خارج از بازه'; }
  }

  // متراژ: ۱۲ امتیاز
  $ar = matchInRange((float)$p['area'], $req['minArea'] ?? null, $req['maxArea'] ?? null);
  if ($ar === 'in') { $score += 12; $reasons[] = 'متراژ مناسب'; } elseif ($ar === 'near') $score += 6;

  // اتاق: ۸ امتیاز
  if (!empty($req['rooms'])) {
    if ((int)$p['rooms'] === (int)$req['rooms']) { $score += 8; $reasons[] = 'تعداد اتاق دقیق'; }
    elseif (abs((int)$p['rooms'] - (int)$req['rooms']) === 1) $score += 4;
  } else $score += 4;

  // محله: ۱۲ امتیاز
  $locs = array_values(array_filter(array_merge($req['neighborhoods'] ?? [], !empty($req['location']) ? [$req['location']] : [])));
  if (!empty($locs)) {
    $hay = ($p['neighborhood'] ?? '') . ' ' . ($p['address'] ?? '');
    $hit = false;
    foreach ($locs as $l) {
      if ($l && (str_contains($hay, $l) || str_contains($l, $p['neighborhood'] ?? '§'))) { $hit = true; break; }
    }
    if ($hit) { $score += 12; $reasons[] = 'در محله درخواستی'; } else $score -= 3;
  } else $score += 6;

  // سن بنا: ۶ امتیاز
  if ((!empty($req['minAge']) || !empty($req['maxAge'])) && (int)($p['year_built'] ?? 0) > 1300) {
    $age = MATCH_CURRENT_YEAR - (int)$p['year_built'];
    $okMin = empty($req['minAge']) || $age >= $req['minAge'];
    $okMax = empty($req['maxAge']) || $age <= $req['maxAge'];
    if ($okMin && $okMax) { $score += 6; $reasons[] = 'سن بنا مناسب'; }
  } else $score += 3;

  // امکانات: تا ۱۰ امتیاز
  $want = $req['amenities'] ?? [];
  if (!empty($want)) {
    $have = j_decode($p['amenities'] ?? null, []);
    $hits = count(array_intersect($want, $have));
    $ratio = $hits / count($want);
    $score += (int)round($ratio * 10);
    if ($hits > 0) $reasons[] = $hits . ' امکانات مشترک';
  } else $score += 5;

  $score = max(0, min(100, (int)round($score)));
  return ['score' => $score, 'reasons' => array_slice($reasons, 0, 4)];
}

function matchLabel(int $score): string {
  if ($score >= 85) return 'تطابق عالی';
  if ($score >= 65) return 'تطابق خوب';
  if ($score >= 45) return 'نزدیک به درخواست';
  return 'تطابق ضعیف';
}
