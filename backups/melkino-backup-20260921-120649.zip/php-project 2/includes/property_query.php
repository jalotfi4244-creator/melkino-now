<?php
require_once __DIR__ . '/db.php';

/**
 * ساخت و اجرای کوئری فیلترشده آگهی‌ها — معادل src/app/api/properties/route.ts (GET)
 * $filters keys: status, deal, type, q, minPrice, maxPrice, minArea, maxArea, rooms,
 *                neighborhood, amenities(array), featured, vip, sort, limit, offset
 * خروجی: ['items' => [...], 'total' => int]
 */
function queryProperties(array $filters): array {
  $where = ['status = :status'];
  $params = [':status' => $filters['status'] ?? 'available'];

  if (!empty($filters['deal']) && $filters['deal'] !== 'all') {
    $where[] = 'deal_type = :deal';
    $params[':deal'] = $filters['deal'];
  }
  if (!empty($filters['type']) && $filters['type'] !== 'all') {
    $where[] = 'type = :type';
    $params[':type'] = $filters['type'];
  }
  if (!empty($filters['neighborhood']) && $filters['neighborhood'] !== 'all') {
    $where[] = 'neighborhood = :neighborhood';
    $params[':neighborhood'] = $filters['neighborhood'];
  }
  if (!empty($filters['rooms']) && $filters['rooms'] !== 'all') {
    if ($filters['rooms'] === '4+') {
      $where[] = 'rooms >= 4';
    } else {
      $where[] = 'rooms = :rooms';
      $params[':rooms'] = (int)$filters['rooms'];
    }
  }
  if (!empty($filters['minPrice'])) { $where[] = 'price >= :minPrice'; $params[':minPrice'] = (int)$filters['minPrice']; }
  if (!empty($filters['maxPrice'])) { $where[] = 'price <= :maxPrice'; $params[':maxPrice'] = (int)$filters['maxPrice']; }
  if (!empty($filters['minArea'])) { $where[] = 'area >= :minArea'; $params[':minArea'] = (int)$filters['minArea']; }
  if (!empty($filters['maxArea'])) { $where[] = 'area <= :maxArea'; $params[':maxArea'] = (int)$filters['maxArea']; }
  if (!empty($filters['featured'])) { $where[] = 'featured = 1'; }
  if (!empty($filters['vip'])) { $where[] = 'vip = 1'; }
  if (!empty($filters['q'])) {
    $where[] = '(title LIKE :q1 OR description LIKE :q2 OR neighborhood LIKE :q3 OR code LIKE :q4)';
    $qv = '%' . $filters['q'] . '%';
    $params[':q1'] = $qv; $params[':q2'] = $qv; $params[':q3'] = $qv; $params[':q4'] = $qv;
  }
  if (!empty($filters['amenities']) && is_array($filters['amenities'])) {
    $i = 0;
    foreach ($filters['amenities'] as $a) {
      $key = ':amenity' . $i++;
      $where[] = 'JSON_CONTAINS(amenities, JSON_QUOTE(' . $key . '))';
      $params[$key] = $a;
    }
  }

  $sort = $filters['sort'] ?? 'newest';
  $orderBy = match ($sort) {
    'cheap' => 'price ASC',
    'expensive' => 'price DESC',
    'area' => 'area DESC',
    'views' => 'views DESC',
    default => 'created_at DESC',
  };

  $limit = min((int)($filters['limit'] ?? 24), 60);
  $offset = max((int)($filters['offset'] ?? 0), 0);

  $whereSql = implode(' AND ', $where);

  $countStmt = db()->prepare("SELECT COUNT(*) c FROM properties WHERE $whereSql");
  $countStmt->execute($params);
  $total = (int)$countStmt->fetch()['c'];

  $sql = "SELECT * FROM properties WHERE $whereSql ORDER BY $orderBy LIMIT $limit OFFSET $offset";
  $stmt = db()->prepare($sql);
  $stmt->execute($params);
  $items = $stmt->fetchAll();

  return ['items' => $items, 'total' => $total];
}
