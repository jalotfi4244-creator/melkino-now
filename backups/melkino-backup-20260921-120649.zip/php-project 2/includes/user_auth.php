<?php
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/functions.php';

define('USER_COOKIE', 'melkino_session');
define('SESSION_DAYS', 90);

function normalizePhone(string $v): string {
  $p = toEnDigits($v);
  $p = preg_replace('/[^\d+]/', '', $p);
  if (str_starts_with($p, '+98')) $p = '0' . substr($p, 3);
  elseif (str_starts_with($p, '98') && strlen($p) === 12) $p = '0' . substr($p, 2);
  elseif (str_starts_with($p, '0098')) $p = '0' . substr($p, 4);
  elseif (strlen($p) === 10 && str_starts_with($p, '9')) $p = '0' . $p;
  return $p;
}

function isValidPhone(string $p): bool {
  return (bool)preg_match('/^09\d{9}$/', $p);
}

/** درخواست کد OTP — حداکثر یک کد در ۶۰ ثانیه */
function requestOtp(string $phone): array {
  $stmt = db()->prepare("SELECT id FROM otp_codes WHERE phone = ? AND created_at > (NOW() - INTERVAL 60 SECOND) LIMIT 1");
  $stmt->execute([$phone]);
  if ($stmt->fetch()) {
    return ['ok' => false, 'error' => 'کد قبلاً ارسال شده؛ یک دقیقه صبر کنید.'];
  }
  $code = (string)random_int(100000, 999999);
  $expires = date('Y-m-d H:i:s', time() + 300);
  db()->prepare('INSERT INTO otp_codes (phone, code, expires_at) VALUES (?,?,?)')->execute([$phone, $code, $expires]);
  // بدون سرویس پیامک واقعی، کد مستقیماً برگردانده می‌شود (دقیقاً مثل رفتار پیش‌فرض نسخه اصلی)
  return ['ok' => true, 'message' => 'کد ورود صادر شد.', 'devCode' => $code, 'expiresIn' => 300];
}

/** بررسی کد OTP و ورود/ثبت‌نام کاربر */
function verifyOtp(string $phone, string $code, string $name = ''): array {
  $stmt = db()->prepare("SELECT * FROM otp_codes WHERE phone = ? AND used = 0 ORDER BY created_at DESC LIMIT 1");
  $stmt->execute([$phone]);
  $row = $stmt->fetch();
  if (!$row) return ['ok' => false, 'error' => 'ابتدا کد را درخواست کنید.'];
  if (strtotime($row['expires_at']) < time()) return ['ok' => false, 'error' => 'کد منقضی شده؛ دوباره درخواست کنید.'];
  if ((int)$row['attempts'] >= 5) return ['ok' => false, 'error' => 'تعداد تلاش بیش از حد مجاز.'];
  if ($row['code'] !== $code) {
    db()->prepare('UPDATE otp_codes SET attempts = attempts + 1 WHERE id = ?')->execute([$row['id']]);
    return ['ok' => false, 'error' => 'کد وارد شده اشتباه است.'];
  }
  db()->prepare('UPDATE otp_codes SET used = 1 WHERE id = ?')->execute([$row['id']]);

  $userKey = 'phone_' . preg_replace('/\D/', '', $phone);
  $u = db()->prepare('SELECT * FROM app_users WHERE user_key = ?');
  $u->execute([$userKey]);
  $user = $u->fetch();

  if ($user) {
    $newName = $name !== '' ? $name : $user['name'];
    db()->prepare('UPDATE app_users SET name=?, phone=?, phone_verified=1, last_login=NOW(), login_count = login_count + 1, last_ip=? WHERE id=?')
       ->execute([$newName, $phone, $_SERVER['REMOTE_ADDR'] ?? '', $user['id']]);
    $userId = $user['id'];
  } else {
    db()->prepare('INSERT INTO app_users (user_key, phone, phone_verified, name, platform, ip, last_ip) VALUES (?,?,1,?,?,?,?)')
       ->execute([$userKey, $phone, $name, 'web', $_SERVER['REMOTE_ADDR'] ?? '', $_SERVER['REMOTE_ADDR'] ?? '']);
    $userId = (int)db()->lastInsertId();
  }

  db()->prepare('INSERT INTO user_logins (user_id, path, user_agent, ip, platform, method) VALUES (?,?,?,?,?,?)')
     ->execute([$userId, '/login', substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 300), $_SERVER['REMOTE_ADDR'] ?? '', 'web', 'otp']);

  // ساخت نشست
  $token = bin2hex(random_bytes(32));
  $expiresAt = date('Y-m-d H:i:s', time() + SESSION_DAYS * 86400);
  db()->prepare('INSERT INTO user_sessions (user_id, token, platform, ip, user_agent, expires_at) VALUES (?,?,?,?,?,?)')
     ->execute([$userId, $token, 'web', $_SERVER['REMOTE_ADDR'] ?? '', substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 300), $expiresAt]);

  setcookie(USER_COOKIE, $token, [
    'expires' => time() + SESSION_DAYS * 86400, 'path' => '/', 'httponly' => true, 'samesite' => 'Lax',
  ]);

  $stmt2 = db()->prepare('SELECT * FROM app_users WHERE id = ?');
  $stmt2->execute([$userId]);
  return ['ok' => true, 'user' => $stmt2->fetch()];
}

/** کاربر جاری بر اساس کوکی نشست */
function getSessionAppUser(): ?array {
  $token = $_COOKIE[USER_COOKIE] ?? '';
  if (!$token) return null;
  $stmt = db()->prepare('SELECT * FROM user_sessions WHERE token = ?');
  $stmt->execute([$token]);
  $s = $stmt->fetch();
  if (!$s || strtotime($s['expires_at']) < time()) return null;
  $u = db()->prepare('SELECT * FROM app_users WHERE id = ?');
  $u->execute([$s['user_id']]);
  $user = $u->fetch();
  if (!$user || $user['status'] === 'blocked') return null;
  return $user;
}

function destroyUserSession(): void {
  $token = $_COOKIE[USER_COOKIE] ?? '';
  if ($token) {
    db()->prepare('DELETE FROM user_sessions WHERE token = ?')->execute([$token]);
    setcookie(USER_COOKIE, '', ['expires' => time() - 3600, 'path' => '/']);
  }
}

/* ================= ورود از مینی‌اپ تلگرام / بله ================= */

function getChannelSettings(): array {
  $defaults = [
    'telegramBotToken' => '', 'telegramChatId' => '',
    'baleBotToken' => '', 'baleChatId' => '',
  ];
  return array_merge($defaults, getSetting('channels', []));
}

/**
 * بررسی امضای initData تلگرام/بله (الگوریتم HMAC رسمی تلگرام)
 * خروجی: ['ok'=>bool, 'user'=>array|null, 'error'=>string|null]
 */
function verifyInitData(string $initData, string $botToken, string $platform): array {
  if ($initData === '' || $botToken === '') return ['ok' => false, 'error' => 'initData یا توکن ربات موجود نیست'];
  parse_str($initData, $params);
  $hash = $params['hash'] ?? '';
  if ($hash === '') return ['ok' => false, 'error' => 'hash موجود نیست'];
  unset($params['hash']);
  $pairs = [];
  foreach ($params as $k => $v) { $pairs[] = $k . '=' . $v; }
  sort($pairs);
  $dataCheckString = implode("\n", $pairs);

  $secret = hash_hmac('sha256', $botToken, 'WebAppData', true);
  $calc = hash_hmac('sha256', $dataCheckString, $secret);
  $valid = hash_equals($calc, $hash);

  if (!$valid && $platform === 'bale') {
    // بله در برخی نسخه‌ها از secret = SHA256(botToken) استفاده می‌کند
    $secret2 = hash('sha256', $botToken, true);
    $calc2 = hash_hmac('sha256', $dataCheckString, $secret2);
    $valid = hash_equals($calc2, $hash);
  }
  if (!$valid) return ['ok' => false, 'error' => 'امضای initData معتبر نیست'];

  $authDate = (int)($params['auth_date'] ?? 0);
  if ($authDate && (time() - $authDate) > 86400) return ['ok' => false, 'error' => 'initData منقضی شده است'];

  $userRaw = $params['user'] ?? '';
  $user = $userRaw ? json_decode($userRaw, true) : null;
  if (!$user || empty($user['id'])) return ['ok' => false, 'error' => 'اطلاعات کاربر موجود نیست'];
  return ['ok' => true, 'user' => $user, 'authDate' => $authDate];
}

/** ورود/ثبت‌نام کاربر مینی‌اپ پس از تایید initData */
function upsertWebappUser(string $platform, array $tgUser): array {
  $telegramId = $platform === 'telegram' ? (string)$tgUser['id'] : '';
  $baleId = $platform === 'bale' ? (string)$tgUser['id'] : '';
  $key = $telegramId ? "tg:$telegramId" : ($baleId ? "bl:$baleId" : '');
  if ($key === '') return ['ok' => false, 'error' => 'شناسه کاربر نامشخص است'];

  $phone = !empty($tgUser['phone_number']) ? normalizePhone($tgUser['phone_number']) : '';
  $fullName = trim(($tgUser['first_name'] ?? '') . ' ' . ($tgUser['last_name'] ?? ''));

  $stmt = db()->prepare('SELECT * FROM app_users WHERE user_key = ?');
  $stmt->execute([$key]);
  $existing = $stmt->fetch();
  if (!$existing && $phone) {
    $stmt2 = db()->prepare('SELECT * FROM app_users WHERE phone = ?');
    $stmt2->execute([$phone]);
    $existing = $stmt2->fetch() ?: null;
  }

  $ip = $_SERVER['REMOTE_ADDR'] ?? '';
  $ua = substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 300);

  if ($existing) {
    $newKey = (str_starts_with($existing['user_key'], 'phone:') || $existing['user_key'] === '') ? $key : $existing['user_key'];
    // اگر کلید جدید با رکورد دیگری تداخل داشت، تغییرش نده
    $clashStmt = db()->prepare('SELECT id FROM app_users WHERE user_key = ? AND id != ?');
    $clashStmt->execute([$newKey, $existing['id']]);
    if ($clashStmt->fetch()) $newKey = $existing['user_key'];

    db()->prepare(
      'UPDATE app_users SET user_key=?, telegram_id=?, bale_id=?, name=COALESCE(NULLIF(?,\'\'),name),
       first_name=COALESCE(NULLIF(?,\'\'),first_name), last_name=COALESCE(NULLIF(?,\'\'),last_name),
       username=COALESCE(NULLIF(?,\'\'),username), photo_url=COALESCE(NULLIF(?,\'\'),photo_url),
       language_code=COALESCE(NULLIF(?,\'\'),language_code), is_premium=?, platform=?,
       phone=COALESCE(NULLIF(?,\'\'),phone),
       phone_verified = CASE WHEN ? <> \'\' THEN 1 ELSE phone_verified END,
       last_login=NOW(), last_ip=?, login_count = login_count + 1 WHERE id=?'
    )->execute([
      $newKey, $telegramId, $baleId, $fullName, $tgUser['first_name'] ?? '', $tgUser['last_name'] ?? '',
      $tgUser['username'] ?? '', $tgUser['photo_url'] ?? '', $tgUser['language_code'] ?? '', !empty($tgUser['is_premium']) ? 1 : 0,
      $platform, $phone, $phone, $ip, $existing['id'],
    ]);
    $userId = $existing['id'];
  } else {
    db()->prepare(
      'INSERT INTO app_users (user_key, phone, phone_verified, name, first_name, last_name, telegram_id, bale_id,
       username, platform, photo_url, language_code, is_premium, ip, last_ip)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)'
    )->execute([
      $key, $phone, $phone ? 1 : 0, $fullName, $tgUser['first_name'] ?? '', $tgUser['last_name'] ?? '',
      $telegramId, $baleId, $tgUser['username'] ?? '', $platform, $tgUser['photo_url'] ?? '',
      $tgUser['language_code'] ?? '', !empty($tgUser['is_premium']) ? 1 : 0, $ip, $ip,
    ]);
    $userId = (int)db()->lastInsertId();
  }

  db()->prepare('INSERT INTO user_logins (user_id, path, user_agent, ip, platform, method) VALUES (?,?,?,?,?,?)')
     ->execute([$userId, '/webapp', $ua, $ip, $platform, $platform]);

  $stmt3 = db()->prepare('SELECT * FROM app_users WHERE id = ?');
  $stmt3->execute([$userId]);
  $user = $stmt3->fetch();
  if ($user['status'] === 'blocked') return ['ok' => false, 'error' => 'حساب شما مسدود شده است'];

  $token = bin2hex(random_bytes(32));
  $expiresAt = date('Y-m-d H:i:s', time() + SESSION_DAYS * 86400);
  db()->prepare('INSERT INTO user_sessions (user_id, token, platform, ip, user_agent, expires_at) VALUES (?,?,?,?,?,?)')
     ->execute([$userId, $token, $platform, $ip, $ua, $expiresAt]);
  setcookie(USER_COOKIE, $token, ['expires' => time() + SESSION_DAYS * 86400, 'path' => '/', 'httponly' => true, 'samesite' => 'Lax']);

  return ['ok' => true, 'user' => $user, 'needPhone' => empty($user['phone'])];
}
