<?php
/**
 * صفحه ورودی — معادل src/app/page.tsx (آنبوردینگ)
 * در فاز اول مستقیم به صفحه اصلی هدایت می‌شود؛ صفحه آنبوردینگ کامل در فاز بعدی اضافه می‌شود.
 */
require_once __DIR__ . '/includes/functions.php';
header('Location: ' . SITE_URL . '/home.php');
exit;
