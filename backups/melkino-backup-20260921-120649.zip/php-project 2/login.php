<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/user_auth.php';

$appUser = getSessionAppUser();
$next = $_GET['next'] ?? SITE_URL . '/profile.php';
if ($appUser && $appUser['phone']) {
  header('Location: ' . $next);
  exit;
}

$pageTitle = generalSettings()['siteName'] . ' | ورود';
$activeNav = '';
require __DIR__ . '/includes/layout_head.php';
$general = generalSettings();
?>
<div class="px-4 pt-6 flex flex-col items-center">
  <?php if (!empty($general['logoUrl'])): ?>
    <img src="<?= e(propertyImageUrl($general['logoUrl'])) ?>" style="width:72px;height:72px;border-radius:24px;object-fit:contain">
  <?php else: ?>
    <div style="width:72px;height:72px;border-radius:24px;background:linear-gradient(135deg,var(--gold-light),var(--gold));display:flex;align-items:center;justify-content:center;color:#1a1405;font-weight:900;font-size:28px"><?= e($general['logoLetter'] ?: 'م') ?></div>
  <?php endif; ?>
  <h1 class="font-black text-[22px] mt-4" style="color:var(--text-primary)">ورود به <?= e($general['siteName']) ?></h1>
  <p class="text-[13px] mt-1 text-center leading-6" style="color:var(--text-secondary)">برای ثبت آگهی، درخواست و پیگیری، وارد حساب خود شوید.</p>

  <!-- ورود با پیام‌رسان (فقط داخل مینی‌اپ تلگرام/بله نمایش داده می‌شود) -->
  <div id="webappBtns" class="w-full mt-5 space-y-2" style="display:none">
    <button id="btnTelegram" onclick="mkWebappLogin('telegram')" style="display:none;background:linear-gradient(135deg,#2AABEE,#229ED9);box-shadow:0 8px 22px rgba(42,171,238,.35)" class="w-full py-4 rounded-2xl font-black text-[14px] text-white flex items-center justify-center gap-2">📨 ورود با تلگرام</button>
    <button id="btnBale" onclick="mkWebappLogin('bale')" style="display:none;background:linear-gradient(135deg,#34B7A9,#0F766E);box-shadow:0 8px 22px rgba(15,118,110,.35)" class="w-full py-4 rounded-2xl font-black text-[14px] text-white flex items-center justify-center gap-2">💬 ورود با بله</button>
    <div class="flex items-center gap-3 my-2 text-[12px]" style="color:var(--text-muted)">
      <span class="flex-1 h-px" style="background:var(--border)"></span> یا با شماره موبایل <span class="flex-1 h-px" style="background:var(--border)"></span>
    </div>
  </div>

  <div class="card p-5 w-full mt-4" id="loginCard">
    <!-- مرحله ۱: شماره موبایل -->
    <div id="step1">
      <label class="text-[13px] font-bold block mb-1.5" style="color:var(--text-secondary)">شماره موبایل</label>
      <input type="tel" id="phoneInput" class="form-input" placeholder="09123456789" dir="ltr" style="text-align:left" autofocus>
      <button onclick="mkRequestOtp()" id="btnRequest" class="btn-primary w-full py-3.5 rounded-2xl text-sm mt-3">دریافت کد ورود</button>
    </div>

    <!-- مرحله ۲: کد تایید -->
    <div id="step2" style="display:none">
      <div class="flex items-center justify-between mb-2">
        <label class="text-[13px] font-bold" style="color:var(--text-secondary)">کد ۶ رقمی ارسال‌شده به <b id="phoneShown" dir="ltr"></b></label>
        <button onclick="mkBackToStep1()" class="text-[12px] font-extrabold" style="color:var(--primary)">← تغییر شماره</button>
      </div>
      <input type="text" inputmode="numeric" id="codeInput" maxlength="6" class="form-input text-center" style="font-size:22px;font-weight:900;letter-spacing:.4em" placeholder="——————" dir="ltr">
      <div id="devCodeBox" style="display:none"></div>
      <input class="form-input mt-3" id="nameInput" placeholder="نام و نام خانوادگی (اختیاری)">
      <button onclick="mkVerifyOtp()" id="btnVerify" class="btn-primary w-full py-3.5 rounded-2xl text-sm mt-3">✔ تأیید و ورود</button>
      <button onclick="mkRequestOtp()" id="btnResend" class="w-full mt-2 text-[12.5px] font-bold py-2" style="color:var(--text-secondary)">ارسال مجدد کد</button>
    </div>

    <p id="msgBox" style="display:none" class="text-[12.5px] text-center rounded-2xl py-2.5 mt-3 leading-6"></p>
  </div>

  <p class="text-[11px] mt-4 text-center leading-5" style="color:var(--text-muted)">
    با ورود، <b>قوانین ملکینو</b> را می‌پذیرید. شماره شما فقط برای پیگیری آگهی‌ها و درخواست‌ها استفاده می‌شود.
  </p>
</div>

<script>
var mkPhone = '';
var mkTimer = 0, mkTimerRef = null;
var faDigits = function(n){ var fa=['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹']; return String(n).replace(/[0-9]/g,function(d){return fa[d];}); };

try { var savedPhone = localStorage.getItem('melkino_user_phone'); if (savedPhone) document.getElementById('phoneInput').value = savedPhone; } catch(e){}

/* نمایش دکمه‌های تلگرام/بله فقط زمانی که صفحه داخل مینی‌اپ باز شده باشد */
(function(){
  function detect(){
    var bl = window.Bale && window.Bale.WebApp;
    if (bl && bl.initData) return { platform: 'bale', sdk: bl };
    var tg = window.Telegram && window.Telegram.WebApp;
    if (tg && tg.initData) return { platform: 'telegram', sdk: tg };
    return { platform: 'web' };
  }
  setTimeout(function(){
    var d = detect();
    if (d.platform === 'web') return;
    document.getElementById('webappBtns').style.display = 'block';
    document.getElementById(d.platform === 'telegram' ? 'btnTelegram' : 'btnBale').style.display = 'flex';
    window.__mkWebappSdk = d.sdk;
    window.__mkWebappPlatform = d.platform;
  }, 400); // کمی صبر تا اسکریپت‌های SDK از layout بارگذاری شوند
})();

function mkWebappLogin(pl){
  var sdk = window.__mkWebappSdk;
  if (!sdk || !sdk.initData) { mkShowMsg('این صفحه داخل ' + (pl === 'telegram' ? 'تلگرام' : 'بله') + ' باز نشده است.', false); return; }
  fetch('<?= SITE_URL ?>/webapp_auth.php', { method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify({ platform: pl, initData: sdk.initData, path: '/login' }) })
    .then(function(r){ return r.json(); })
    .then(function(d){
      if (d.ok) {
        if (d.needPhone) { mkShowMsg('✓ ورود موفق — برای تکمیل، شماره موبایل خود را تأیید کنید.', true); }
        else { mkShowMsg('✓ ورود موفق! در حال انتقال...', true); setTimeout(function(){ window.location.href = <?= json_encode($next) ?>; }, 500); }
      } else { mkShowMsg(d.error || 'ورود ناموفق بود.', false); }
    })
    .catch(function(){ mkShowMsg('خطا در ارتباط با سرور.', false); });
}

function mkShowMsg(text, ok){
  var box = document.getElementById('msgBox');
  box.style.display = 'block';
  box.textContent = text;
  box.style.background = ok ? 'var(--success-bg)' : 'var(--danger-bg)';
  box.style.color = ok ? 'var(--success)' : 'var(--danger)';
}

function mkRequestOtp(){
  var phone = document.getElementById('phoneInput').value.trim();
  if (!/^0?9\d{9}$/.test(phone.replace(/\s/g,''))) { mkShowMsg('شماره موبایل معتبر نیست.', false); return; }
  mkPhone = phone;
  document.getElementById('btnRequest').disabled = true;
  fetch('<?= SITE_URL ?>/otp_request.php', { method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:'phone=' + encodeURIComponent(phone) })
    .then(function(r){ return r.json(); })
    .then(function(d){
      document.getElementById('btnRequest').disabled = false;
      if (!d.ok) { mkShowMsg(d.error || 'ارسال کد ناموفق بود.', false); return; }
      document.getElementById('step1').style.display = 'none';
      document.getElementById('step2').style.display = 'block';
      document.getElementById('phoneShown').textContent = faDigits(phone);
      if (d.devCode) {
        var box = document.getElementById('devCodeBox');
        box.style.display = 'block';
        box.className = 'w-full mt-2 text-[12px] font-bold py-2.5 px-3 rounded-xl cursor-pointer';
        box.style.background = 'var(--gold-bg)'; box.style.color = 'var(--gold-dark)';
        box.innerHTML = '🔐 سرویس پیامک فعال نیست — کد شما: <b dir="ltr">' + faDigits(d.devCode) + '</b> (برای تکمیل خودکار ضربه بزنید)';
        box.onclick = function(){ document.getElementById('codeInput').value = d.devCode; };
      }
      mkShowMsg(d.message || 'کد ارسال شد.', true);
      mkStartTimer();
    })
    .catch(function(){ document.getElementById('btnRequest').disabled = false; mkShowMsg('خطا در ارتباط با سرور.', false); });
}

function mkVerifyOtp(){
  var code = document.getElementById('codeInput').value.trim();
  if (!/^\d{6}$/.test(code)) { mkShowMsg('کد ۶ رقمی را وارد کنید.', false); return; }
  document.getElementById('btnVerify').disabled = true;
  var name = document.getElementById('nameInput').value.trim();
  fetch('<?= SITE_URL ?>/otp_verify.php', { method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'},
    body:'phone=' + encodeURIComponent(mkPhone) + '&code=' + encodeURIComponent(code) + '&name=' + encodeURIComponent(name) })
    .then(function(r){ return r.json(); })
    .then(function(d){
      document.getElementById('btnVerify').disabled = false;
      if (!d.ok) { mkShowMsg(d.error || 'کد اشتباه است.', false); return; }
      try { localStorage.setItem('melkino_user_phone', d.data.phone); } catch(e){}
      mkShowMsg('✓ ورود موفق! در حال انتقال...', true);
      setTimeout(function(){ window.location.href = <?= json_encode($next) ?>; }, 500);
    })
    .catch(function(){ document.getElementById('btnVerify').disabled = false; mkShowMsg('خطا در ارتباط با سرور.', false); });
}

function mkBackToStep1(){
  document.getElementById('step1').style.display = 'block';
  document.getElementById('step2').style.display = 'none';
  document.getElementById('msgBox').style.display = 'none';
  clearInterval(mkTimerRef);
}

function mkStartTimer(){
  mkTimer = 60;
  document.getElementById('btnResend').disabled = true;
  clearInterval(mkTimerRef);
  mkTimerRef = setInterval(function(){
    mkTimer--;
    document.getElementById('btnResend').textContent = mkTimer > 0 ? ('ارسال مجدد تا ' + faDigits(mkTimer) + ' ثانیه') : 'ارسال مجدد کد';
    if (mkTimer <= 0) { clearInterval(mkTimerRef); document.getElementById('btnResend').disabled = false; }
  }, 1000);
}
</script>

<?php require __DIR__ . '/includes/layout_foot.php'; ?>
