<?php
require_once __DIR__ . '/includes/functions.php';
$pageTitle = generalSettings()['siteName'] . ' | اعلان‌ها';
$activeNav = '';
require __DIR__ . '/includes/layout_head.php';
?>
<div class="px-4 pt-6 pb-10 text-center">
  <div class="text-[40px] mb-3">🚧</div>
  <h2 class="font-black text-[18px]" style="color:var(--text-primary)">اعلان‌ها</h2>
  <p class="text-[13px] mt-2" style="color:var(--text-muted)">این صفحه در فاز بعدی تبدیل پروژه به PHP کامل می‌شود.</p>
  <a href="<?= SITE_URL ?>/home.php" class="btn-gold inline-block mt-5 py-3 px-6 rounded-2xl text-sm" style="text-decoration:none">بازگشت به خانه</a>
</div>
<?php require __DIR__ . '/includes/layout_foot.php'; ?>
