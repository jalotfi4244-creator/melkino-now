<?php
require_once __DIR__ . '/includes/user_auth.php';
header('Content-Type: application/json; charset=utf-8');

$phone = normalizePhone($_POST['phone'] ?? '');
if (!isValidPhone($phone)) {
  echo json_encode(['ok' => false, 'error' => 'شماره موبایل معتبر نیست.'], JSON_UNESCAPED_UNICODE);
  exit;
}
echo json_encode(requestOtp($phone), JSON_UNESCAPED_UNICODE);
