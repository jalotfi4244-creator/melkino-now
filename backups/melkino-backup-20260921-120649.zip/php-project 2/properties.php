<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/property_query.php';

$pageTitle = generalSettings()['siteName'] . ' | همه آگهی‌ها';
$activeNav = '';

$deal = $_GET['deal'] ?? 'all';
$type = $_GET['type'] ?? 'all';
$q = trim($_GET['q'] ?? '');
$sort = $_GET['sort'] ?? 'newest';

$result = queryProperties([
  'deal' => $deal, 'type' => $type, 'q' => $q, 'sort' => $sort, 'limit' => 30,
]);
$items = $result['items'];
$total = $result['total'];

function qsMerge(array $overrides): string {
  $base = ['deal' => $_GET['deal'] ?? 'all', 'type' => $_GET['type'] ?? 'all', 'q' => $_GET['q'] ?? '', 'sort' => $_GET['sort'] ?? 'newest'];
  return http_build_query(array_merge($base, $overrides));
}

require __DIR__ . '/includes/layout_head.php';
require_once __DIR__ . '/includes/cards.php';
?>
<div class="px-4 pt-4">
  <h1 class="step-title flex items-center gap-2">🗂️ همه آگهی‌ها</h1>
  <p class="step-subtitle mb-4"><?= toFaDigits($total) ?> آگهی منتشر شده • به‌روزرسانی روزانه</p>

  <form method="get" class="relative mb-3">
    <?php if ($deal !== 'all'): ?><input type="hidden" name="deal" value="<?= e($deal) ?>"><?php endif; ?>
    <?php if ($type !== 'all'): ?><input type="hidden" name="type" value="<?= e($type) ?>"><?php endif; ?>
    <input type="hidden" name="sort" value="<?= e($sort) ?>">
    <span style="position:absolute;right:14px;top:50%;transform:translateY(-50%);color:var(--primary)">🔍</span>
    <input type="text" name="q" value="<?= e($q) ?>" placeholder="جستجو: عنوان، محله، کد ملک..." class="form-input" style="padding-right:44px">
  </form>

  <div class="flex gap-2 overflow-x-auto mb-3" style="scrollbar-width:none">
    <a href="?<?= qsMerge(['deal' => 'all']) ?>" class="option-btn <?= $deal === 'all' ? 'selected' : '' ?>" style="white-space:nowrap">همه</a>
    <?php foreach (DEAL_TYPES() as $k => $v): ?>
      <a href="?<?= qsMerge(['deal' => $k]) ?>" class="option-btn <?= $deal === $k ? 'selected' : '' ?>" style="white-space:nowrap"><?= e($v) ?></a>
    <?php endforeach; ?>
  </div>
  <div class="flex gap-2 overflow-x-auto mb-3" style="scrollbar-width:none">
    <a href="?<?= qsMerge(['type' => 'all']) ?>" class="option-btn <?= $type === 'all' ? 'selected' : '' ?>" style="white-space:nowrap">همه انواع</a>
    <?php foreach (PROPERTY_TYPES() as $k => $v): ?>
      <a href="?<?= qsMerge(['type' => $k]) ?>" class="option-btn <?= $type === $k ? 'selected' : '' ?>" style="white-space:nowrap"><?= e($v) ?></a>
    <?php endforeach; ?>
  </div>

  <form method="get" class="flex gap-2 mb-4">
    <?php if ($deal !== 'all'): ?><input type="hidden" name="deal" value="<?= e($deal) ?>"><?php endif; ?>
    <?php if ($type !== 'all'): ?><input type="hidden" name="type" value="<?= e($type) ?>"><?php endif; ?>
    <?php if ($q !== ''): ?><input type="hidden" name="q" value="<?= e($q) ?>"><?php endif; ?>
    <select name="sort" onchange="this.form.submit()" class="form-select" style="width:auto;font-size:13px">
      <option value="newest" <?= $sort === 'newest' ? 'selected' : '' ?>>جدیدترین</option>
      <option value="cheap" <?= $sort === 'cheap' ? 'selected' : '' ?>>ارزان‌ترین</option>
      <option value="expensive" <?= $sort === 'expensive' ? 'selected' : '' ?>>گران‌ترین</option>
      <option value="area" <?= $sort === 'area' ? 'selected' : '' ?>>بزرگ‌ترین متراژ</option>
      <option value="views" <?= $sort === 'views' ? 'selected' : '' ?>>پربازدیدترین</option>
    </select>
    <button type="submit" class="btn-primary px-6 py-2.5 rounded-2xl text-[13px]">اعمال جستجو</button>
  </form>

  <?php if (empty($items)): ?>
    <div class="card p-8 text-center">
      <div class="text-4xl mb-2">🏠</div>
      <div class="font-extrabold text-sm" style="color:var(--text-primary)">ملکی یافت نشد</div>
      <a href="<?= SITE_URL ?>/request.php" class="btn-gold inline-block px-6 py-2.5 rounded-xl text-[13px] mt-3" style="text-decoration:none">📩 ثبت درخواست</a>
    </div>
  <?php else: ?>
    <div class="space-y-3.5">
      <?php foreach ($items as $p) renderPropertyCard($p); ?>
    </div>
  <?php endif; ?>
  <div class="h-2"></div>
</div>
<?php require __DIR__ . '/includes/layout_foot.php'; ?>
