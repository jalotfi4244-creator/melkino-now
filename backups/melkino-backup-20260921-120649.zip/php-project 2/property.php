<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/property_query.php';
require_once __DIR__ . '/includes/cards.php';

$id = (int)($_GET['id'] ?? 0);
$stmt = db()->prepare('SELECT * FROM properties WHERE id = ?');
$stmt->execute([$id]);
$p = $stmt->fetch();

if (!$p) {
  header('Location: ' . SITE_URL . '/properties.php');
  exit;
}

// افزایش بازدید
db()->prepare('UPDATE properties SET views = views + 1 WHERE id = ?')->execute([$id]);
$p['views'] = (int)$p['views'] + 1;

// آگهی‌های مشابه (همان نوع، به‌جز خود آگهی)
$similarRes = queryProperties(['type' => $p['type'], 'limit' => 4]);
$similar = array_values(array_filter($similarRes['items'], fn($x) => (int)$x['id'] !== $id));
$similar = array_slice($similar, 0, 3);

// مشاور مربوطه
$agent = null;
if (!empty($p['agent_id'])) {
  $aStmt = db()->prepare('SELECT * FROM agents WHERE id = ?');
  $aStmt->execute([$p['agent_id']]);
  $agent = $aStmt->fetch() ?: null;
}
if (!$agent) {
  $agent = db()->query('SELECT * FROM agents WHERE active = 1 ORDER BY id LIMIT 1')->fetch() ?: null;
}

$pageTitle = e($p['title']) . ' | ' . generalSettings()['siteName'];
$activeNav = '';
require __DIR__ . '/includes/layout_head.php';

$types = PROPERTY_TYPES();
$dealTypes = DEAL_TYPES();
$dealBadge = DEAL_BADGE();
$images = j_decode($p['images'] ?? null, []);
$hasImages = count($images) > 0;
$details = j_decode($p['details'] ?? null, []);
$amenities = j_decode($p['amenities'] ?? null, []);

$DETAIL_LABELS = [
  'flooring' => 'پوشش کف', 'cabinet' => 'کابینت', 'cooling' => 'سرمایش', 'heating' => 'گرمایش',
  'landType' => 'نوع زمین', 'width' => 'عرض زمین', 'length' => 'طول زمین', 'deedStatus' => 'وضعیت سند',
  'ownership' => 'مالکیت', 'treeCount' => 'تعداد درختان', 'treeTypes' => 'نوع درختان',
  'irrigation' => 'آبیاری', 'waterSource' => 'منبع آب', 'paymentTerms' => 'شرایط پرداخت',
  'downPayment' => 'پیش‌پرداخت', 'totalPrice' => 'قیمت کل', 'visitHours' => 'ساعت بازدید',
  'deliveryDate' => 'تاریخ تحویل', 'isNotKeyed' => 'کلیدنخورده', 'exchange' => 'معاوضه',
];

$specs = [];
if ((int)$p['area'] > 0) $specs[] = ['متراژ بنا', formatNumber($p['area']) . ' متر'];
if ((int)$p['land_area'] > 0) $specs[] = ['متراژ زمین', formatNumber($p['land_area']) . ' متر'];
if ((int)$p['rooms'] > 0) $specs[] = ['اتاق', toFaDigits($p['rooms'])];
if ((int)$p['bathrooms'] > 0) $specs[] = ['سرویس', toFaDigits($p['bathrooms'])];
if ((int)$p['total_floors'] > 0) $specs[] = ['طبقه', toFaDigits($p['floor']) . ' از ' . toFaDigits($p['total_floors'])];
if ((int)$p['year_built'] > 1300) $specs[] = ['سال ساخت', toFaDigits($p['year_built'])];
foreach ($DETAIL_LABELS as $k => $label) {
  $v = $details[$k] ?? null;
  if ($v === null || $v === '' || $v === false) continue;
  if (is_numeric($v) && in_array($k, ['downPayment', 'totalPrice'])) $specs[] = [$label, formatToman($v)];
  elseif (is_bool($v)) $specs[] = [$label, 'دارد'];
  else $specs[] = [$label, toFaDigits((string)$v)];
}
?>
<div class="px-4 pt-4">
  <!-- گالری -->
  <div class="relative rounded-[24px] overflow-hidden h-64 card !p-0" id="gallery" style="padding:0">
    <?php if ($hasImages): ?>
      <?php foreach ($images as $i => $img): ?>
        <img src="<?= e(propertyImageUrl($img)) ?>" data-gallery-img="<?= $i ?>" class="w-full h-full object-cover gallery-slide" style="<?= $i === 0 ? '' : 'display:none' ?>; position:absolute; inset:0">
      <?php endforeach; ?>
    <?php else: ?>
      <div class="w-full h-full flex items-center justify-center" style="background:var(--bg-secondary);color:var(--text-muted)">بدون تصویر</div>
    <?php endif; ?>
    <div class="absolute inset-0" style="background:linear-gradient(to top, rgba(0,0,0,.4), transparent 40%)"></div>
    <div class="absolute top-3 right-3 flex gap-1.5">
      <span class="badge" style="background:var(--primary);color:#fff">🏷️ <?= e($dealBadge[$p['deal_type']] ?? '') ?></span>
    </div>
    <div class="absolute top-3 left-3 flex gap-1.5">
      <button onclick="melkinoToggleFav(<?= $id ?>)" id="favBtn" class="w-9 h-9 rounded-xl flex items-center justify-center text-white" style="background:rgba(0,0,0,.45)">🤍</button>
      <button onclick="melkinoShare()" class="w-9 h-9 rounded-xl flex items-center justify-center text-white" style="background:rgba(0,0,0,.45)">🔗</button>
    </div>
    <?php if (count($images) > 1): ?>
      <button onclick="melkinoGallery(1)" class="absolute right-2 top-1/2 -translate-y-1/2 w-9 h-9 rounded-full text-white flex items-center justify-center" style="background:rgba(0,0,0,.5)">›</button>
      <button onclick="melkinoGallery(-1)" class="absolute left-2 top-1/2 -translate-y-1/2 w-9 h-9 rounded-full text-white flex items-center justify-center" style="background:rgba(0,0,0,.5)">‹</button>
    <?php endif; ?>
    <div class="absolute bottom-3 right-3 badge" style="background:rgba(0,0,0,.55);color:#fff">📸 <span id="galleryCount"><?= $hasImages ? (toFaDigits(1) . ' / ' . toFaDigits(count($images))) : 'بدون تصویر' ?></span></div>
    <div class="absolute bottom-3 left-3 flex items-center gap-1 text-[11px] text-white/90">👁️ <?= formatNumber($p['views']) ?></div>
  </div>

  <!-- کد + عنوان -->
  <div class="card p-4 mt-3">
    <div class="flex items-center justify-between text-[12px] mb-1.5">
      <span style="color:var(--text-muted)">کد ملک: <b dir="ltr" class="font-mono"><?= e($p['code']) ?></b></span>
      <span style="color:var(--text-muted)">ملکینو • <?= e($types[$p['type']] ?? $p['type']) ?></span>
    </div>
    <h1 class="font-black text-[18px] leading-8" style="color:var(--text-primary)"><?= e($p['title']) ?></h1>
    <div class="flex items-center gap-1.5 mt-2 flex-wrap">
      <span class="badge badge-primary">🏷️ <?= e($dealTypes[$p['deal_type']] ?? ($dealBadge[$p['deal_type']] ?? '')) ?></span>
      <span class="badge" style="background:var(--bg-secondary);color:var(--text-secondary)">📍 <?= e($p['neighborhood']) ?> — <?= e($p['address']) ?></span>
    </div>
  </div>

  <!-- شرایط معامله -->
  <div class="card p-4 mt-3" style="border-color:var(--gold);border-width:1.5px">
    <h2 class="font-black text-[14px] mb-2.5" style="color:var(--gold-dark)">💰 شرایط معامله</h2>
    <?php if ($p['deal_type'] === 'rent'): ?>
      <div class="space-y-1.5 text-[14px] font-extrabold" style="color:var(--text-primary)">
        <div>💰 ودیعه: <?= formatToman($p['mortgage_price']) ?></div>
        <div>💰 اجاره ماهانه: <?= formatToman($p['rent_price']) ?></div>
      </div>
    <?php else: ?>
      <div class="space-y-1.5 text-[14px] font-extrabold" style="color:var(--text-primary)">
        <div>💰 قیمت <?= $p['deal_type'] === 'presale' ? 'پیش‌فروش' : 'فروش' ?>: <?= formatToman($p['price']) ?></div>
        <?php if ((int)$p['price_per_meter'] > 0): ?><div>💰 قیمت هر متر مربع: <?= formatToman($p['price_per_meter']) ?></div><?php endif; ?>
      </div>
    <?php endif; ?>
  </div>

  <!-- مشخصات -->
  <?php if (!empty($specs)): ?>
    <div class="card p-4 mt-3">
      <h2 class="font-black text-[14px] mb-3" style="color:var(--text-primary)">📋 مشخصات ملک</h2>
      <div class="grid grid-cols-2 gap-2">
        <?php foreach ($specs as [$k, $v]): ?>
          <div class="rounded-xl px-3 py-2.5 text-center" style="background:var(--surface-soft);border:1px solid var(--border-light)">
            <div class="text-[11px]" style="color:var(--text-muted)"><?= e($k) ?></div>
            <div class="font-extrabold text-[13px] mt-0.5" style="color:var(--text-primary)"><?= e($v) ?></div>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  <?php endif; ?>

  <!-- امکانات -->
  <?php if (!empty($amenities)): ?>
    <div class="card p-4 mt-3">
      <h2 class="font-black text-[14px] mb-3" style="color:var(--text-primary)">✨ امکانات ملک</h2>
      <div class="grid grid-cols-2 gap-2">
        <?php foreach ($amenities as $a): ?>
          <div class="flex items-center gap-1.5 rounded-xl px-3 py-2 text-[12.5px] font-bold" style="background:color-mix(in srgb, var(--primary-light) 9%, transparent);color:var(--text-primary)">
            ✓ <?= e($a) ?>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  <?php endif; ?>

  <!-- توضیحات -->
  <?php if (!empty($p['description'])): ?>
    <div class="card p-4 mt-3">
      <h2 class="font-black text-[14px] mb-2" style="color:var(--text-primary)">📝 توضیحات</h2>
      <p class="text-[13.5px] leading-7" style="color:var(--text-secondary);white-space:pre-line"><?= e($p['description']) ?></p>
    </div>
  <?php endif; ?>

  <!-- مشاور -->
  <div class="card p-4 mt-3">
    <div class="flex items-center gap-3">
      <div class="w-14 h-14 rounded-2xl flex items-center justify-center text-2xl shrink-0" style="background:color-mix(in srgb, var(--gold) 18%, transparent)">👤</div>
      <div class="flex-1">
        <div class="font-black text-[15px]" style="color:var(--text-primary)"><?= e($agent['name'] ?? 'مشاور ملکینو') ?></div>
        <div class="text-[12px]" style="color:var(--text-muted)"><?= e($agent['title'] ?? 'مشاور ملکینو') ?></div>
      </div>
      <span class="badge badge-success">آنلاین</span>
    </div>
    <div class="grid grid-cols-2 gap-2 mt-3">
      <a href="tel:<?= e(preg_replace('/\s/', '', $agent['phone'] ?? '09123730000')) ?>" class="btn-primary py-3 rounded-2xl text-[13px] flex items-center justify-center gap-1.5" style="text-decoration:none">📞 تماس با مشاور</a>
      <a href="<?= SITE_URL ?>/contact.php" class="btn-gold py-3 rounded-2xl text-[13px] flex items-center justify-center gap-1.5" style="text-decoration:none">💬 پیام به مشاور</a>
    </div>
  </div>

  <!-- مشابه -->
  <?php if (!empty($similar)): ?>
    <div class="mt-5">
      <h2 class="font-black text-[15px] mb-3" style="color:var(--text-primary)">آگهی‌های مشابه</h2>
      <div class="space-y-3.5">
        <?php foreach ($similar as $s) renderPropertyCard($s); ?>
      </div>
    </div>
  <?php endif; ?>
  <div class="h-2"></div>
</div>

<script>
var galleryImgs = document.querySelectorAll('.gallery-slide');
var galleryIdx = 0;
function melkinoGallery(dir){
  if (!galleryImgs.length) return;
  galleryImgs[galleryIdx].style.display = 'none';
  galleryIdx = (galleryIdx + dir + galleryImgs.length) % galleryImgs.length;
  galleryImgs[galleryIdx].style.display = 'block';
  document.getElementById('galleryCount').textContent = (galleryIdx + 1) + ' / ' + galleryImgs.length;
}
function melkinoToggleFav(id){
  try {
    var arr = JSON.parse(localStorage.getItem('melkino_favs') || '[]');
    var i = arr.indexOf(id);
    if (i >= 0) arr.splice(i, 1); else arr.push(id);
    localStorage.setItem('melkino_favs', JSON.stringify(arr));
    document.getElementById('favBtn').textContent = arr.indexOf(id) >= 0 ? '❤️' : '🤍';
  } catch(e){}
}
(function(){
  try {
    var arr = JSON.parse(localStorage.getItem('melkino_favs') || '[]');
    if (arr.indexOf(<?= $id ?>) >= 0) document.getElementById('favBtn').textContent = '❤️';
  } catch(e){}
})();
function melkinoShare(){
  if (navigator.share) { navigator.share({ title: document.title, url: window.location.href }).catch(function(){}); }
  else { navigator.clipboard.writeText(window.location.href); alert('لینک آگهی کپی شد ✓'); }
}
</script>

<?php require __DIR__ . '/includes/layout_foot.php'; ?>
