<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/sell_config.php';

$pageTitle = generalSettings()['siteName'] . ' | ثبت درخواست';
$activeNav = '';
require __DIR__ . '/includes/layout_head.php';

$PROPERTY_TYPES = [
  'apartment' => 'آپارتمان', 'villa' => 'ویلا', 'land' => 'زمین',
  'garden' => 'باغ', 'office' => 'اداری', 'commercial' => 'تجاری',
];
$DEALS = ['sale' => 'فروش', 'presale' => 'پیش فروش', 'rent' => 'اجاره', 'invest' => 'سرمایه‌گذاری'];
$AMENITIES = SELL_AMENITIES();
$ALL_AMENITIES = array_values(array_unique(array_merge(...array_values($AMENITIES))));
?>
<div class="px-4 pt-4 flex flex-col" style="min-height:70vh">
  <div class="flex items-center gap-2.5 mb-4">
    <div class="w-10 h-10 rounded-2xl flex items-center justify-center text-lg" style="background:color-mix(in srgb, var(--primary-light) 14%, transparent)">📄</div>
    <div class="flex-1">
      <div class="font-black text-[14px]" style="color:var(--text-primary)">ثبت درخواست ملک</div>
      <div class="text-[12px]" style="color:var(--text-muted)">مرحله <span id="stepLabel">۱</span> از ۵</div>
    </div>
  </div>
  <div class="h-1.5 rounded-full mb-5" style="background:var(--bg-tertiary)">
    <div id="progressBar" class="h-full rounded-full" style="width:20%;background:linear-gradient(90deg,var(--primary-light),var(--primary));transition:width .4s"></div>
  </div>

  <form method="post" action="<?= SITE_URL ?>/request_submit.php" class="card p-5 flex-1 flex flex-col" id="reqForm">
    <input type="hidden" name="gender" id="f_gender" value="آقا">
    <input type="hidden" name="dealType" id="f_dealType" value="sale">
    <input type="hidden" name="propertyType" id="f_propertyType" value="apartment">
    <input type="hidden" name="noPriority" id="f_noPriority" value="">

    <!-- STEP 1 -->
    <div class="step-content active" data-step="1">
      <h2 class="step-title mb-1">👤 اطلاعات تماس</h2>
      <p class="step-subtitle mb-4">لطفاً اطلاعات خود را وارد کنید.</p>
      <div class="form-group">
        <label>جنسیت</label>
        <div class="options-group">
          <button type="button" class="option-btn selected" data-val="آقا" onclick="rqSelect(this,'f_gender')">آقا</button>
          <button type="button" class="option-btn" data-val="خانم" onclick="rqSelect(this,'f_gender')">خانم</button>
        </div>
      </div>
      <div class="form-group">
        <label>نام خانوادگی</label>
        <input class="form-input" name="lastName" id="lastName" placeholder="نام خانوادگی خود را وارد کنید">
      </div>
      <div class="form-group">
        <label>شماره تماس</label>
        <input type="tel" class="form-input" name="phone" id="phone" placeholder="مثلاً ۰۹۱۲۳۴۵۶۷۸۹" dir="ltr" style="text-align:right">
      </div>
    </div>

    <!-- STEP 2 -->
    <div class="step-content" data-step="2">
      <h2 class="step-title mb-1">💱 نوع معامله</h2>
      <p class="step-subtitle mb-4">نوع معامله‌ی مورد نظر خود را انتخاب کنید.</p>
      <div class="options-group" style="display:grid;grid-template-columns:1fr 1fr">
        <?php foreach ($DEALS as $k => $v): ?>
          <button type="button" class="option-btn <?= $k === 'sale' ? 'selected' : '' ?>" data-val="<?= $k ?>" onclick="rqSelect(this,'f_dealType'); rqDealChanged('<?= $k ?>')" style="justify-content:center"><?= e($v) ?></button>
        <?php endforeach; ?>
      </div>
      <div id="investNote" class="rounded-2xl p-4 text-[12.5px] leading-7 mt-4" style="background:var(--gold-bg);color:var(--gold-dark);display:none">
        <b>💡 مدل سرمایه‌گذاری:</b><br>
        اولویت نوع ملک‌ها را در مرحله بعد مشخص کنید؛ بین فایل‌های فروش و پیش‌فروش، بهترین گزینه‌ها را می‌یابیم.
      </div>
    </div>

    <!-- STEP 3 -->
    <div class="step-content" data-step="3">
      <h2 class="step-title mb-1" id="step3Title">🏠 نوع ملک</h2>
      <p class="step-subtitle mb-4" id="step3Sub">نوع ملک مورد نظر خود را انتخاب کنید</p>

      <div class="form-group" id="singleTypeGroup">
        <label>نوع اصلی ملک</label>
        <div class="options-group" style="display:grid;grid-template-columns:1fr 1fr 1fr">
          <?php foreach ($PROPERTY_TYPES as $k => $v): ?>
            <button type="button" class="option-btn <?= $k === 'apartment' ? 'selected' : '' ?>" data-val="<?= $k ?>" onclick="rqSelect(this,'f_propertyType'); rqTypeChanged('<?= $k ?>')" style="justify-content:center"><?= e($v) ?></button>
          <?php endforeach; ?>
        </div>
      </div>

      <div id="prioritiesGroup" style="display:none">
        <div class="form-group">
          <label>اولویت‌های نوع ملک (به ترتیب اهمیت)</label>
          <div class="space-y-2.5">
            <div class="flex items-center gap-3">
              <span class="badge badge-gold" style="min-height:38px;padding:0 12px">اولویت اول</span>
              <select class="form-select flex-1" name="p1">
                <option value="">انتخاب کنید</option>
                <?php foreach ($PROPERTY_TYPES as $k => $v): ?><option value="<?= $k ?>"><?= e($v) ?></option><?php endforeach; ?>
              </select>
            </div>
            <div class="flex items-center gap-3">
              <span class="badge" style="min-height:38px;padding:0 12px;background:var(--bg-secondary);color:var(--text-secondary)">اولویت دوم</span>
              <select class="form-select flex-1" name="p2">
                <option value="">انتخاب کنید</option>
                <?php foreach ($PROPERTY_TYPES as $k => $v): ?><option value="<?= $k ?>"><?= e($v) ?></option><?php endforeach; ?>
              </select>
            </div>
            <div class="flex items-center gap-3">
              <span class="badge" style="min-height:38px;padding:0 12px;background:var(--bg-secondary);color:var(--text-muted)">اولویت سوم</span>
              <select class="form-select flex-1" name="p3">
                <option value="">انتخاب کنید</option>
                <?php foreach ($PROPERTY_TYPES as $k => $v): ?><option value="<?= $k ?>"><?= e($v) ?></option><?php endforeach; ?>
              </select>
            </div>
          </div>
        </div>
        <label class="amen-check mb-3"><input type="checkbox" id="noPriorityChk" onchange="document.getElementById('f_noPriority').value = this.checked ? '1' : ''"> بدون اولویت (همه نوع ملک قابل قبول)</label>
      </div>

      <div class="form-group">
        <label>محله / منطقه</label>
        <input class="form-input" name="location" placeholder="محله یا منطقه مورد نظر را وارد کنید">
      </div>
      <div class="form-group">
        <label>فوریت درخواست</label>
        <input type="hidden" name="urgency" id="f_urgency" value="عادی">
        <div class="options-group">
          <?php foreach (['عادی', 'فوری', 'خیلی فوری'] as $u): ?>
            <button type="button" class="option-btn <?= $u === 'عادی' ? 'selected' : '' ?>" data-val="<?= $u ?>" onclick="rqSelect(this,'f_urgency')"><?= e($u) ?></button>
          <?php endforeach; ?>
        </div>
      </div>
      <div id="rahnKamalWrap" style="display:none">
        <label class="amen-check mb-3"><input type="checkbox" name="rahnKamal" value="1"> دنبال رهن کامل می‌گردم</label>
      </div>
      <div class="form-group">
        <label>تاریخ نیاز</label>
        <input type="date" class="form-input" name="dateNeeded">
      </div>
    </div>

    <!-- STEP 4 -->
    <div class="step-content" data-step="4">
      <h2 class="step-title mb-1">🎚️ فیلترهای جستجو</h2>
      <p class="step-subtitle mb-4">هرچه دقیق‌تر بنویسید، نتیجه بهتر می‌شود</p>

      <div id="investBudgetNote" class="rounded-2xl p-3.5 text-[12px] leading-6 mb-3" style="background:var(--gold-bg);color:var(--gold-dark);display:none">
        💰 برای <b>سرمایه‌گذاری</b> فقط بازه بودجه‌تان را مشخص کنید؛ بقیه به‌صورت خودکار روی فایل‌های فروش و پیش‌فروش اعمال می‌شود.
      </div>

      <div class="deal-price-sale">
        <div class="row-half">
          <div class="form-group"><label>حداقل قیمت (تومان)</label><input class="form-input" name="minPrice" inputmode="numeric" placeholder="۵۰,۰۰۰,۰۰۰"></div>
          <div class="form-group"><label>حداکثر قیمت (تومان)</label><input class="form-input" name="maxPrice" inputmode="numeric" placeholder="۲,۰۰۰,۰۰۰,۰۰۰"></div>
        </div>
      </div>
      <div class="deal-price-rent" style="display:none">
        <div class="row-half">
          <div class="form-group"><label>حداقل ودیعه (تومان)</label><input class="form-input" name="minDeposit" inputmode="numeric" placeholder="۲۰۰,۰۰۰,۰۰۰"></div>
          <div class="form-group"><label>حداکثر ودیعه (تومان)</label><input class="form-input" name="maxDeposit" inputmode="numeric" placeholder="۵۰۰,۰۰۰,۰۰۰"></div>
        </div>
        <div class="row-half">
          <div class="form-group"><label>حداقل اجاره ماهانه</label><input class="form-input" name="minRent" inputmode="numeric" placeholder="۲۰,۰۰۰,۰۰۰"></div>
          <div class="form-group"><label>حداکثر اجاره ماهانه</label><input class="form-input" name="maxRent" inputmode="numeric" placeholder="۵۰,۰۰۰,۰۰۰"></div>
        </div>
      </div>

      <div id="notInvestExtra">
        <div class="row-half mt-3">
          <div class="form-group"><label>حداقل متراژ (متر مربع)</label><input type="number" class="form-input" name="minArea" min="0" placeholder="۶۰"></div>
          <div class="form-group"><label>حداکثر متراژ (متر مربع)</label><input type="number" class="form-input" name="maxArea" min="0" placeholder="۱۲۰"></div>
        </div>
        <div class="row-half">
          <div class="form-group"><label>حداقل سن بنا (سال)</label><input class="form-input" name="minAge" inputmode="numeric" placeholder="۲"></div>
          <div class="form-group"><label>حداکثر سن بنا (سال)</label><input class="form-input" name="maxAge" inputmode="numeric" placeholder="۱۰"></div>
        </div>
        <label class="amen-check mb-3"><input type="checkbox" name="isNotKeyed" value="1"> کلید نخورده</label>

        <div class="ptype-extra ptype-apartment">
          <div class="row-half">
            <div class="form-group">
              <label>تعداد اتاق</label>
              <select class="form-select" name="rooms">
                <option value="">انتخاب کنید</option>
                <?php foreach ([1,2,3,4,5] as $n): ?><option value="<?= $n ?>"><?= toFaDigits($n) ?></option><?php endforeach; ?>
              </select>
            </div>
            <div class="form-group"><label>طبقه</label><input class="form-input" name="floor" inputmode="numeric" placeholder="۳"></div>
          </div>
          <div class="row-half">
            <div class="form-group">
              <label>نوع کفپوش</label>
              <select class="form-select" name="flooring"><option value="">انتخاب کنید</option><?php foreach (FLOORING_OPTIONS() as $o): ?><option value="<?= e($o) ?>"><?= e($o) ?></option><?php endforeach; ?></select>
            </div>
            <div class="form-group">
              <label>نوع کابینت</label>
              <select class="form-select" name="cabinet"><option value="">انتخاب کنید</option><?php foreach (CABINET_OPTIONS() as $o): ?><option value="<?= e($o) ?>"><?= e($o) ?></option><?php endforeach; ?></select>
            </div>
          </div>
          <div class="row-half">
            <div class="form-group">
              <label>سیستم سرمایش</label>
              <select class="form-select" name="cooling"><option value="">انتخاب کنید</option><?php foreach (COOLING_OPTIONS() as $o): ?><option value="<?= e($o) ?>"><?= e($o) ?></option><?php endforeach; ?></select>
            </div>
            <div class="form-group">
              <label>سیستم گرمایش</label>
              <select class="form-select" name="heating"><option value="">انتخاب کنید</option><?php foreach (HEATING_OPTIONS() as $o): ?><option value="<?= e($o) ?>"><?= e($o) ?></option><?php endforeach; ?></select>
            </div>
          </div>
        </div>

        <div class="ptype-extra ptype-villa" style="display:none">
          <div class="form-group">
            <label>وضعیت ملک</label>
            <input type="hidden" name="condition" id="f_condition">
            <div class="options-group">
              <?php foreach (['نوساز', 'بازسازی‌شده', 'قدیمی'] as $c): ?>
                <button type="button" class="option-btn" data-val="<?= $c ?>" onclick="rqToggle(this,'f_condition')"><?= e($c) ?></button>
              <?php endforeach; ?>
            </div>
          </div>
          <div class="form-group">
            <label>جهت ملک</label>
            <input type="hidden" name="orientation" id="f_orientation">
            <div class="options-group">
              <?php foreach (['شمالی', 'جنوبی', 'شرقی', 'غربی'] as $c): ?>
                <button type="button" class="option-btn" data-val="<?= $c ?>" onclick="rqToggle(this,'f_orientation')"><?= e($c) ?></button>
              <?php endforeach; ?>
            </div>
          </div>
        </div>

        <div class="ptype-extra ptype-land" style="display:none">
          <div class="form-group">
            <label>نوع زمین</label>
            <input type="hidden" name="landType" id="f_landType">
            <div class="options-group">
              <?php foreach (LAND_TYPES_OPT() as $c): ?>
                <button type="button" class="option-btn" data-val="<?= $c ?>" onclick="rqToggle(this,'f_landType')"><?= e($c) ?></button>
              <?php endforeach; ?>
            </div>
          </div>
          <div class="form-group">
            <label>وضعیت سند</label>
            <select class="form-select" name="deedStatus"><option value="">انتخاب کنید</option><?php foreach (DEED_STATUS_OPT() as $o): ?><option value="<?= e($o) ?>"><?= e($o) ?></option><?php endforeach; ?></select>
          </div>
        </div>
      </div>

      <!-- amenities: یک بلوک به‌ازای هر نوع ملک + یک بلوک برای حالت سرمایه‌گذاری -->
      <div class="form-group mt-2">
        <label>امکانات مورد نظر</label>
        <?php foreach ($AMENITIES as $ptype => $list): ?>
          <div class="grid grid-cols-2 gap-2 amenities-block amenities-<?= $ptype ?>" style="<?= $ptype === 'apartment' ? '' : 'display:none' ?>">
            <?php foreach ($list as $a): ?>
              <label class="amen-check"><input type="checkbox" name="amenities[]" value="<?= e($a) ?>"> <?= e($a) ?></label>
            <?php endforeach; ?>
          </div>
        <?php endforeach; ?>
        <div class="grid grid-cols-2 gap-2 amenities-block amenities-invest" style="display:none">
          <?php foreach ($ALL_AMENITIES as $a): ?>
            <label class="amen-check"><input type="checkbox" name="amenities[]" value="<?= e($a) ?>"> <?= e($a) ?></label>
          <?php endforeach; ?>
        </div>
      </div>
    </div>

    <!-- STEP 5 -->
    <div class="step-content" data-step="5">
      <h2 class="step-title mb-1">📩 زمان‌بندی و ثبت نهایی</h2>
      <p class="step-subtitle mb-4">درخواست شما با موتور تطبیق هوشمند ملکینو، بلافاصله با آگهی‌های فعال مقایسه می‌شود.</p>
      <div class="rounded-2xl p-4" style="background:var(--surface-soft);border:1px solid var(--border-light)">
        <div class="font-black text-[13px] mb-2.5" style="color:var(--text-primary)">📋 پیش از ثبت</div>
        <div class="text-[12.5px] leading-7" style="color:var(--text-secondary)">
          اطلاعات مراحل قبل ثبت شده‌اند. با زدن دکمه «ثبت نهایی درخواست»، سیستم بلافاصله نزدیک‌ترین آگهی‌های فعال را به شما نشان می‌دهد.
        </div>
      </div>
      <div class="form-group mt-4">
        <label>توضیحات تکمیلی</label>
        <textarea class="form-textarea" name="notes" rows="3" placeholder="اگر نیاز یا خواسته‌ای دارید که در فرم وجود ندارد، اینجا بنویسید..."></textarea>
      </div>
      <div class="rounded-2xl p-3.5 text-[12px] leading-6" style="background:var(--info-bg,#EAF3FF);color:var(--info,#2563EB)">
        📍 پس از ثبت، نزدیک‌ترین آگهی‌های فعال به درخواست شما را به‌صورت زنده نشان می‌دهیم و از آرشیو جدیدها هم عقب نمی‌مانید.
      </div>
    </div>

    <div class="bottom-actions">
      <button type="button" id="btnPrev" class="btn-secondary px-6 rounded-2xl text-sm" style="display:none" onclick="rqStep(-1)">مرحله قبل</button>
      <button type="button" id="btnNext" class="btn-primary btn-primary-full py-3.5 rounded-2xl text-sm" onclick="rqStep(1)">مرحله بعد</button>
      <button type="submit" id="btnSubmit" class="btn-gold btn-primary-full py-3.5 rounded-2xl text-sm" style="display:none">📩 ثبت نهایی درخواست</button>
    </div>
  </form>
</div>

<script>
var rqCur = 1, rqTotal = 5;
var faNum = function(n){ var fa=['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹']; return String(n).replace(/[0-9]/g,function(d){return fa[d];}); };

function rqSelect(btn, hiddenId){
  var group = btn.parentElement;
  Array.prototype.forEach.call(group.children, function(b){ b.classList.remove('selected'); });
  btn.classList.add('selected');
  document.getElementById(hiddenId).value = btn.getAttribute('data-val');
}
function rqToggle(btn, hiddenId){
  var group = btn.parentElement;
  var hidden = document.getElementById(hiddenId);
  var val = btn.getAttribute('data-val');
  if (btn.classList.contains('selected')) { btn.classList.remove('selected'); hidden.value=''; }
  else {
    Array.prototype.forEach.call(group.children, function(b){ b.classList.remove('selected'); });
    btn.classList.add('selected'); hidden.value = val;
  }
}
function rqDealChanged(deal){
  var isInvest = deal === 'invest';
  document.getElementById('investNote').style.display = isInvest ? 'block' : 'none';
  document.getElementById('singleTypeGroup').style.display = isInvest ? 'none' : 'block';
  document.getElementById('prioritiesGroup').style.display = isInvest ? 'block' : 'none';
  document.getElementById('step3Title').textContent = isInvest ? '📊 اولویت‌های نوع ملک' : '🏠 نوع ملک';
  document.getElementById('step3Sub').textContent = isInvest ? 'نوع ملک‌های دلخواه خود را به ترتیب اهمیت انتخاب کنید' : 'نوع ملک مورد نظر خود را انتخاب کنید';
  document.getElementById('rahnKamalWrap').style.display = deal === 'rent' ? 'block' : 'none';
  document.getElementById('investBudgetNote').style.display = isInvest ? 'block' : 'none';
  document.getElementById('notInvestExtra').style.display = isInvest ? 'none' : 'block';

  document.querySelectorAll('.deal-price-sale, .deal-price-rent').forEach(function(el){ el.style.display = 'none'; });
  document.querySelector(deal === 'rent' ? '.deal-price-rent' : '.deal-price-sale').style.display = 'block';

  document.querySelectorAll('.amenities-block').forEach(function(el){ el.style.display = 'none'; });
  if (isInvest) {
    document.querySelector('.amenities-invest').style.display = 'grid';
  } else {
    var t = document.getElementById('f_propertyType').value || 'apartment';
    var el = document.querySelector('.amenities-' + t);
    if (el) el.style.display = 'grid';
  }
}
function rqTypeChanged(type){
  document.querySelectorAll('.ptype-extra').forEach(function(el){ el.style.display = 'none'; });
  var pe = document.querySelector('.ptype-' + type);
  if (pe) pe.style.display = 'block';
  if (document.getElementById('f_dealType').value !== 'invest') {
    document.querySelectorAll('.amenities-block').forEach(function(el){ el.style.display = 'none'; });
    var el = document.querySelector('.amenities-' + type);
    if (el) el.style.display = 'grid';
  }
}

function rqStep(dir){
  if (rqCur === 1 && dir === 1) {
    var ln = document.getElementById('lastName').value.trim();
    var ph = document.getElementById('phone').value.trim();
    if (!ln) { alert('لطفاً نام خانوادگی خود را وارد کنید.'); return; }
    if (!/^0?9\d{9}$/.test(ph.replace(/\s/g,''))) { alert('لطفاً یک شماره موبایل معتبر وارد کنید.'); return; }
  }
  var next = rqCur + dir;
  if (next < 1 || next > rqTotal) return;
  document.querySelector('.step-content[data-step="'+rqCur+'"]').classList.remove('active');
  rqCur = next;
  document.querySelector('.step-content[data-step="'+rqCur+'"]').classList.add('active');
  document.getElementById('stepLabel').textContent = faNum(rqCur);
  document.getElementById('progressBar').style.width = (rqCur/rqTotal*100) + '%';
  document.getElementById('btnPrev').style.display = rqCur === 1 ? 'none' : 'flex';
  document.getElementById('btnNext').style.display = rqCur === rqTotal ? 'none' : 'flex';
  document.getElementById('btnSubmit').style.display = rqCur === rqTotal ? 'flex' : 'none';
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

// بازیابی شماره تلفن ذخیره‌شده قبلی
(function(){
  try { var ph = localStorage.getItem('melkino_user_phone'); if (ph) document.getElementById('phone').value = ph; } catch(e){}
})();
</script>

<?php require __DIR__ . '/includes/layout_foot.php'; ?>
