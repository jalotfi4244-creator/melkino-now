<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/match.php';
require_once __DIR__ . '/includes/cards.php';

$id = (int)($_GET['id'] ?? 0);
$stmt = db()->prepare('SELECT * FROM requests WHERE id = ?');
$stmt->execute([$id]);
$reqRow = $stmt->fetch();
if (!$reqRow) {
  header('Location: ' . SITE_URL . '/home.php');
  exit;
}

$isInvest = $reqRow['deal_type'] === 'invest';
$req = [
  'dealType' => $reqRow['deal_type'],
  'propertyType' => $reqRow['property_type'],
  'priorities' => j_decode($reqRow['priorities'], []),
  'noPriority' => (bool)$reqRow['no_priority'],
  'location' => $reqRow['location'],
  'minPrice' => (float)$reqRow['min_price'], 'maxPrice' => (float)$reqRow['max_price'],
  'minDeposit' => (float)$reqRow['min_deposit'], 'maxDeposit' => (float)$reqRow['max_deposit'],
  'minRent' => (float)$reqRow['min_rent'], 'maxRent' => (float)$reqRow['max_rent'],
  'minArea' => (float)$reqRow['min_area'], 'maxArea' => (float)$reqRow['max_area'],
  'minAge' => (float)$reqRow['min_age'], 'maxAge' => (float)$reqRow['max_age'],
  'rooms' => (int)$reqRow['rooms'],
  'amenities' => j_decode($reqRow['amenities'], []),
  'rahnKamal' => (bool)$reqRow['rahn_kamal'],
];

$candidates = db()->query("SELECT * FROM properties WHERE status = 'available'")->fetchAll();
if ($isInvest) {
  $candidates = array_values(array_filter($candidates, fn($p) => in_array($p['deal_type'], ['sale', 'presale'])));
}

$scored = [];
foreach ($candidates as $p) {
  $r = scoreProperty($req, $p);
  if ($r['score'] >= 35) {
    $scored[] = ['p' => $p, 'score' => $r['score'], 'reasons' => $r['reasons']];
  }
}
usort($scored, fn($a, $b) => $b['score'] <=> $a['score']);
$scored = array_slice($scored, 0, 4);

$pageTitle = generalSettings()['siteName'] . ' | درخواست ثبت شد';
$activeNav = '';
require __DIR__ . '/includes/layout_head.php';
?>
<div class="px-4 pt-8 flex flex-col items-center">
  <div class="w-20 h-20 rounded-full flex items-center justify-center mb-4" style="background:var(--success-bg)">
    <span style="font-size:36px;color:var(--success)">✔</span>
  </div>
  <h1 class="font-black text-[19px]" style="color:var(--text-primary)">درخواست شما ثبت شد 📩</h1>
  <p class="text-[13px] leading-6 text-center mt-1.5" style="color:var(--text-secondary)">
    کد پیگیری: <b dir="ltr"><?= e($reqRow['code']) ?></b><br>
    مشاوران ملکینو با شماره شما تماس می‌گیرند
  </p>

  <div class="w-full mt-7">
    <div class="flex items-center gap-2 mb-1">
      <span style="color:var(--gold-dark)">✨</span>
      <h2 class="font-black text-[16px]" style="color:var(--text-primary)">نزدیک‌ترین آگهی‌ها به خواسته شما</h2>
    </div>
    <p class="text-[12px] mb-4" style="color:var(--text-muted)">ما بین آگهی‌های فعال به‌دنبال فایل‌هایی که به خواسته‌تان نزدیک‌ترند، گشتیم:</p>

    <?php if (empty($scored)): ?>
      <div class="card p-6 text-center">
        <div class="text-3xl mb-2">🔎</div>
        <div class="font-extrabold text-[14px]" style="color:var(--text-primary)">هنوز آگهی دقیقاً مطابقی نداریم</div>
        <p class="text-[12.5px] mt-2 leading-6" style="color:var(--text-secondary)">
          نگران نباشید! درخواست شما در آرشیو ملکینو ماندگار است و به‌محض ثبت هر آگهی مشابه، اولین نفری هستید که باهاش آشنا می‌شوید.
        </p>
      </div>
    <?php else: ?>
      <div class="space-y-3">
        <?php foreach ($scored as $m): ?>
          <div>
            <div class="flex items-center gap-2 mb-1.5" style="padding-right:4px">
              <span class="badge badge-gold">★ تطابق <?= toFaDigits($m['score']) ?>٪</span>
              <span class="text-[11px] font-bold" style="color:var(--text-secondary)"><?= e(matchLabel($m['score'])) ?></span>
              <?php if (!empty($m['reasons'][0])): ?><span class="text-[11px]" style="color:var(--text-muted)">• <?= e($m['reasons'][0]) ?></span><?php endif; ?>
            </div>
            <?php renderPropertyCard($m['p']); ?>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>

    <div class="grid grid-cols-2 gap-2.5 mt-6">
      <a href="<?= SITE_URL ?>/properties.php" class="btn-secondary py-3.5 rounded-2xl text-[13px]" style="text-decoration:none">مشاهده همه آگهی‌ها</a>
      <a href="<?= SITE_URL ?>/home.php" class="btn-primary py-3.5 rounded-2xl text-[13px]" style="text-decoration:none">بازگشت به خانه</a>
    </div>
  </div>
  <div class="h-4"></div>
</div>
<?php require __DIR__ . '/includes/layout_foot.php'; ?>
