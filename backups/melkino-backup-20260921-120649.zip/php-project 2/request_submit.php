<?php
require_once __DIR__ . '/includes/functions.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  header('Location: ' . SITE_URL . '/request.php');
  exit;
}

function parsePriceVal($v): int {
  $v = toEnDigits((string)($v ?? ''));
  $v = preg_replace('/[^\d]/', '', $v);
  return $v === '' ? 0 : (int)$v;
}

$dealType = $_POST['dealType'] ?? 'sale';
$isInvest = $dealType === 'invest';
$noPriority = !empty($_POST['noPriority']);
$propertyType = $isInvest ? 'all' : ($_POST['propertyType'] ?? 'apartment');
$priorities = $isInvest ? [$_POST['p1'] ?? '', $_POST['p2'] ?? '', $_POST['p3'] ?? ''] : [];
$amenities = !empty($_POST['amenities']) && is_array($_POST['amenities']) ? array_values($_POST['amenities']) : [];

$lastName = trim($_POST['lastName'] ?? '');
$phone = trim($_POST['phone'] ?? '');
if ($lastName === '' || $phone === '') {
  header('Location: ' . SITE_URL . '/request.php?error=missing');
  exit;
}

$exclude = ['gender','dealType','propertyType','noPriority','p1','p2','p3','location','urgency','rahnKamal',
  'dateNeeded','minPrice','maxPrice','minDeposit','maxDeposit','minRent','maxRent','minArea','maxArea',
  'minAge','maxAge','rooms','amenities','notes','lastName','phone'];
$details = [];
foreach ($_POST as $k => $v) {
  if (in_array($k, $exclude)) continue;
  if ($v === '' || $v === null) continue;
  $details[$k] = is_string($v) ? trim($v) : $v;
}

$stmt = db()->prepare(
  'INSERT INTO requests
   (name, phone, gender, deal_type, property_type, priorities, no_priority, location, urgency, date_needed,
    rahn_kamal, min_price, max_price, min_deposit, max_deposit, min_rent, max_rent, min_area, max_area,
    min_age, max_age, rooms, details, amenities, description, code, status)
   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)'
);
$code = 'RQ-' . date('Ymd') . '-' . random_int(1000, 9999);
$stmt->execute([
  $lastName, $phone, $_POST['gender'] ?? 'آقا', $dealType, $propertyType,
  json_encode($priorities, JSON_UNESCAPED_UNICODE), $noPriority ? 1 : 0,
  trim($_POST['location'] ?? ''), $_POST['urgency'] ?? 'عادی', trim($_POST['dateNeeded'] ?? ''),
  !empty($_POST['rahnKamal']) ? 1 : 0,
  parsePriceVal($_POST['minPrice'] ?? 0), parsePriceVal($_POST['maxPrice'] ?? 0),
  parsePriceVal($_POST['minDeposit'] ?? 0), parsePriceVal($_POST['maxDeposit'] ?? 0),
  parsePriceVal($_POST['minRent'] ?? 0), parsePriceVal($_POST['maxRent'] ?? 0),
  (int)($_POST['minArea'] ?? 0), (int)($_POST['maxArea'] ?? 0),
  (int)($_POST['minAge'] ?? 0), (int)($_POST['maxAge'] ?? 0),
  (int)($_POST['rooms'] ?? 0),
  json_encode($details, JSON_UNESCAPED_UNICODE),
  json_encode($amenities, JSON_UNESCAPED_UNICODE),
  trim($_POST['notes'] ?? ''),
  $code, 'new',
]);
$requestId = (int)db()->lastInsertId();

// شناسایی کاربر
if ($phone !== '') {
  $userKey = 'phone_' . preg_replace('/\D/', '', $phone);
  $u = db()->prepare('SELECT id FROM app_users WHERE user_key = ?');
  $u->execute([$userKey]);
  if (!$u->fetch()) {
    db()->prepare('INSERT INTO app_users (user_key, phone, name, platform) VALUES (?,?,?,?)')
       ->execute([$userKey, $phone, $lastName, 'web']);
  }
}

header('Location: ' . SITE_URL . '/request_results.php?id=' . $requestId);
exit;
