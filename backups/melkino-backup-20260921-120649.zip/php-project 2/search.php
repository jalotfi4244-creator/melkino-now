<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/property_query.php';
require_once __DIR__ . '/includes/cards.php';

$pageTitle = generalSettings()['siteName'] . ' | جستجوی ملک';
$activeNav = 'search';

$did = isset($_GET['did']); // آیا فرم ارسال شده؟
$f = [
  'type' => $_GET['type'] ?? '',
  'deal' => $_GET['deal'] ?? '',
  'minPrice' => $_GET['minPrice'] ?? '',
  'maxPrice' => $_GET['maxPrice'] ?? '',
  'minArea' => $_GET['minArea'] ?? '',
  'maxArea' => $_GET['maxArea'] ?? '',
  'rooms' => $_GET['rooms'] ?? '',
  'parking' => isset($_GET['parking']),
  'elevator' => isset($_GET['elevator']),
];

$items = [];
$total = 0;
if ($did) {
  $amenities = [];
  if ($f['parking']) $amenities[] = 'پارکینگ';
  if ($f['elevator']) $amenities[] = 'آسانسور';
  $result = queryProperties([
    'type' => $f['type'] ?: 'all',
    'deal' => $f['deal'] ?: 'all',
    'minPrice' => $f['minPrice'], 'maxPrice' => $f['maxPrice'],
    'minArea' => $f['minArea'], 'maxArea' => $f['maxArea'],
    'rooms' => $f['rooms'] ?: 'all',
    'amenities' => $amenities,
    'limit' => 30,
  ]);
  $items = $result['items'];
  $total = $result['total'];
}

require __DIR__ . '/includes/layout_head.php';
?>
<div class="px-4 pt-4">
  <h1 class="step-title flex items-center gap-2">🎚️ جستجوی ملک</h1>
  <p class="step-subtitle mb-4">فیلترها را تنظیم کن و گزینه مناسب را پیدا کن 🔍</p>

  <form method="get" class="card p-5">
    <input type="hidden" name="did" value="1">
    <h2 class="font-black text-[14px] mb-3" style="color:var(--text-primary)">نوع ملک و معامله</h2>
    <div class="form-group">
      <label>نوع ملک</label>
      <select name="type" class="form-select">
        <option value="">همه</option>
        <?php foreach (PROPERTY_TYPES() as $k => $v): ?>
          <option value="<?= $k ?>" <?= $f['type'] === $k ? 'selected' : '' ?>><?= e($v) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="form-group">
      <label>نوع معامله</label>
      <select name="deal" class="form-select">
        <option value="">همه</option>
        <?php foreach (DEAL_TYPES() as $k => $v): ?>
          <option value="<?= $k ?>" <?= $f['deal'] === $k ? 'selected' : '' ?>><?= e($v) ?></option>
        <?php endforeach; ?>
      </select>
    </div>

    <h2 class="font-black text-[14px] mt-5 mb-1" style="color:var(--text-primary)">بازه قیمت</h2>
    <p class="text-[12px] mb-3" style="color:var(--text-muted)">قیمت را به تومان وارد کنید</p>
    <div class="row-half">
      <div class="form-group">
        <label>حداقل</label>
        <input type="number" name="minPrice" class="form-input" value="<?= e($f['minPrice']) ?>" placeholder="۵۰۰,۰۰۰,۰۰۰">
      </div>
      <div class="form-group">
        <label>حداکثر</label>
        <input type="number" name="maxPrice" class="form-input" value="<?= e($f['maxPrice']) ?>" placeholder="۵,۰۰۰,۰۰۰,۰۰۰">
      </div>
    </div>

    <h2 class="font-black text-[14px] mt-4 mb-1" style="color:var(--text-primary)">بازه متراژ</h2>
    <p class="text-[12px] mb-3" style="color:var(--text-muted)">متراژ به متر مربع</p>
    <div class="row-half">
      <div class="form-group">
        <label>حداقل</label>
        <input type="number" name="minArea" class="form-input" value="<?= e($f['minArea']) ?>" placeholder="۵۰">
      </div>
      <div class="form-group">
        <label>حداکثر</label>
        <input type="number" name="maxArea" class="form-input" value="<?= e($f['maxArea']) ?>" placeholder="۳۰۰">
      </div>
    </div>

    <div class="form-group mt-3">
      <label>تعداد اتاق</label>
      <select name="rooms" class="form-select">
        <option value="">فرقی نمی‌کند</option>
        <?php foreach ([1, 2, 3] as $r): ?>
          <option value="<?= $r ?>" <?= $f['rooms'] == $r ? 'selected' : '' ?>><?= toFaDigits($r) ?> اتاق</option>
        <?php endforeach; ?>
        <option value="4+" <?= $f['rooms'] === '4+' ? 'selected' : '' ?>>۴ اتاق و بیشتر</option>
      </select>
    </div>

    <h2 class="font-black text-[14px] mt-4 mb-2" style="color:var(--text-primary)">امکانات</h2>
    <label class="amen-check"><input type="checkbox" name="parking" <?= $f['parking'] ? 'checked' : '' ?>> 🚗 پارکینگ</label>
    <label class="amen-check mt-1.5"><input type="checkbox" name="elevator" <?= $f['elevator'] ? 'checked' : '' ?>> 🛗 آسانسور</label>

    <div class="grid grid-cols-2 gap-2 mt-5">
      <button type="submit" class="btn-primary py-3.5 rounded-2xl text-sm">🔍 جستجو</button>
      <a href="<?= SITE_URL ?>/search.php" class="btn-secondary py-3.5 rounded-2xl text-sm flex items-center justify-center" style="text-decoration:none">↺ بازنشانی</a>
    </div>
  </form>

  <?php if ($did): ?>
    <div class="mt-5">
      <h2 class="font-black text-[15px] mb-3" style="color:var(--text-primary)">نتایج جستجو (<?= toFaDigits($total) ?>)</h2>
      <?php if (empty($items)): ?>
        <div class="card p-8 text-center">
          <div class="text-4xl mb-2">🏠</div>
          <div class="font-extrabold text-sm" style="color:var(--text-primary)">با این فیلترها ملکی یافت نشد</div>
          <a href="<?= SITE_URL ?>/request.php" class="btn-gold inline-block px-6 py-2.5 rounded-xl text-[13px] mt-3" style="text-decoration:none">📩 ثبت درخواست</a>
        </div>
      <?php else: ?>
        <div class="space-y-3.5">
          <?php foreach ($items as $p) renderPropertyCard($p); ?>
        </div>
      <?php endif; ?>
    </div>
  <?php endif; ?>
  <div class="h-2"></div>
</div>
<?php require __DIR__ . '/includes/layout_foot.php'; ?>
