<?php
require_once __DIR__ . '/includes/functions.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  header('Location: ' . SITE_URL . '/sell.php');
  exit;
}

function parsePriceVal($v): int {
  $v = toEnDigits((string)$v);
  $v = preg_replace('/[^\d]/', '', $v);
  return $v === '' ? 0 : (int)$v;
}

$type = $_POST['type'] ?? 'apartment';
$dealType = $_POST['dealType'] ?? 'sale';
$title = trim($_POST['title'] ?? '');
$location = trim($_POST['location'] ?? '');
$address = trim($_POST['address'] ?? '');

if ($title === '' || $location === '' || $address === '') {
  header('Location: ' . SITE_URL . '/sell_type.php?type=' . urlencode($type) . '&error=missing');
  exit;
}

$isRent = $dealType === 'rent';
$isPresale = $dealType === 'presale';
$fullRent = !empty($_POST['fullRent']);

$price = 0; $rentPrice = 0; $mortgagePrice = 0;
if ($isRent) {
  $rentPrice = parsePriceVal($_POST['rentMonthly'] ?? 0);
  $mortgagePrice = $fullRent ? parsePriceVal($_POST['fullRentAmount'] ?? 0) : parsePriceVal($_POST['deposit'] ?? 0);
  $price = $fullRent ? parsePriceVal($_POST['fullRentAmount'] ?? 0) : 0;
} elseif ($isPresale) {
  $price = parsePriceVal($_POST['totalPrice'] ?? 0);
} else {
  $price = parsePriceVal($_POST['price'] ?? 0);
}

$area = 0; $rooms = 0; $landArea = 0;
switch ($type) {
  case 'apartment':
    $area = (int)($_POST['area'] ?? 0); $rooms = (int)($_POST['rooms'] ?? 0);
    break;
  case 'villa':
    $area = (int)($_POST['floorArea'] ?? 0); $rooms = (int)($_POST['rooms'] ?? 0);
    $landArea = (int)($_POST['landArea'] ?? 0);
    break;
  case 'land':
    $landArea = (int)($_POST['landArea'] ?? 0);
    break;
  case 'garden':
    $area = (int)($_POST['buildingArea'] ?? 0);
    $landArea = (int)($_POST['gardenArea'] ?? 0);
    break;
  case 'office':
    $area = (int)($_POST['area'] ?? 0); $rooms = (int)($_POST['rooms'] ?? 0);
    break;
  case 'commercial':
    $area = (int)($_POST['area'] ?? 0);
    break;
}

// جزئیات اضافی: هرچه از فرم آمده به‌جز فیلدهای اصلی، در details ذخیره می‌شود
$exclude = ['type','dealType','title','location','address','images','amenities','publishPhotos','fullDesc','visitHours','gender','lastName','phone'];
$details = [];
foreach ($_POST as $k => $v) {
  if (in_array($k, $exclude)) continue;
  if ($v === '' || $v === null) continue;
  $details[$k] = is_string($v) ? trim($v) : $v;
}
$details['gender'] = $_POST['gender'] ?? 'آقا';
$details['publishPhotos'] = $_POST['publishPhotos'] ?? 'yes';
if (!empty($_POST['visitHours'])) $details['visitHours'] = trim($_POST['visitHours']);
if (!empty($_POST['negotiable'])) $details['dealNegotiable'] = true;
if (!empty($_POST['fixed'])) $details['dealFixed'] = true;
if (!empty($_POST['exchange'])) { $details['exchangeInterested'] = true; $details['exchangeWith'] = trim($_POST['exchangeWith'] ?? ''); }
if ($isPresale && !empty($_POST['downPayment'])) $details['downPayment'] = parsePriceVal($_POST['downPayment']);

// امکانات
$amenities = [];
if (!empty($_POST['amenities']) && is_array($_POST['amenities'])) {
  $amenities = array_values(array_filter(array_map('trim', $_POST['amenities'])));
}

// آپلود تصاویر
$allImages = [];
if (!empty($_FILES['images']['name'][0])) {
  $allowed = ['jpg' => 1, 'jpeg' => 1, 'png' => 1, 'webp' => 1];
  $count = count($_FILES['images']['name']);
  for ($i = 0; $i < $count && count($allImages) < 8; $i++) {
    if ($_FILES['images']['error'][$i] !== UPLOAD_ERR_OK) continue;
    $ext = strtolower(pathinfo($_FILES['images']['name'][$i], PATHINFO_EXTENSION));
    if (!isset($allowed[$ext]) || $_FILES['images']['size'][$i] > 5 * 1024 * 1024) continue;
    $newName = 'prop_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
    $dest = UPLOADS_DIR . '/properties/' . $newName;
    if (move_uploaded_file($_FILES['images']['tmp_name'][$i], $dest)) {
      $allImages[] = 'properties/' . $newName;
    }
  }
}
$publishPhotos = ($_POST['publishPhotos'] ?? 'yes') === 'yes';
$publicImages = $publishPhotos ? $allImages : [];

// وضعیت انتشار: طبق تنظیمات عمومی (انتشار خودکار) یا در انتظار تأیید
$general = generalSettings();
$autoPublish = !empty($general['autoPublish']);
$status = $autoPublish ? 'available' : 'pending';

// کد آگهی یکتا
$code = 'AD-' . date('Ymd') . '-' . random_int(1000, 9999);

$pricePerMeter = ($price > 0 && $area > 0) ? (int)round($price / $area) : 0;

$stmt = db()->prepare(
  'INSERT INTO properties
   (code, title, description, type, deal_type, price, rent_price, mortgage_price, price_per_meter,
    area, land_area, rooms, floor, total_floors, year_built, address, neighborhood, images, all_images,
    publish_photos, amenities, status, owner_name, owner_phone, details)
   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)'
);
$stmt->execute([
  $code,
  $title,
  trim($_POST['fullDesc'] ?? ''),
  $type,
  $dealType,
  $price,
  $rentPrice,
  $mortgagePrice,
  $pricePerMeter,
  $area,
  $landArea,
  $rooms,
  (int)($_POST['floor'] ?? 0),
  (int)($_POST['totalUnits'] ?? $_POST['unitsPerFloor'] ?? 0),
  (int)($_POST['year'] ?? 0),
  $address,
  $location,
  json_encode($publicImages, JSON_UNESCAPED_UNICODE),
  json_encode($allImages, JSON_UNESCAPED_UNICODE),
  $publishPhotos ? 1 : 0,
  json_encode($amenities, JSON_UNESCAPED_UNICODE),
  $status,
  trim($_POST['lastName'] ?? ''),
  trim($_POST['phone'] ?? ''),
  json_encode($details, JSON_UNESCAPED_UNICODE),
]);

$newId = (int)db()->lastInsertId();

// ثبت/به‌روزرسانی کاربر اپ بر اساس شماره تماس (شناسایی ساده کاربر)
$phone = trim($_POST['phone'] ?? '');
if ($phone !== '') {
  $userKey = 'phone_' . preg_replace('/\D/', '', $phone);
  $u = db()->prepare('SELECT id FROM app_users WHERE user_key = ?');
  $u->execute([$userKey]);
  if (!$u->fetch()) {
    db()->prepare('INSERT INTO app_users (user_key, phone, name, platform) VALUES (?,?,?,?)')
       ->execute([$userKey, $phone, trim($_POST['lastName'] ?? ''), 'web']);
  }
}

header('Location: ' . SITE_URL . '/sell_success.php?code=' . urlencode($code) . '&id=' . $newId);
exit;
