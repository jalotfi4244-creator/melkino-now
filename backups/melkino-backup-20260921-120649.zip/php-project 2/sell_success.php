<?php
require_once __DIR__ . '/includes/functions.php';

$code = $_GET['code'] ?? '';
$id = (int)($_GET['id'] ?? 0);
if ($code === '' || $id <= 0) {
  header('Location: ' . SITE_URL . '/home.php');
  exit;
}

$pageTitle = generalSettings()['siteName'] . ' | ثبت موفق آگهی';
$activeNav = '';
require __DIR__ . '/includes/layout_head.php';
?>
<div class="px-4 pt-10 flex flex-col items-center text-center">
  <div class="w-24 h-24 rounded-full flex items-center justify-center mb-5" style="background:var(--success-bg)">
    <span style="font-size:44px;color:var(--success)">✔</span>
  </div>
  <h1 class="font-black text-[20px]" style="color:var(--text-primary)">آگهی شما با موفقیت ثبت شد 🎉</h1>
  <p class="text-[13px] leading-7 mt-2.5" style="color:var(--text-secondary)">
    آگهی شما پس از بررسی و تأیید توسط تیم ملکینو منتشر می‌شود.<br>
    معمولاً این فرایند کمتر از ۲۴ ساعت کاری طول می‌کشد.
  </p>
  <div class="card p-4 mt-5 w-full max-w-sm">
    <div class="text-[12px]" style="color:var(--text-muted)">کد پیگیری آگهی</div>
    <div class="font-black text-[18px] font-mono mt-1" dir="ltr" style="color:var(--primary)"><?= e($code) ?></div>
    <div class="flex items-center justify-center gap-1.5 mt-2">
      <span class="badge badge-warning">در انتظار بررسی</span>
    </div>
  </div>
  <div class="grid grid-cols-2 gap-2.5 mt-5 w-full max-w-sm">
    <a href="<?= SITE_URL ?>/properties.php" class="btn-secondary py-3.5 rounded-2xl text-[13px]" style="text-decoration:none">مشاهده همه آگهی‌ها</a>
    <a href="<?= SITE_URL ?>/home.php" class="btn-primary py-3.5 rounded-2xl text-[13px]" style="text-decoration:none">بازگشت به خانه</a>
  </div>
</div>
<?php require __DIR__ . '/includes/layout_foot.php'; ?>
