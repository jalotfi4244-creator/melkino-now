<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/sell_config.php';

$type = $_GET['type'] ?? '';
$META = SELL_TYPE_META();
if (!isset($META[$type])) {
  header('Location: ' . SITE_URL . '/sell.php');
  exit;
}
$meta = $META[$type];
$totalSteps = sellTotalSteps($type);
$dealType = $_GET['deal'] ?? 'sale'; // مقدار واقعی از sessionStorage در سمت کاربر خوانده و با JS به فرم اعمال می‌شود

$pageTitle = 'ثبت ' . $meta['label'] . ' | ' . generalSettings()['siteName'];
$activeNav = 'sell';
require __DIR__ . '/includes/layout_head.php';

/* ---------- توابع کمکی رندر فیلد ---------- */
function sf_select(string $name, string $label, array $options, ?string $note = null): void {
  ?>
  <div class="form-group">
    <label><?= e($label) ?></label>
    <select name="<?= e($name) ?>" class="form-select">
      <option value="">انتخاب کنید</option>
      <?php foreach ($options as $o): ?><option value="<?= e($o) ?>"><?= e($o) ?></option><?php endforeach; ?>
    </select>
    <?php if ($note): ?><p class="text-[11px] mt-1" style="color:var(--text-muted)"><?= e($note) ?></p><?php endif; ?>
  </div>
  <?php
}
function sf_select_default(string $name, string $label, array $options): void {
  // مثل select های flooring/cabinet/cooling/heating که مقدار پیش‌فرض دارند
  ?>
  <div class="form-group">
    <label><?= e($label) ?></label>
    <select name="<?= e($name) ?>" class="form-select">
      <?php foreach ($options as $o): ?><option value="<?= e($o) ?>"><?= e($o) ?></option><?php endforeach; ?>
    </select>
  </div>
  <?php
}
function sf_text(string $name, string $label, string $placeholder = '', bool $numeric = true): void {
  ?>
  <div class="form-group">
    <label><?= e($label) ?></label>
    <input class="form-input" name="<?= e($name) ?>" <?= $numeric ? 'inputmode="numeric"' : '' ?> placeholder="<?= e($placeholder) ?>">
  </div>
  <?php
}
function sf_date(string $name, string $label): void {
  ?>
  <div class="form-group">
    <label><?= e($label) ?></label>
    <input type="date" class="form-input" name="<?= e($name) ?>">
  </div>
  <?php
}
$togCounter = 0;
function sf_toggle_group(string $name, string $label, array $options): void {
  global $togCounter;
  $hid = 'h_' . $name . '_' . (++$togCounter);
  ?>
  <div class="form-group">
    <label><?= e($label) ?></label>
    <input type="hidden" name="<?= e($name) ?>" id="<?= $hid ?>">
    <div class="options-group">
      <?php foreach ($options as $o): ?>
        <button type="button" class="option-btn" data-val="<?= e($o) ?>" onclick="mkRadioToggle(this,'<?= $hid ?>')"><?= e($o) ?></button>
      <?php endforeach; ?>
    </div>
  </div>
  <?php
}
function sf_checkbox(string $name, string $label, string $wrapClass = ''): void {
  ?>
  <label class="amen-check <?= e($wrapClass) ?>"><input type="checkbox" name="<?= e($name) ?>" value="1"> <?= e($label) ?></label>
  <?php
}
?>
<div class="px-4 pt-4 flex flex-col" style="min-height:70vh">
  <div class="flex items-center gap-2.5 mb-4">
    <div class="w-10 h-10 rounded-2xl flex items-center justify-center text-lg" style="background:color-mix(in srgb, var(--primary-light) 14%, transparent)"><?= $meta['icon'] ?></div>
    <div class="flex-1">
      <div class="font-black text-[14px]" style="color:var(--text-primary)">ثبت ملک <?= e($meta['label']) ?></div>
      <div class="text-[12px]" style="color:var(--text-muted)">مرحله <span id="stepLabel">۱</span> از <?= toFaDigits($totalSteps) ?></div>
    </div>
    <a href="<?= SITE_URL ?>/sell.php" class="icon-btn" title="مرحله قبل">←</a>
  </div>
  <div class="h-1.5 rounded-full mb-5" style="background:var(--bg-tertiary)">
    <div id="progressBar" class="h-full rounded-full" style="width:<?= round(100 / $totalSteps) ?>%;background:linear-gradient(90deg,var(--primary-light),var(--primary));transition:width .4s"></div>
  </div>

  <form method="post" action="<?= SITE_URL ?>/sell_submit.php" enctype="multipart/form-data" class="card p-5 flex-1 flex flex-col" id="sellForm">
    <input type="hidden" name="type" value="<?= e($type) ?>">
    <input type="hidden" name="dealType" id="f_dealType" value="sale">
    <input type="hidden" name="gender" id="f_gender" value="آقا">
    <input type="hidden" name="lastName" id="f_lastName" value="">
    <input type="hidden" name="phone" id="f_phone" value="">

    <!-- ============ STEP 1: اطلاعات پایه و موقعیت ============ -->
    <div class="step-content active" data-step="1">
      <h2 class="step-title mb-1">📍 اطلاعات پایه و موقعیت</h2>
      <p class="step-subtitle mb-4">اطلاعات اصلی ملک خود را وارد کنید</p>
      <div class="form-group">
        <label>عنوان آگهی</label>
        <input class="form-input" name="title" placeholder="<?= $type === 'land' ? 'زمین ۵۰۰ متری با دسترسی به خیابان اصلی' : e($meta['label']) . ' ۱۲۰ متری نوساز خ فردوسی' ?>">
      </div>
      <div class="form-group">
        <label>محله / خیابان اصلی</label>
        <input class="form-input" name="location" placeholder="خیابان بهار">
      </div>
      <div class="form-group">
        <label>آدرس دقیق</label>
        <input class="form-input" name="address" placeholder="خ بهار کوچه بیستم...">
      </div>

      <?php if ($type === 'apartment'): ?>
        <div class="row-half">
          <?php sf_text('area', 'متراژ (متر مربع)', '۹۰'); ?>
          <?php sf_text('floor', 'طبقه', '۳'); ?>
        </div>
        <div class="row-half">
          <?php sf_select('rooms', 'تعداد اتاق', [1,2,3,4]); ?>
          <?php sf_text('totalUnits', 'تعداد کل واحدها', '۲۰'); ?>
        </div>
        <?php sf_text('year', 'سال ساخت', '۱۴۰۲'); ?>
        <?php sf_checkbox('isNotKeyed', 'کلید نخورده', 'mb-3'); ?>
        <div class="deal-presale" style="display:none"><?php sf_date('deliveryDate', 'تاریخ تحویل'); ?></div>
        <div class="deal-rent" style="display:none">
          <?php sf_date('vacancyDate', 'تاریخ تخلیه'); ?>
          <?php sf_checkbox('isVacant', 'واحد تخلیه است'); ?>
        </div>
      <?php elseif ($type === 'villa'): ?>
        <div class="row-half">
          <?php sf_text('landArea', 'متراژ زمین (متر مربع)', '۵۰۰'); ?>
          <?php sf_text('floorArea', 'زیربنا (متر مربع)', '۲۵۰'); ?>
        </div>
        <div class="row-half">
          <?php sf_select('rooms', 'تعداد اتاق', [1,2,3,4,5]); ?>
          <?php sf_text('year', 'سال ساخت', '۱۴۰۰'); ?>
        </div>
        <?php sf_toggle_group('condition', 'وضعیت ملک', ['کلید نخورده', 'کلنگی', 'بازسازی شده']); ?>
        <div class="deal-presale" style="display:none"><?php sf_date('deliveryDate', 'تاریخ تحویل'); ?></div>
        <div class="deal-rent" style="display:none">
          <?php sf_date('vacancyDate', 'تاریخ تخلیه'); ?>
          <?php sf_checkbox('isVacant', 'ساختمان تخلیه است'); ?>
        </div>
      <?php elseif ($type === 'land'): ?>
        <?php sf_text('landArea', 'متراژ زمین (متر مربع)', '۵۰۰'); ?>
        <?php sf_toggle_group('landType', 'نوع زمین', LAND_TYPES_OPT()); ?>
        <div class="row-half">
          <?php sf_text('width', 'عرض زمین (متر)', '۱۲'); ?>
          <?php sf_text('length', 'طول زمین (متر)', '۴۲'); ?>
        </div>
        <div class="row-half">
          <?php sf_text('frontWidth', 'بر زمین (متر)', '۱۰'); ?>
          <?php sf_text('blocks', 'تعداد بلوک', '۲'); ?>
        </div>
        <div class="row-half">
          <?php sf_select('direction', 'جهت زمین', LAND_DIRECTIONS_OPT()); ?>
          <?php sf_select('shape', 'شکل زمین', LAND_SHAPES_OPT()); ?>
        </div>
        <?php sf_select('deedStatus', 'وضعیت سند', DEED_STATUS_OPT()); ?>
        <?php sf_toggle_group('ownership', 'وضعیت مالکیت', ['شش‌دانگ', 'مشاع']); ?>
      <?php elseif ($type === 'garden'): ?>
        <?php sf_text('gardenArea', 'مساحت باغ (متر مربع)', '۱۰۰۰'); ?>
        <?php sf_toggle_group('documentType', 'نوع سند', ['سند', 'قولنامه']); ?>
      <?php elseif ($type === 'office'): ?>
        <div class="row-half">
          <?php sf_text('area', 'متراژ واحد (متر مربع)', '۱۲۰'); ?>
          <?php sf_text('floor', 'طبقه', '۳'); ?>
        </div>
        <div class="row-half">
          <?php sf_text('unitsPerFloor', 'تعداد واحد در طبقه', '۴'); ?>
          <?php sf_select('rooms', 'تعداد اتاق', [1,2,3,4,5,6]); ?>
        </div>
        <?php sf_text('year', 'سال ساخت', '۱۴۰۲'); ?>
        <?php sf_toggle_group('condition', 'وضعیت واحد', ['نوساز', 'بازسازی‌شده', 'قدیمی']); ?>
        <?php sf_toggle_group('orientation', 'موقعیت واحد', ['شمالی', 'جنوبی', 'شرقی', 'غربی']); ?>
        <?php sf_toggle_group('usage', 'کاربری', ['اداری', 'دفتر کار', 'تجاری-اداری']); ?>
        <div class="deal-presale" style="display:none"><?php sf_date('deliveryDate', 'تاریخ تحویل'); ?></div>
        <div class="deal-rent" style="display:none">
          <?php sf_date('vacancyDate', 'تاریخ تخلیه'); ?>
          <?php sf_checkbox('isVacant', 'واحد تخلیه است'); ?>
        </div>
      <?php elseif ($type === 'commercial'): ?>
        <div class="row-half">
          <?php sf_text('area', 'متراژ (متر مربع)', '۴۰'); ?>
          <?php sf_text('front', 'بر مغازه (متر)', '۶'); ?>
        </div>
        <?php sf_toggle_group('location1', 'موقعیت ملک تجاری', ['دونبش', 'دوبر', 'یک بر']); ?>
        <?php sf_toggle_group('location2', 'دسترسی', ['بر خیابان اصلی', 'بر خیابان فرعی', 'در پاساژ', 'در گاراژ']); ?>
        <div class="deal-presale" style="display:none"><?php sf_date('deliveryDate', 'تاریخ تحویل'); ?></div>
        <div class="deal-rent" style="display:none">
          <?php sf_date('vacancyDate', 'تاریخ تخلیه'); ?>
          <?php sf_checkbox('isVacant', 'واحد تجاری تخلیه است'); ?>
        </div>
      <?php endif; ?>
    </div>

    <?php
    $stepN = 1;
    if ($meta['specStep2']):
      $stepN = 2;
    ?>
    <!-- ============ STEP 2: مشخصات فنی ============ -->
    <div class="step-content" data-step="2">
      <?php if ($type === 'apartment' || $type === 'villa'): ?>
        <h2 class="step-title mb-1">🏗️ مشخصات فنی</h2>
        <p class="step-subtitle mb-4">مشخصات فنی ملک را مشخص کنید</p>
        <div class="row-half">
          <?php sf_select_default('flooring', 'نوع پوشش کف', FLOORING_OPTIONS()); ?>
          <?php sf_select_default('cabinet', 'نوع کابینت', CABINET_OPTIONS()); ?>
        </div>
        <div class="row-half">
          <?php sf_select_default('cooling', 'سیستم سرمایش', COOLING_OPTIONS()); ?>
          <?php sf_select_default('heating', 'سیستم گرمایش', HEATING_OPTIONS()); ?>
        </div>
      <?php elseif ($type === 'garden'): ?>
        <h2 class="step-title mb-1">🌳 مشخصات باغ</h2>
        <p class="step-subtitle mb-4">مشخصات باغ را کامل کنید</p>
        <?php sf_text('treeTypes', 'نوع درختان', 'گردو، سیب، ...', false); ?>
        <div class="row-half">
          <?php sf_text('treeAge', 'سن درختان (سال)', '۱۰'); ?>
          <?php sf_select('irrigation', 'نوع آبیاری', IRRIGATION_OPT()); ?>
        </div>
        <?php sf_toggle_group('hasWater', 'آب ملکی', ['دارد', 'ندارد']); ?>
        <div class="row-half">
          <?php sf_text('waterHours', 'مقدار ساعت آب', '۲'); ?>
          <?php sf_text('wellName', 'نام چاه آب', '', false); ?>
        </div>
        <?php sf_toggle_group('hasPond', 'استخر ذخیره آب', ['دارد', 'ندارد']); ?>
        <?php sf_toggle_group('hasBuilding', 'بنا / خانه باغ', ['دارد', 'ندارد']); ?>
        <?php sf_text('buildingArea', 'متراژ بنا (متر مربع)', '۶۰'); ?>
      <?php elseif ($type === 'commercial'): ?>
        <h2 class="step-title mb-1">🏪 مشخصات فنی</h2>
        <p class="step-subtitle mb-4">مشخصات ملک تجاری را کامل کنید</p>
        <div class="row-half">
          <?php sf_select_default('flooring', 'پوشش کف', ['سرامیک','موکت','سنگ','موزاییک','سیمان','کفپوش']); ?>
          <?php sf_select_default('wall', 'پوشش دیوارها', WALL_COVER_OPT()); ?>
        </div>
        <div class="row-half">
          <?php sf_select_default('cabinet', 'نوع کابینت', CABINET_OPTIONS()); ?>
          <?php sf_select_default('cooling', 'سیستم سرمایش', COOLING_OPTIONS()); ?>
        </div>
        <?php sf_select_default('heating', 'سیستم گرمایش', HEATING_OPTIONS()); ?>
      <?php endif; ?>
    </div>
    <?php endif; ?>

    <?php $amenStep = $meta['specStep2'] ? 3 : 2; ?>
    <!-- ============ امکانات ============ -->
    <div class="step-content" data-step="<?= $amenStep ?>">
      <h2 class="step-title mb-1">✨ امکانات</h2>
      <p class="step-subtitle mb-4">امکانات موجود در ملک را تیک بزنید</p>
      <div class="grid grid-cols-2 gap-2">
        <?php foreach (SELL_AMENITIES()[$type] as $a): ?>
          <label class="amen-check"><input type="checkbox" name="amenities[]" value="<?= e($a) ?>"> <?= e($a) ?></label>
        <?php endforeach; ?>
      </div>
    </div>

    <?php $priceStep = $amenStep + 1; ?>
    <!-- ============ قیمت ============ -->
    <div class="step-content" data-step="<?= $priceStep ?>">
      <h2 class="step-title mb-1">💰 قیمت</h2>
      <p class="step-subtitle mb-4" id="priceHint">قیمت ملک خود را به تومان وارد کنید</p>

      <div class="deal-sale">
        <?php sf_text('price', 'قیمت (تومان)', '۲,۸۰۰,۰۰۰,۰۰۰'); ?>
        <div class="form-group">
          <label>شرط قیمت</label>
          <input type="hidden" name="negotiable" id="f_negotiable" value="">
          <input type="hidden" name="fixed" id="f_fixed" value="">
          <div class="options-group">
            <button type="button" class="option-btn" onclick="mkSelfToggle(this,'f_negotiable')">قابل مذاکره</button>
            <button type="button" class="option-btn" onclick="mkSelfToggle(this,'f_fixed')">مقطوع</button>
          </div>
        </div>
        <?php sf_checkbox('exchange', 'مایل به معاوضه هستم', 'mb-2'); ?>
        <div class="form-group">
          <label>معاوضه با:</label>
          <textarea class="form-textarea" name="exchangeWith" rows="3" placeholder="مثلاً: معاوضه با آپارتمان بزرگ‌تر یا ویلا..."></textarea>
        </div>
      </div>

      <div class="deal-rent" style="display:none">
        <?php sf_text('deposit', 'ودیعه (تومان)', '۵۰۰,۰۰۰,۰۰۰'); ?>
        <?php sf_text('rentMonthly', 'اجاره ماهانه (تومان)', '۳۰,۰۰۰,۰۰۰'); ?>
        <?php sf_checkbox('fullRent', 'رهن کامل'); ?>
        <?php sf_text('fullRentAmount', 'مبلغ رهن کامل (تومان)', '۱,۰۰۰,۰۰۰,۰۰۰'); ?>
      </div>

      <div class="deal-presale" style="display:none">
        <?php sf_text('totalPrice', 'قیمت کل (تومان)', '۳,۰۰۰,۰۰۰,۰۰۰'); ?>
        <?php sf_text('downPayment', 'پیش‌پرداخت (تومان)', '۹۰۰,۰۰۰,۰۰۰'); ?>
        <div class="form-group">
          <label>شرایط پرداخت</label>
          <textarea class="form-textarea" name="paymentTerms" rows="3" placeholder="مثال: ۳۰٪ قرارداد، ۲۰٪ اسکلت..."></textarea>
        </div>
      </div>
    </div>

    <?php $imgStep = $priceStep + 1; ?>
    <!-- ============ تصاویر و توضیحات ============ -->
    <div class="step-content" data-step="<?= $imgStep ?>">
      <h2 class="step-title mb-1">📸 تصاویر، توضیحات و ثبت نهایی</h2>
      <p class="step-subtitle mb-4">آخرین قدم؛ آگهی شما آماده انتشار است</p>

      <div class="form-group">
        <label>آپلود تصاویر (حداکثر ۸ تصویر، فرمت JPG, PNG, WEBP — اولین تصویر، عکس اصلی آگهی است)</label>
        <input type="file" name="images[]" accept="image/jpeg,image/png,image/webp" multiple class="form-input">
      </div>

      <div class="form-group">
        <label>انتخاب حالت انتشار تصاویر</label>
        <input type="hidden" name="publishPhotos" id="f_publishPhotos" value="yes">
        <div class="options-group">
          <button type="button" class="option-btn selected" data-val="yes" onclick="mkRadioSingle(this,'f_publishPhotos')">مایل به انتشار عکس‌ها در آگهی هستم</button>
          <button type="button" class="option-btn" data-val="no" onclick="mkRadioSingle(this,'f_publishPhotos')">مایل به انتشار عکس‌ها نیستم</button>
        </div>
      </div>

      <div class="form-group">
        <label>توضیحات تکمیلی</label>
        <textarea class="form-textarea" name="fullDesc" rows="4" maxlength="1000" placeholder="شرح کامل امکانات و شرایط ملک..."></textarea>
      </div>

      <div class="form-group">
        <label>چه زمان‌هایی میشه بازدید کرد؟</label>
        <textarea class="form-textarea" name="visitHours" rows="2" placeholder="مثال: فقط عصرها میشه بازدید کرد..."></textarea>
      </div>
    </div>

    <div class="bottom-actions">
      <button type="button" id="btnPrev" class="btn-secondary px-6 rounded-2xl text-sm" onclick="mkStep(-1)">مرحله قبل</button>
      <button type="button" id="btnNext" class="btn-primary btn-primary-full py-3.5 rounded-2xl text-sm" onclick="mkStep(1)">مرحله بعد</button>
      <button type="submit" id="btnSubmit" class="btn-primary btn-primary-full py-3.5 rounded-2xl text-sm" style="display:none">📩 ثبت نهایی آگهی</button>
    </div>
    <div class="text-center text-[11px] mt-3" style="color:var(--text-muted)">📷 پس از ثبت، آگهی شما توسط تیم ملکینو بررسی و منتشر می‌شود</div>
  </form>
</div>

<script>
var mkCur = 1, mkTotal = <?= $totalSteps ?>;

/* بازیابی اطلاعات مرحله قبل (sell.php) */
(function(){
  try {
    document.getElementById('f_gender').value = sessionStorage.getItem('reg_gender') || 'آقا';
    document.getElementById('f_lastName').value = sessionStorage.getItem('reg_last_name') || '';
    document.getElementById('f_phone').value = sessionStorage.getItem('reg_phone') || '';
    var dt = sessionStorage.getItem('reg_transaction_type') || 'sale';
    document.getElementById('f_dealType').value = dt;
    document.querySelectorAll('.deal-sale, .deal-rent, .deal-presale').forEach(function(el){ el.style.display = 'none'; });
    document.querySelectorAll('.deal-' + dt).forEach(function(el){ el.style.display = 'block'; });
    var hint = document.getElementById('priceHint');
    if (hint) hint.textContent = dt === 'sale' ? 'قیمت ملک خود را به تومان وارد کنید' : dt === 'rent' ? 'مبالغ ودیعه و اجاره را وارد کنید' : 'شرایط پرداخت پیش‌فروش را مشخص کنید';
  } catch(e){}
})();

function mkRadioToggle(btn, hiddenId){
  var group = btn.parentElement;
  var hidden = document.getElementById(hiddenId);
  var val = btn.getAttribute('data-val');
  if (btn.classList.contains('selected')) {
    btn.classList.remove('selected'); hidden.value = '';
  } else {
    Array.prototype.forEach.call(group.children, function(b){ b.classList.remove('selected'); });
    btn.classList.add('selected'); hidden.value = val;
  }
}
function mkSelfToggle(btn, hiddenId){
  var hidden = document.getElementById(hiddenId);
  if (btn.classList.contains('selected')) { btn.classList.remove('selected'); hidden.value = ''; }
  else { btn.classList.add('selected'); hidden.value = '1'; }
}
function mkRadioSingle(btn, hiddenId){
  var group = btn.parentElement;
  Array.prototype.forEach.call(group.children, function(b){ b.classList.remove('selected'); });
  btn.classList.add('selected');
  document.getElementById(hiddenId).value = btn.getAttribute('data-val');
}

function mkStep(dir){
  var next = mkCur + dir;
  if (next < 1 || next > mkTotal) return;
  document.querySelector('.step-content[data-step="'+mkCur+'"]').classList.remove('active');
  mkCur = next;
  document.querySelector('.step-content[data-step="'+mkCur+'"]').classList.add('active');
  document.getElementById('stepLabel').textContent = toFaNum(mkCur);
  document.getElementById('progressBar').style.width = (mkCur/mkTotal*100) + '%';
  document.getElementById('btnPrev').style.display = mkCur === 1 ? 'none' : 'flex';
  document.getElementById('btnNext').style.display = mkCur === mkTotal ? 'none' : 'flex';
  document.getElementById('btnSubmit').style.display = mkCur === mkTotal ? 'flex' : 'none';
  window.scrollTo({ top: 0, behavior: 'smooth' });
}
function toFaNum(n){
  var fa = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
  return String(n).replace(/[0-9]/g, function(d){ return fa[d]; });
}
</script>

<?php require __DIR__ . '/includes/layout_foot.php'; ?>
