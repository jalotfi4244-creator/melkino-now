<?php
require_once __DIR__ . '/includes/user_auth.php';
header('Content-Type: application/json; charset=utf-8');

$body = json_decode(file_get_contents('php://input'), true) ?: [];
$platform = ($body['platform'] ?? '') === 'bale' ? 'bale' : 'telegram';
$initData = (string)($body['initData'] ?? '');

$ch = getChannelSettings();
$token = $platform === 'telegram' ? $ch['telegramBotToken'] : $ch['baleBotToken'];
if (!$token) {
  echo json_encode([
    'ok' => false,
    'error' => 'توکن ربات ' . ($platform === 'telegram' ? 'تلگرام' : 'بله') . ' در پنل مدیریت تنظیم نشده است',
    'code' => 'no_token',
  ], JSON_UNESCAPED_UNICODE);
  exit;
}

$v = verifyInitData($initData, $token, $platform);
if (!$v['ok']) {
  echo json_encode(['ok' => false, 'error' => $v['error'] ?? 'احراز هویت ناموفق'], JSON_UNESCAPED_UNICODE);
  exit;
}

$r = upsertWebappUser($platform, $v['user']);
if (!$r['ok']) {
  echo json_encode(['ok' => false, 'error' => $r['error']], JSON_UNESCAPED_UNICODE);
  exit;
}
$u = $r['user'];
echo json_encode([
  'ok' => true,
  'needPhone' => $r['needPhone'],
  'data' => ['id' => $u['id'], 'name' => $u['name'], 'phone' => $u['phone'], 'photoUrl' => $u['photo_url'], 'platform' => $u['platform']],
], JSON_UNESCAPED_UNICODE);
