import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { properties } from "@/db/schema";
import { eq } from "drizzle-orm";
import { isAdmin } from "@/lib/admin-auth";
import { isUploadUrl, filenameFromUrl, removeFile } from "@/lib/uploads";

/*
  مدیریت تصاویر یک آگهی (فقط مدیر)
  PUT  { published: string[], all: string[] }   → تعیین اینکه کدام تصاویر منتشر شوند + ترتیب
  POST { add: string[] }                        → افزودن تصویر (آپلودشده توسط ادمین) به مخزن آگهی + انتشار
  DELETE { url }                                → حذف کامل تصویر از آگهی و دیسک
*/
export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  if (!(await isAdmin(req))) return NextResponse.json({ ok: false, error: "دسترسی غیرمجاز" }, { status: 401 });
  const { id } = await params;
  const b = await req.json();
  const all: string[] = Array.isArray(b.all) ? b.all.filter((x: unknown) => typeof x === "string") : [];
  const published: string[] = Array.isArray(b.published) ? b.published.filter((x: string) => all.includes(x)) : [];
  const [row] = await db.update(properties).set({ allImages: all, images: published, updatedAt: new Date() }).where(eq(properties.id, Number(id))).returning();
  return NextResponse.json({ ok: true, data: row });
}

export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  if (!(await isAdmin(req))) return NextResponse.json({ ok: false, error: "دسترسی غیرمجاز" }, { status: 401 });
  const { id } = await params;
  const b = await req.json();
  const add: string[] = Array.isArray(b.add) ? b.add.filter((x: unknown) => typeof x === "string") : [];
  const [cur] = await db.select().from(properties).where(eq(properties.id, Number(id)));
  if (!cur) return NextResponse.json({ ok: false, error: "یافت نشد" }, { status: 404 });
  const all = Array.from(new Set([...(cur.allImages || []), ...add]));
  const published = b.publish === false ? (cur.images || []) : Array.from(new Set([...(cur.images || []), ...add]));
  const [row] = await db.update(properties).set({ allImages: all, images: published, updatedAt: new Date() }).where(eq(properties.id, Number(id))).returning();
  return NextResponse.json({ ok: true, data: row });
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  if (!(await isAdmin(req))) return NextResponse.json({ ok: false, error: "دسترسی غیرمجاز" }, { status: 401 });
  const { id } = await params;
  const b = await req.json();
  const url = String(b.url || "");
  const [cur] = await db.select().from(properties).where(eq(properties.id, Number(id)));
  if (!cur) return NextResponse.json({ ok: false, error: "یافت نشد" }, { status: 404 });
  const all = (cur.allImages || []).filter((u) => u !== url);
  const published = (cur.images || []).filter((u) => u !== url);
  const [row] = await db.update(properties).set({ allImages: all, images: published, updatedAt: new Date() }).where(eq(properties.id, Number(id))).returning();
  if (isUploadUrl(url)) await removeFile(filenameFromUrl(url));
  return NextResponse.json({ ok: true, data: row });
}
