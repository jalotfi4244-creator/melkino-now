import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { properties } from "@/db/schema";
import { eq, sql } from "drizzle-orm";
import { isAdmin } from "@/lib/admin-auth";

export async function GET(_: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const [row] = await db.select().from(properties).where(eq(properties.id, Number(id)));
    if (!row) return NextResponse.json({ ok: false, error: "یافت نشد" }, { status: 404 });
    await db.update(properties).set({ views: sql`${properties.views} + 1` }).where(eq(properties.id, Number(id)));
    return NextResponse.json({ ok: true, data: row });
  } catch (e) {
    return NextResponse.json({ ok: false, error: String(e) }, { status: 500 });
  }
}

export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    if (!(await isAdmin(req))) return NextResponse.json({ ok: false, error: "دسترسی غیرمجاز" }, { status: 401 });
    const { id } = await params;
    const body = await req.json();
    const patch: Record<string, unknown> = {};
    const fields = ["title","description","type","dealType","price","rentPrice","mortgagePrice","pricePerMeter","area","landArea","rooms","bathrooms","floor","totalFloors","yearBuilt","address","neighborhood","city","images","allImages","publishPhotos","amenities","status","featured","vip","agentId","ownerName","ownerPhone","code","details","views"];
    for (const f of fields) if (body[f] !== undefined) patch[f] = body[f];
    patch.updatedAt = new Date();
    const [before] = await db.select({ status: properties.status }).from(properties).where(eq(properties.id, Number(id)));
    const [row] = await db.update(properties).set(patch).where(eq(properties.id, Number(id))).returning();

    /* انتشار خودکار در کانال‌ها هنگام تأیید (اگر در تنظیمات فعال باشد) */
    let channel: Record<string, unknown> | undefined;
    if (body.status === "available" && before?.status !== "available") {
      try {
        const { getChannelSettings } = await import("@/lib/user-auth");
        const ch = await getChannelSettings();
        if (ch.autoPostOnApprove) {
          const { postPropertyToChannel } = await import("@/lib/channel-post");
          channel = {};
          if (ch.telegramBotToken && ch.telegramChatId) channel.telegram = await postPropertyToChannel(row.id, "telegram");
          if (ch.baleBotToken && ch.baleChatId) channel.bale = await postPropertyToChannel(row.id, "bale");
        }
      } catch { /* ignore */ }
    }
    return NextResponse.json({ ok: true, data: row, channel });
  } catch (e) {
    return NextResponse.json({ ok: false, error: String(e) }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    if (!(await isAdmin(req))) return NextResponse.json({ ok: false, error: "دسترسی غیرمجاز" }, { status: 401 });
    const { id } = await params;
    await db.delete(properties).where(eq(properties.id, Number(id)));
    return NextResponse.json({ ok: true });
  } catch (e) {
    return NextResponse.json({ ok: false, error: String(e) }, { status: 500 });
  }
}
