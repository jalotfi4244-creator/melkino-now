import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { requests } from "@/db/schema";
import { eq } from "drizzle-orm";
import { isAdmin } from "@/lib/admin-auth";

export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  if (!(await isAdmin(req))) return NextResponse.json({ ok: false, error: "دسترسی غیرمجاز" }, { status: 401 });
  const { id } = await params;
  const b = await req.json();
  const patch: Record<string, unknown> = {};
  if (b.status !== undefined) patch.status = b.status;
  if (b.adminNote !== undefined) patch.adminNote = b.adminNote;
  const [row] = await db.update(requests).set(patch).where(eq(requests.id, Number(id))).returning();
  return NextResponse.json({ ok: true, data: row });
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  if (!(await isAdmin(req))) return NextResponse.json({ ok: false, error: "دسترسی غیرمجاز" }, { status: 401 });
  const { id } = await params;
  await db.delete(requests).where(eq(requests.id, Number(id)));
  return NextResponse.json({ ok: true });
}
