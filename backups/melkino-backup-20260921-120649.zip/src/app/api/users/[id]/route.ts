import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { appUsers, userLogins } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { isAdmin } from "@/lib/admin-auth";

export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  if (!(await isAdmin(req))) return NextResponse.json({ ok: false, error: "دسترسی غیرمجاز" }, { status: 401 });
  const { id } = await params;
  const [user] = await db.select().from(appUsers).where(eq(appUsers.id, Number(id)));
  if (!user) return NextResponse.json({ ok: false, error: "یافت نشد" }, { status: 404 });
  const logins = await db.select().from(userLogins).where(eq(userLogins.userId, Number(id))).orderBy(desc(userLogins.createdAt)).limit(60);
  return NextResponse.json({ ok: true, data: { user, logins } });
}

export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  if (!(await isAdmin(req))) return NextResponse.json({ ok: false, error: "دسترسی غیرمجاز" }, { status: 401 });
  const { id } = await params;
  const b = await req.json();
  const patch: Record<string, unknown> = {};
  if (b.status) patch.status = b.status;
  if (b.name !== undefined) patch.name = b.name;
  if (b.username !== undefined) patch.username = b.username;
  if (b.telegramId !== undefined) patch.telegramId = b.telegramId;
  const [row] = await db.update(appUsers).set(patch).where(eq(appUsers.id, Number(id))).returning();
  return NextResponse.json({ ok: true, data: row });
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  if (!(await isAdmin(req))) return NextResponse.json({ ok: false, error: "دسترسی غیرمجاز" }, { status: 401 });
  const { id } = await params;
  await db.delete(userLogins).where(eq(userLogins.userId, Number(id)));
  await db.delete(appUsers).where(eq(appUsers.id, Number(id)));
  return NextResponse.json({ ok: true });
}
