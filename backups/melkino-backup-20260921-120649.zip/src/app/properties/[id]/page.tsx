"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import { Heart, Share2, ChevronLeft, ChevronRight, MapPin, Phone, MessageCircle, Check, Eye, CalendarDays } from "lucide-react";
import PropertyCard, { CardProperty } from "@/components/PropertyCard";
import { formatToman, formatNumber, toFaDigits, PROPERTY_TYPES, DEAL_BADGE, DEAL_TYPES, cn } from "@/lib/utils";
import { PropertyImage } from "@/components/Logo";

interface FullProperty extends CardProperty {
  description: string;
  pricePerMeter: number;
  landArea: number;
  floor: number;
  totalFloors: number;
  yearBuilt: number;
  amenities: string[];
  agentId: number;
  details?: Record<string, unknown>;
  ownerName?: string;
}

const DETAIL_LABELS: Record<string, string> = {
  flooring: "پوشش کف", cabinet: "کابینت", cooling: "سرمایش", heating: "گرمایش",
  landType: "نوع زمین", width: "عرض زمین", length: "طول زمین", deedStatus: "وضعیت سند",
  ownership: "مالکیت", treeCount: "تعداد درختان", treeTypes: "نوع درختان",
  irrigation: "آبیاری", waterSource: "منبع آب", paymentTerms: "شرایط پرداخت",
  downPayment: "پیش‌پرداخت", totalPrice: "قیمت کل", visitHours: "ساعت بازدید",
  deliveryDate: "تاریخ تحویل", isNotKeyed: "کلیدنخورده", exchange: "معاوضه",
};

export default function PropertyDetailPage() {
  const params = useParams();
  const router = useRouter();
  const id = params.id as string;
  const [p, setP] = useState<FullProperty | null>(null);
  const [similar, setSimilar] = useState<CardProperty[]>([]);
  const [imgIdx, setImgIdx] = useState(0);
  const [fav, setFav] = useState(false);
  const [agent, setAgent] = useState<{ name: string; phone: string; title: string } | null>(null);

  useEffect(() => {
    fetch(`/api/properties/${id}`).then((r) => r.json()).then((d) => {
      if (d.ok) {
        setP(d.data);
        fetch(`/api/properties?type=${d.data.type}&limit=4`).then((r2) => r2.json()).then((d2) => {
          if (d2.ok) setSimilar(d2.data.filter((x: CardProperty) => x.id !== Number(id)).slice(0, 3));
        });
        fetch("/api/agents").then((r3) => r3.json()).then((d3) => {
          if (d3.ok && d3.data.length) setAgent(d3.data.find((x: { id: number }) => x.id === d.data.agentId) || d3.data[0]);
        });
      } else router.push("/properties");
    });
    try { setFav(JSON.parse(localStorage.getItem("melkino_favs") || "[]").includes(Number(id))); } catch { /* ignore */ }
  }, [id, router]);

  const toggleFav = () => {
    try {
      const arr: number[] = JSON.parse(localStorage.getItem("melkino_favs") || "[]");
      const next = arr.includes(Number(id)) ? arr.filter((x) => x !== Number(id)) : [...arr, Number(id)];
      localStorage.setItem("melkino_favs", JSON.stringify(next));
      setFav(next.includes(Number(id)));
    } catch { /* ignore */ }
  };

  const share = async () => {
    try {
      if (navigator.share) await navigator.share({ title: p?.title, url: window.location.href });
      else { await navigator.clipboard.writeText(window.location.href); alert("لینک آگهی کپی شد ✓"); }
    } catch { /* ignore */ }
  };

  if (!p) return <div className="px-4 pt-4"><div className="card h-[500px] animate-pulse" /></div>;

  const images = p.images && p.images.length ? p.images : [];
  const hasImages = images.length > 0;
  const details = (p.details || {}) as Record<string, unknown>;

  const specs: [string, string][] = [];
  if (p.area > 0) specs.push(["متراژ بنا", `${formatNumber(p.area)} متر`]);
  if (p.landArea > 0) specs.push(["متراژ زمین", `${formatNumber(p.landArea)} متر`]);
  if (p.rooms > 0) specs.push(["اتاق", toFaDigits(p.rooms)]);
  if ((p.bathrooms ?? 0) > 0) specs.push(["سرویس", toFaDigits(p.bathrooms!)]);
  if (p.totalFloors > 0) specs.push(["طبقه", `${toFaDigits(p.floor)} از ${toFaDigits(p.totalFloors)}`]);
  if (p.yearBuilt > 1300) specs.push(["سال ساخت", toFaDigits(p.yearBuilt)]);
  for (const [k, label] of Object.entries(DETAIL_LABELS)) {
    const v = details[k];
    if (v === undefined || v === null || v === "" || v === false) continue;
    if (typeof v === "number" && (k === "downPayment" || k === "totalPrice")) specs.push([label, formatToman(v)]);
    else if (typeof v === "boolean") specs.push([label, "دارد"]);
    else specs.push([label, toFaDigits(String(v))]);
  }

  return (
    <div className="px-4 pt-4">
      {/* gallery */}
      <div className="relative rounded-[24px] overflow-hidden h-64 card !p-0">
        <PropertyImage src={hasImages ? images[Math.min(imgIdx, images.length - 1)] : ""} alt={p.title} className="w-full h-full object-cover" />
        <div className="absolute inset-0" style={{ background: "linear-gradient(to top, rgba(0,0,0,.4), transparent 40%)" }} />
        <div className="absolute top-3 right-3 flex gap-1.5">
          <span className="badge" style={{ background: "var(--primary)", color: "#fff" }}>🏷️ {DEAL_BADGE[p.dealType]}</span>
        </div>
        <div className="absolute top-3 left-3 flex gap-1.5">
          <button onClick={toggleFav} className="w-9 h-9 rounded-xl flex items-center justify-center text-white" style={{ background: fav ? "var(--danger)" : "rgba(0,0,0,.45)" }}>
            <Heart size={17} className={fav ? "fill-white" : ""} />
          </button>
          <button onClick={share} className="w-9 h-9 rounded-xl flex items-center justify-center text-white" style={{ background: "rgba(0,0,0,.45)" }}>
            <Share2 size={17} />
          </button>
        </div>
        {images.length > 1 && (
          <>
            <button onClick={() => setImgIdx((imgIdx + 1) % images.length)} className="absolute right-2 top-1/2 -translate-y-1/2 w-9 h-9 rounded-full text-white flex items-center justify-center" style={{ background: "rgba(0,0,0,.5)" }}><ChevronRight size={18} /></button>
            <button onClick={() => setImgIdx((imgIdx - 1 + images.length) % images.length)} className="absolute left-2 top-1/2 -translate-y-1/2 w-9 h-9 rounded-full text-white flex items-center justify-center" style={{ background: "rgba(0,0,0,.5)" }}><ChevronLeft size={18} /></button>
          </>
        )}
        <div className="absolute bottom-3 right-3 badge" style={{ background: "rgba(0,0,0,.55)", color: "#fff" }}>📸 {hasImages ? `${toFaDigits(imgIdx + 1)} / ${toFaDigits(images.length)}` : "بدون تصویر"}</div>
        <div className="absolute bottom-3 left-3 flex items-center gap-1 text-[11px] text-white/90"><Eye size={13} /> {formatNumber(p.views)}</div>
      </div>

      {/* code + title */}
      <div className="card p-4 mt-3">
        <div className="flex items-center justify-between text-[12px] mb-1.5">
          <span style={{ color: "var(--text-muted)" }}>کد ملک: <b dir="ltr" className="font-mono">{p.code}</b></span>
          <span style={{ color: "var(--text-muted)" }}>ملکینو • {PROPERTY_TYPES[p.type]}</span>
        </div>
        <h1 className="font-black text-[18px] leading-8" style={{ color: "var(--text-primary)" }}>{p.title}</h1>
        <div className="flex items-center gap-1.5 mt-2 flex-wrap">
          <span className="badge badge-primary">🏷️ {DEAL_TYPES[p.dealType] || DEAL_BADGE[p.dealType]}</span>
          <span className="badge" style={{ background: "var(--bg-secondary)", color: "var(--text-secondary)" }}><MapPin size={12} /> {p.neighborhood} — {p.address}</span>
        </div>
      </div>

      {/* deal terms */}
      <div className="card p-4 mt-3" style={{ borderColor: "var(--gold)", borderWidth: 1.5 }}>
        <h2 className="font-black text-[14px] mb-2.5" style={{ color: "var(--gold-dark)" }}>💰 شرایط معامله</h2>
        {p.dealType === "rent" ? (
          <div className="space-y-1.5 text-[14px] font-extrabold" style={{ color: "var(--text-primary)" }}>
            <div>💰 ودیعه: {formatToman(p.mortgagePrice)}</div>
            <div>💰 اجاره ماهانه: {formatToman(p.rentPrice)}</div>
          </div>
        ) : (
          <div className="space-y-1.5 text-[14px] font-extrabold" style={{ color: "var(--text-primary)" }}>
            <div>💰 قیمت {p.dealType === "presale" ? "پیش‌فروش" : "فروش"}: {formatToman(p.price)}</div>
            {p.pricePerMeter > 0 && <div>💰 قیمت هر متر مربع: {formatToman(p.pricePerMeter)}</div>}
          </div>
        )}
      </div>

      {/* specs */}
      {specs.length > 0 && (
        <div className="card p-4 mt-3">
          <h2 className="font-black text-[14px] mb-3" style={{ color: "var(--text-primary)" }}>📋 مشخصات ملک</h2>
          <div className="grid grid-cols-2 gap-2">
            {specs.map(([k, v]) => (
              <div key={k} className="rounded-xl px-3 py-2.5 text-center" style={{ background: "var(--surface-soft)", border: "1px solid var(--border-light)" }}>
                <div className="text-[11px]" style={{ color: "var(--text-muted)" }}>{k}</div>
                <div className="font-extrabold text-[13px] mt-0.5" style={{ color: "var(--text-primary)" }}>{v}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* amenities */}
      {p.amenities && p.amenities.length > 0 && (
        <div className="card p-4 mt-3">
          <h2 className="font-black text-[14px] mb-3" style={{ color: "var(--text-primary)" }}>✨ امکانات ملک</h2>
          <div className="grid grid-cols-2 gap-2">
            {p.amenities.map((a) => (
              <div key={a} className="flex items-center gap-1.5 rounded-xl px-3 py-2 text-[12.5px] font-bold" style={{ background: "color-mix(in srgb, var(--primary-light) 9%, transparent)", color: "var(--text-primary)" }}>
                <Check size={14} style={{ color: "var(--primary)" }} /> {a}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* description */}
      {p.description && (
        <div className="card p-4 mt-3">
          <h2 className="font-black text-[14px] mb-2" style={{ color: "var(--text-primary)" }}>📝 توضیحات</h2>
          <p className="text-[13.5px] leading-7 whitespace-pre-line" style={{ color: "var(--text-secondary)" }}>{p.description}</p>
        </div>
      )}

      {/* agent */}
      <div className="card p-4 mt-3">
        <div className="flex items-center gap-3">
          <div className="w-14 h-14 rounded-2xl flex items-center justify-center text-2xl shrink-0" style={{ background: "color-mix(in srgb, var(--gold) 18%, transparent)" }}>👤</div>
          <div className="flex-1">
            <div className="font-black text-[15px]" style={{ color: "var(--text-primary)" }}>{agent?.name || "مشاور ملکینو"}</div>
            <div className="text-[12px]" style={{ color: "var(--text-muted)" }}>{agent?.title || "مشاور ملکینو"}</div>
          </div>
          <span className="badge badge-success">آنلاین</span>
        </div>
        <div className="grid grid-cols-2 gap-2 mt-3">
          <a href={`tel:${(agent?.phone || "09123730000").replace(/\s/g, "")}`} className="btn-primary py-3 rounded-2xl text-[13px] flex items-center justify-center gap-1.5">
            <Phone size={15} /> 📞 تماس با مشاور
          </a>
          <Link href="/contact" className="btn-gold py-3 rounded-2xl text-[13px] flex items-center justify-center gap-1.5">
            <MessageCircle size={15} /> 💬 پیام به مشاور
          </Link>
        </div>
      </div>

      {/* similar */}
      {similar.length > 0 && (
        <div className="mt-5">
          <h2 className="font-black text-[15px] mb-3" style={{ color: "var(--text-primary)" }}>آگهی‌های مشابه</h2>
          <div className="space-y-3.5">
            {similar.map((s) => <PropertyCard key={s.id} p={s} />)}
          </div>
        </div>
      )}
      <div className="h-2" />
    </div>
  );
}
