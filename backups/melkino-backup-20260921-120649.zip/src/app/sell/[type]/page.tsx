"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import { Camera, Check, Trash2, ArrowRight, ArrowLeft, ImagePlus } from "lucide-react";
import { uploadFiles } from "@/lib/image-client";
import {
  toFaDigits, parsePrice, cn,
  AMENITIES_APT, AMENITIES_VILLA, AMENITIES_LAND, AMENITIES_GARDEN, AMENITIES_OFFICE, AMENITIES_COMMERCIAL,
  FLOORING_OPTIONS, CABINET_OPTIONS, COOLING_OPTIONS, HEATING_OPTIONS,
  LAND_TYPES, LAND_DIRECTIONS, LAND_SHAPES, DEED_STATUS,
  pushNotif,
} from "@/lib/utils";

/* ============ configs exactly like original site ============ */
const TYPE_META: Record<string, { label: string; icon: string; totalSteps: number; stepTitles: string[] }> = {
  apartment: { label: "آپارتمان", icon: "🏢", totalSteps: 5, stepTitles: ["اطلاعات پایه و موقعیت", "مشخصات آپارتمان", "امکانات", "قیمت", "تصاویر، توضیحات و ثبت نهایی"] },
  villa: { label: "ویلا", icon: "🏡", totalSteps: 5, stepTitles: ["اطلاعات پایه و موقعیت", "مشخصات ویلا", "امکانات ویلا", "قیمت", "تصاویر، توضیحات و ثبت نهایی"] },
  land: { label: "زمین", icon: "🌍", totalSteps: 4, stepTitles: ["اطلاعات پایه و موقعیت", "امکانات و وضعیت زمین", "قیمت", "تصاویر، توضیحات و ثبت نهایی"] },
  garden: { label: "باغ", icon: "🌳", totalSteps: 5, stepTitles: ["اطلاعات پایه و موقعیت", "مشخصات باغ", "امکانات باغ", "قیمت", "تصاویر، توضیحات و ثبت نهایی"] },
  office: { label: "اداری", icon: "🏬", totalSteps: 5, stepTitles: ["اطلاعات پایه و موقعیت", "مشخصات واحد اداری", "امکانات واحد اداری", "قیمت", "تصاویر، توضیحات و ثبت نهایی"] },
  commercial: { label: "تجاری", icon: "🏪", totalSteps: 5, stepTitles: ["اطلاعات پایه و موقعیت", "مشخصات ملک تجاری", "امکانات ملک تجاری", "قیمت", "تصاویر، توضیحات و ثبت نهایی"] },
};

const AMENITIES: Record<string, string[]> = {
  apartment: AMENITIES_APT,
  villa: [...AMENITIES_VILLA, "زیرزمین", "گلخانه", "حیاط خلوت", "دوبلکس"],
  land: AMENITIES_LAND,
  garden: ["سرویس بهداشتی", "پارکینگ", "انباری", "آلاچیق", "استخر", "سونا", "باربیکیو", "برق", "گاز", "آب شهری", "دیوارکشی", "نگهبانی", "درب ورودی خودرو"],
  office: ["آسانسور", "پارکینگ", "انباری", "لابی", "نگهبانی", "دوربین مداربسته", "سیستم اعلام حریق", "اطفای حریق", "سیستم سرمایش", "سیستم گرمایش", "برق اختصاصی", "سه‌فاز", "آب", "گاز", "اینترنت", "تلفن", "آبدارخانه", "سرویس بهداشتی", "اتاق مدیریت", "اتاق جلسات", "پارتیشن‌بندی", "سیستم هوشمند", "درب ضدسرقت"],
  commercial: ["شیشه سکوریت", "درب اتوماتیک", "درب فلزی", "کرکره برقی", "کرکره معمولی", "سرویس بهداشتی", "آسانسور", "بالابر", "ویترین", "نورپردازی", "اسپیلت", "کولر آبی", "آبگرمکن", "پکیج", "بخاری"],
};

const IRRIGATION = ["قطره‌ای", "بارانی", "جوی و پشته", "آبیاری تحت فشار", "سطحی", "ترکیبی", "غرقابی"];
const WALL_COVER = ["کاغذ دیواری", "رنگ", "پنل", "گچ", "سرامیک", "سنگ"];

function ss(key: string): string {
  try { return sessionStorage.getItem(key) || ""; } catch { return ""; }
}

export default function SellTypePage() {
  const params = useParams<{ type: string }>();
  const router = useRouter();
  const type = params.type;
  const meta = TYPE_META[type];

  const [step, setStep] = useState(1);
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState<{ id: number; code: string } | null>(null);

  const [lastName] = useState(ss("reg_last_name"));
  const [phone] = useState(ss("reg_phone"));
  const [dealType] = useState(() => ss("reg_transaction_type") || "sale");

  const [f, setF] = useState<Record<string, string>>({});
  const [amens, setAmens] = useState<string[]>([]);
  const [images, setImages] = useState<string[]>([]);
  const [uploading, setUploading] = useState(false);
  const MAX_IMAGES = 8;
  const [publishPhotos, setPublishPhotos] = useState("yes");
  const [fullDesc, setFullDesc] = useState("");
  const [visitHours, setVisitHours] = useState("");

  useEffect(() => {
    if (!meta) router.push("/sell");
  }, [meta, router]);

  if (!meta) return null;

  const set = (k: string, v: string) => setF((p) => ({ ...p, [k]: v }));
  const toggleAmen = (a: string) => setAmens((p) => (p.includes(a) ? p.filter((x) => x !== a) : [...p, a]));

  /* ===== validation per step ===== */
  const validateStep = (): string | null => {
    if (step === 1) {
      if (!f.title?.trim()) return "عنوان آگهی الزامی است";
      if (!f.location?.trim()) return "محله / خیابان اصلی الزامی است";
      if (!f.address?.trim()) return "آدرس دقیق الزامی است";
      if (type === "apartment") {
        if (!f.area) return "متراژ الزامی است";
        if (!f.floor) return "طبقه الزامی است";
        if (!f.rooms) return "تعداد اتاق را انتخاب کنید";
        if (!f.year) return "سال ساخت الزامی است";
      }
      if (type === "villa") {
        if (!f.landArea) return "متراژ زمین الزامی است";
        if (!f.floorArea) return "زیربنا الزامی است";
        if (!f.year) return "سال ساخت الزامی است";
        if (!f.condition) return "وضعیت ملک را انتخاب کنید";
      }
      if (type === "land") {
        if (!f.landArea) return "متراژ زمین الزامی است";
        if (!f.landType) return "نوع زمین را انتخاب کنید";
        if (!f.width) return "عرض زمین الزامی است";
        if (!f.length) return "طول زمین الزامی است";
        if (!f.ownership) return "وضعیت مالکیت را انتخاب کنید";
      }
      if (type === "garden") {
        if (!f.gardenArea) return "مساحت باغ الزامی است";
        if (!f.documentType) return "نوع سند را انتخاب کنید";
      }
      if (type === "office") {
        if (!f.area) return "متراژ واحد الزامی است";
        if (!f.floor) return "طبقه الزامی است";
        if (!f.rooms) return "تعداد اتاق را انتخاب کنید";
        if (!f.year) return "سال ساخت الزامی است";
        if (!f.condition) return "وضعیت واحد را انتخاب کنید";
        if (!f.orientation) return "موقعیت واحد را انتخاب کنید";
        if (!f.usage) return "کاربری را انتخاب کنید";
      }
      if (type === "commercial") {
        if (!f.area) return "متراژ الزامی است";
        if (!f.front) return "بر مغازه الزامی است";
        if (!f.location1) return "موقعیت ملک را انتخاب کنید";
        if (!f.location2) return "موقعیت دسترسی را انتخاب کنید";
      }
    }
    if (meta.stepTitles[step - 1] === "قیمت") {
      if (dealType === "sale" && !parsePrice(f.price)) return "قیمت الزامی است";
      if (dealType === "rent") {
        if (!parsePrice(f.deposit) && !parsePrice(f.fullRentAmount)) return "ودیعه یا مبلغ رهن کامل را وارد کنید";
        if (!parsePrice(f.rentMonthly) && !parsePrice(f.fullRentAmount)) return "اجاره ماهانه یا مبلغ رهن کامل را وارد کنید";
      }
      if (dealType === "presale" && !parsePrice(f.totalPrice)) return "قیمت کل الزامی است";
    }
    return null;
  };

  const next = () => {
    const err = validateStep();
    if (err) { alert(err); return; }
    if (step < meta.totalSteps) setStep(step + 1);
  };
  const prev = () => {
    if (step > 1) setStep(step - 1);
    else router.push("/sell");
  };

  /* ===== images: فشرده‌سازی سمت کلاینت + آپلود واقعی به سرور ===== */
  const handleFiles = async (files: FileList | null) => {
    if (!files || !files.length) return;
    const list = Array.from(files).filter((f) => f.type.startsWith("image/"));
    const room = MAX_IMAGES - images.length;
    if (room <= 0) { alert(`حداکثر ${toFaDigits(MAX_IMAGES)} تصویر`); return; }
    const picked = list.slice(0, room);
    setUploading(true);
    try {
      const urls = await uploadFiles(picked, "property", { maxSide: 1400, quality: 0.8 });
      setImages((p) => [...p, ...urls].slice(0, MAX_IMAGES));
    } catch (e) {
      alert((e as Error).message || "خطا در آپلود تصویر");
    }
    setUploading(false);
  };

  /* ===== submit ===== */
  const submit = async () => {
    const p = parsePrice;
    const isRent = dealType === "rent";
    const isPresale = dealType === "presale";
    const fullRent = f.fullRent === "1";
    let price = 0, rentPrice = 0, mortgagePrice = 0, area = 0, rooms = 0;

    if (isRent) {
      rentPrice = p(f.rentMonthly);
      mortgagePrice = fullRent ? p(f.fullRentAmount) : p(f.deposit);
      price = fullRent ? p(f.fullRentAmount) : 0;
    } else if (isPresale) {
      price = p(f.totalPrice);
    } else {
      price = p(f.price);
    }

    if (type === "apartment") { area = Number(f.area) || 0; rooms = Number(f.rooms) || 0; }
    if (type === "villa") { area = Number(f.floorArea) || 0; rooms = Number(f.rooms) || 0; }
    if (type === "land") { area = 0; }
    if (type === "garden") { area = Number(f.buildingArea) || 0; }
    if (type === "office") { area = Number(f.area) || 0; rooms = Number(f.rooms) || 0; }
    if (type === "commercial") { area = Number(f.area) || 0; }

    const landArea =
      type === "villa" ? Number(f.landArea) || 0 :
      type === "land" ? Number(f.landArea) || 0 :
      type === "garden" ? Number(f.gardenArea) || 0 : 0;

    const details: Record<string, unknown> = {
      ...f,
      gender: ss("reg_gender"),
      publishPhotos,
      visitHours: visitHours || undefined,
      dealNegotiable: f.negotiable === "1",
      dealFixed: f.fixed === "1",
      exchangeInterested: f.exchange === "1",
      exchangeWith: f.exchangeWith || undefined,
      downPayment: isPresale ? p(f.downPayment) || undefined : undefined,
    };
    if (type === "villa") details.landArea = Number(f.landArea) || 0;
    if (type === "garden") details.gardenArea = Number(f.gardenArea) || 0;

    setSubmitting(true);
    try {
      const res = await fetch("/api/properties", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: f.title,
          type,
          dealType,
          ownerName: lastName,
          ownerPhone: phone,
          price,
          rentPrice,
          mortgagePrice,
          pricePerMeter: price && area ? Math.round(price / area) : 0,
          area,
          landArea,
          rooms,
          floor: Number(f.floor) || 0,
          totalFloors: Number(f.totalUnits) || 0,
          yearBuilt: Number(f.year) || 0,
          address: f.address,
          neighborhood: f.location,
          amenities: amens,
          /* همه تصاویر برای ادمین ارسال می‌شوند؛ انتشار عمومی طبق انتخاب کاربر */
          allImages: images,
          images: publishPhotos === "yes" ? images : [],
          publishPhotos: publishPhotos === "yes",
          description: fullDesc,
          status: "pending",
          details,
        }),
      });
      const d = await res.json();
      if (d.ok) {
        setDone({ id: d.data.id, code: d.data.code });
        /* شناسایی کاربر (identity-sync) */
        fetch("/api/users", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ phone, name: lastName, path: `/sell/${type}` }) }).catch(() => {});
        pushNotif({
          title: "آگهی شما ثبت شد",
          text: `آگهی «${f.title}» با کد ${d.data.code} برای بررسی ارسال شد. پس از تأیید تیم ملکینو منتشر می‌شود.`,
          link: "/properties",
        });
      } else {
        alert(d.error || "خطا در ثبت آگهی");
      }
    } catch {
      alert("خطا در ارتباط با سرور");
    }
    setSubmitting(false);
  };

  /* ===== success screen ===== */
  if (done) {
    return (
      <div className="px-4 pt-10 flex flex-col items-center text-center">
        <div className="w-24 h-24 rounded-full flex items-center justify-center mb-5" style={{ background: "var(--success-bg)" }}>
          <Check size={48} style={{ color: "var(--success)" }} strokeWidth={3} />
        </div>
        <h1 className="font-black text-[20px]" style={{ color: "var(--text-primary)" }}>آگهی شما با موفقیت ثبت شد 🎉</h1>
        <p className="text-[13px] leading-7 mt-2.5" style={{ color: "var(--text-secondary)" }}>
          آگهی شما پس از بررسی و تأیید توسط تیم ملکینو منتشر می‌شود.
          <br />
          معمولاً این فرایند کمتر از ۲۴ ساعت کاری طول می‌کشد.
        </p>
        <div className="card p-4 mt-5 w-full max-w-sm">
          <div className="text-[12px]" style={{ color: "var(--text-muted)" }}>کد پیگیری آگهی</div>
          <div className="font-black text-[18px] font-mono mt-1" dir="ltr" style={{ color: "var(--primary)" }}>{done.code}</div>
          <div className="flex items-center justify-center gap-1.5 mt-2">
            <span className="badge badge-warning">در انتظار بررسی</span>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-2.5 mt-5 w-full max-w-sm">
          <Link href="/properties" className="btn-secondary py-3.5 rounded-2xl text-[13px]">مشاهده همه آگهی‌ها</Link>
          <Link href="/home" className="btn-primary py-3.5 rounded-2xl text-[13px]">بازگشت به خانه</Link>
        </div>
      </div>
    );
  }

  const priceStepIdx = meta.stepTitles.indexOf("قیمت");

  return (
    <div className="px-4 pt-4 flex flex-col min-h-[70vh]">
      {/* header */}
      <div className="flex items-center gap-2.5 mb-4">
        <div className="w-10 h-10 rounded-2xl flex items-center justify-center text-lg" style={{ background: "color-mix(in srgb, var(--primary-light) 14%, transparent)" }}>{meta.icon}</div>
        <div className="flex-1">
          <div className="font-black text-[14px]" style={{ color: "var(--text-primary)" }}>ثبت ملک {meta.label}</div>
          <div className="text-[12px]" style={{ color: "var(--text-muted)" }}>مرحله {toFaDigits(step)} از {toFaDigits(meta.totalSteps)} — {meta.stepTitles[step - 1]}</div>
        </div>
        <button onClick={prev} className="icon-btn" title="مرحله قبل"><ArrowRight size={18} /></button>
      </div>
      <div className="h-1.5 rounded-full mb-5" style={{ background: "var(--bg-tertiary)" }}>
        <div className="h-full rounded-full transition-all duration-500" style={{ width: `${(step / meta.totalSteps) * 100}%`, background: "linear-gradient(90deg,var(--primary-light),var(--primary))" }} />
      </div>

      <div className="card p-5 flex-1 flex flex-col">
        {/* ============ STEP 1: base info ============ */}
        {step === 1 && (
          <div className="animate-fade-up">
            <h2 className="step-title mb-1">📍 اطلاعات پایه و موقعیت</h2>
            <p className="step-subtitle mb-4">اطلاعات اصلی ملک خود را وارد کنید</p>
            <div className="form-group">
              <label>عنوان آگهی</label>
              <input className="form-input" value={f.title || ""} onChange={(e) => set("title", e.target.value)} placeholder={type === "land" ? "زمین ۵۰۰ متری با دسترسی به خیابان اصلی" : `${meta.label} ۱۲۰ متری نوساز خ فردوسی`} />
            </div>
            <div className="form-group">
              <label>محله / خیابان اصلی</label>
              <input className="form-input" value={f.location || ""} onChange={(e) => set("location", e.target.value)} placeholder="خیابان بهار" />
            </div>
            <div className="form-group">
              <label>آدرس دقیق</label>
              <input className="form-input" value={f.address || ""} onChange={(e) => set("address", e.target.value)} placeholder="خ بهار کوچه بیستم..." />
            </div>

            {type === "apartment" && (
              <>
                <div className="row-half">
                  <div className="form-group"><label>متراژ (متر مربع)</label><input className="form-input" value={f.area || ""} onChange={(e) => set("area", e.target.value)} inputMode="numeric" placeholder="۹۰" /></div>
                  <div className="form-group"><label>طبقه</label><input className="form-input" value={f.floor || ""} onChange={(e) => set("floor", e.target.value)} inputMode="numeric" placeholder="۳" /></div>
                </div>
                <div className="row-half">
                  <div className="form-group">
                    <label>تعداد اتاق</label>
                    <select className="form-select" value={f.rooms || ""} onChange={(e) => set("rooms", e.target.value)}>
                      <option value="">انتخاب کنید</option>
                      {[1, 2, 3, 4].map((n) => <option key={n} value={n}>{toFaDigits(n)}</option>)}
                    </select>
                  </div>
                  <div className="form-group"><label>تعداد کل واحدها</label><input className="form-input" value={f.totalUnits || ""} onChange={(e) => set("totalUnits", e.target.value)} inputMode="numeric" placeholder="۲۰" /></div>
                </div>
                <div className="form-group"><label>سال ساخت</label><input className="form-input" value={f.year || ""} onChange={(e) => set("year", e.target.value)} inputMode="numeric" placeholder="۱۴۰۲" /></div>
                <label className="amen-check mb-3"><input type="checkbox" checked={f.isNotKeyed === "1"} onChange={(e) => set("isNotKeyed", e.target.checked ? "1" : "")} /> کلید نخورده</label>
                {dealType === "presale" && (
                  <div className="form-group"><label>تاریخ تحویل</label><input type="date" className="form-input" value={f.deliveryDate || ""} onChange={(e) => set("deliveryDate", e.target.value)} /></div>
                )}
                {dealType === "rent" && (
                  <div className="form-group"><label>تاریخ تخلیه</label><input type="date" className="form-input" value={f.vacancyDate || ""} onChange={(e) => set("vacancyDate", e.target.value)} /></div>
                )}
                {dealType === "rent" && <label className="amen-check"><input type="checkbox" checked={f.isVacant === "1"} onChange={(e) => set("isVacant", e.target.checked ? "1" : "")} /> واحد تخلیه است</label>}
              </>
            )}

            {type === "villa" && (
              <>
                <div className="row-half">
                  <div className="form-group"><label>متراژ زمین (متر مربع)</label><input className="form-input" value={f.landArea || ""} onChange={(e) => set("landArea", e.target.value)} inputMode="numeric" placeholder="۵۰۰" /></div>
                  <div className="form-group"><label>زیربنا (متر مربع)</label><input className="form-input" value={f.floorArea || ""} onChange={(e) => set("floorArea", e.target.value)} inputMode="numeric" placeholder="۲۵۰" /></div>
                </div>
                <div className="row-half">
                  <div className="form-group">
                    <label>تعداد اتاق</label>
                    <select className="form-select" value={f.rooms || ""} onChange={(e) => set("rooms", e.target.value)}>
                      <option value="">انتخاب کنید</option>
                      {[1, 2, 3, 4, 5].map((n) => <option key={n} value={n}>{toFaDigits(n)}</option>)}
                    </select>
                  </div>
                  <div className="form-group"><label>سال ساخت</label><input className="form-input" value={f.year || ""} onChange={(e) => set("year", e.target.value)} inputMode="numeric" placeholder="۱۴۰" /></div>
                </div>
                <div className="form-group">
                  <label>وضعیت ملک</label>
                  <div className="options-group">
                    {["کلید نخورده", "کلنگی", "بازسازی شده"].map((c) => (
                      <button key={c} type="button" onClick={() => set("condition", f.condition === c ? "" : c)} className={cn("option-btn", f.condition === c && "selected")}>{c}</button>
                    ))}
                  </div>
                </div>
                {dealType === "presale" && <div className="form-group"><label>تاریخ تحویل</label><input type="date" className="form-input" value={f.deliveryDate || ""} onChange={(e) => set("deliveryDate", e.target.value)} /></div>}
                {dealType === "rent" && <>
                  <div className="form-group"><label>تاریخ تخلیه</label><input type="date" className="form-input" value={f.vacancyDate || ""} onChange={(e) => set("vacancyDate", e.target.value)} /></div>
                  <label className="amen-check"><input type="checkbox" checked={f.isVacant === "1"} onChange={(e) => set("isVacant", e.target.checked ? "1" : "")} /> ساختمان تخلیه است</label>
                </>}
              </>
            )}

            {type === "land" && (
              <>
                <div className="form-group"><label>متراژ زمین (متر مربع)</label><input className="form-input" value={f.landArea || ""} onChange={(e) => set("landArea", e.target.value)} inputMode="numeric" placeholder="۵۰۰" /></div>
                <div className="form-group">
                  <label>نوع زمین</label>
                  <div className="options-group">
                    {LAND_TYPES.map((c) => (
                      <button key={c} type="button" onClick={() => set("landType", f.landType === c ? "" : c)} className={cn("option-btn", f.landType === c && "selected")}>{c}</button>
                    ))}
                  </div>
                </div>
                <div className="row-half">
                  <div className="form-group"><label>عرض زمین (متر)</label><input className="form-input" value={f.width || ""} onChange={(e) => set("width", e.target.value)} inputMode="numeric" placeholder="۱۲" /></div>
                  <div className="form-group"><label>طول زمین (متر)</label><input className="form-input" value={f.length || ""} onChange={(e) => set("length", e.target.value)} inputMode="numeric" placeholder="۴۲" /></div>
                </div>
                <div className="row-half">
                  <div className="form-group"><label>بر زمین (متر)</label><input className="form-input" value={f.frontWidth || ""} onChange={(e) => set("frontWidth", e.target.value)} inputMode="numeric" placeholder="۱۰" /></div>
                  <div className="form-group"><label>تعداد بلوک</label><input className="form-input" value={f.blocks || ""} onChange={(e) => set("blocks", e.target.value)} inputMode="numeric" placeholder="۲" /></div>
                </div>
                <div className="row-half">
                  <div className="form-group">
                    <label>جهت زمین</label>
                    <select className="form-select" value={f.direction || ""} onChange={(e) => set("direction", e.target.value)}>
                      <option value="">انتخاب کنید</option>
                      {LAND_DIRECTIONS.map((d) => <option key={d} value={d}>{d}</option>)}
                    </select>
                  </div>
                  <div className="form-group">
                    <label>شکل زمین</label>
                    <select className="form-select" value={f.shape || ""} onChange={(e) => set("shape", e.target.value)}>
                      <option value="">انتخاب کنید</option>
                      {LAND_SHAPES.map((d) => <option key={d} value={d}>{d}</option>)}
                    </select>
                  </div>
                </div>
                <div className="form-group">
                  <label>وضعیت سند</label>
                  <select className="form-select" value={f.deedStatus || ""} onChange={(e) => set("deedStatus", e.target.value)}>
                    <option value="">انتخاب کنید</option>
                    {DEED_STATUS.map((d) => <option key={d} value={d}>{d}</option>)}
                  </select>
                </div>
                <div className="form-group">
                  <label>وضعیت مالکیت</label>
                  <div className="options-group">
                    {["شش‌دانگ", "مشاع"].map((c) => (
                      <button key={c} type="button" onClick={() => set("ownership", f.ownership === c ? "" : c)} className={cn("option-btn", f.ownership === c && "selected")}>{c}</button>
                    ))}
                  </div>
                </div>
              </>
            )}

            {type === "garden" && (
              <>
                <div className="form-group"><label>مساحت باغ (متر مربع)</label><input className="form-input" value={f.gardenArea || ""} onChange={(e) => set("gardenArea", e.target.value)} inputMode="numeric" placeholder="۱۰۰" /></div>
                <div className="form-group">
                  <label>نوع سند</label>
                  <div className="options-group">
                    {["سند", "قولنامه"].map((c) => (
                      <button key={c} type="button" onClick={() => set("documentType", f.documentType === c ? "" : c)} className={cn("option-btn", f.documentType === c && "selected")}>{c}</button>
                    ))}
                  </div>
                </div>
              </>
            )}

            {type === "office" && (
              <>
                <div className="row-half">
                  <div className="form-group"><label>متراژ واحد (متر مربع)</label><input className="form-input" value={f.area || ""} onChange={(e) => set("area", e.target.value)} inputMode="numeric" placeholder="۱۲۰" /></div>
                  <div className="form-group"><label>طبقه</label><input className="form-input" value={f.floor || ""} onChange={(e) => set("floor", e.target.value)} inputMode="numeric" placeholder="۳" /></div>
                </div>
                <div className="row-half">
                  <div className="form-group"><label>تعداد واحد در طبقه</label><input className="form-input" value={f.unitsPerFloor || ""} onChange={(e) => set("unitsPerFloor", e.target.value)} inputMode="numeric" placeholder="۴" /></div>
                  <div className="form-group">
                    <label>تعداد اتاق</label>
                    <select className="form-select" value={f.rooms || ""} onChange={(e) => set("rooms", e.target.value)}>
                      <option value="">انتخاب کنید</option>
                      {[1, 2, 3, 4, 5, 6].map((n) => <option key={n} value={n}>{toFaDigits(n)}</option>)}
                    </select>
                  </div>
                </div>
                <div className="form-group"><label>سال ساخت</label><input className="form-input" value={f.year || ""} onChange={(e) => set("year", e.target.value)} inputMode="numeric" placeholder="۱۴۰۲" /></div>
                <div className="form-group">
                  <label>وضعیت واحد</label>
                  <div className="options-group">
                    {["نوساز", "بازسازی‌شده", "قدیمی"].map((c) => (
                      <button key={c} type="button" onClick={() => set("condition", f.condition === c ? "" : c)} className={cn("option-btn", f.condition === c && "selected")}>{c}</button>
                    ))}
                  </div>
                </div>
                <div className="form-group">
                  <label>موقعیت واحد</label>
                  <div className="options-group">
                    {["شمالی", "جنوبی", "شرقی", "غربی"].map((c) => (
                      <button key={c} type="button" onClick={() => set("orientation", f.orientation === c ? "" : c)} className={cn("option-btn", f.orientation === c && "selected")}>{c}</button>
                    ))}
                  </div>
                </div>
                <div className="form-group">
                  <label>کاربری</label>
                  <div className="options-group">
                    {["اداری", "دفتر کار", "تجاری-اداری"].map((c) => (
                      <button key={c} type="button" onClick={() => set("usage", f.usage === c ? "" : c)} className={cn("option-btn", f.usage === c && "selected")}>{c}</button>
                    ))}
                  </div>
                </div>
                {dealType === "presale" && <div className="form-group"><label>تاریخ تحویل</label><input type="date" className="form-input" value={f.deliveryDate || ""} onChange={(e) => set("deliveryDate", e.target.value)} /></div>}
                {dealType === "rent" && <>
                  <div className="form-group"><label>تاریخ تخلیه</label><input type="date" className="form-input" value={f.vacancyDate || ""} onChange={(e) => set("vacancyDate", e.target.value)} /></div>
                  <label className="amen-check"><input type="checkbox" checked={f.isVacant === "1"} onChange={(e) => set("isVacant", e.target.checked ? "1" : "")} /> واحد تخلیه است</label>
                </>}
              </>
            )}

            {type === "commercial" && (
              <>
                <div className="row-half">
                  <div className="form-group"><label>متراژ (متر مربع)</label><input className="form-input" value={f.area || ""} onChange={(e) => set("area", e.target.value)} inputMode="numeric" placeholder="۴۰" /></div>
                  <div className="form-group"><label>بر مغازه (متر)</label><input className="form-input" value={f.front || ""} onChange={(e) => set("front", e.target.value)} inputMode="numeric" placeholder="۶" /></div>
                </div>
                <div className="form-group">
                  <label>موقعیت ملک تجاری</label>
                  <div className="options-group">
                    {["دونبش", "دوبر", "یک بر"].map((c) => (
                      <button key={c} type="button" onClick={() => set("location1", f.location1 === c ? "" : c)} className={cn("option-btn", f.location1 === c && "selected")}>{c}</button>
                    ))}
                  </div>
                </div>
                <div className="form-group">
                  <label>دسترسی</label>
                  <div className="options-group">
                    {["بر خیابان اصلی", "بر خیابان فرعی", "در پاساژ", "در گاراژ"].map((c) => (
                      <button key={c} type="button" onClick={() => set("location2", f.location2 === c ? "" : c)} className={cn("option-btn", f.location2 === c && "selected")}>{c}</button>
                    ))}
                  </div>
                </div>
                {dealType === "presale" && <div className="form-group"><label>تاریخ تحویل</label><input type="date" className="form-input" value={f.deliveryDate || ""} onChange={(e) => set("deliveryDate", e.target.value)} /></div>}
                {dealType === "rent" && <>
                  <div className="form-group"><label>تاریخ تخلیه</label><input type="date" className="form-input" value={f.vacancyDate || ""} onChange={(e) => set("vacancyDate", e.target.value)} /></div>
                  <label className="amen-check"><input type="checkbox" checked={f.isVacant === "1"} onChange={(e) => set("isVacant", e.target.checked ? "1" : "")} /> واحد تجاری تخلیه است</label>
                </>}
              </>
            )}
          </div>
        )}

        {/* ============ STEP 2: specs (apartment/villa) ============ */}
        {step === 2 && (type === "apartment" || type === "villa") && (
          <div className="animate-fade-up">
            <h2 className="step-title mb-1">🏗️ {meta.stepTitles[1]}</h2>
            <p className="step-subtitle mb-4">مشخصات فنی ملک را مشخص کنید</p>
            <div className="row-half">
              <div className="form-group">
                <label>نوع پوشش کف</label>
                <select className="form-select" value={f.flooring || FLOORING_OPTIONS[0]} onChange={(e) => set("flooring", e.target.value)}>
                  {FLOORING_OPTIONS.map((o) => <option key={o} value={o}>{o}</option>)}
                </select>
              </div>
              <div className="form-group">
                <label>نوع کابینت</label>
                <select className="form-select" value={f.cabinet || CABINET_OPTIONS[0]} onChange={(e) => set("cabinet", e.target.value)}>
                  {CABINET_OPTIONS.map((o) => <option key={o} value={o}>{o}</option>)}
                </select>
              </div>
            </div>
            <div className="row-half">
              <div className="form-group">
                <label>سیستم سرمایش</label>
                <select className="form-select" value={f.cooling || COOLING_OPTIONS[0]} onChange={(e) => set("cooling", e.target.value)}>
                  {COOLING_OPTIONS.map((o) => <option key={o} value={o}>{o}</option>)}
                </select>
              </div>
              <div className="form-group">
                <label>سیستم گرمایش</label>
                <select className="form-select" value={f.heating || HEATING_OPTIONS[0]} onChange={(e) => set("heating", e.target.value)}>
                  {HEATING_OPTIONS.map((o) => <option key={o} value={o}>{o}</option>)}
                </select>
              </div>
            </div>
          </div>
        )}

        {/* ============ STEP 2: garden specs ============ */}
        {step === 2 && type === "garden" && (
          <div className="animate-fade-up">
            <h2 className="step-title mb-1">🌳 {meta.stepTitles[1]}</h2>
            <p className="step-subtitle mb-4">مشخصات باغ را کامل کنید</p>
            <div className="form-group">
              <label>نوع درختان</label>
              <input className="form-input" value={f.treeTypes || ""} onChange={(e) => set("treeTypes", e.target.value)} placeholder="گردو، سیب، ..." />
            </div>
            <div className="row-half">
              <div className="form-group"><label>سن درختان (سال)</label><input className="form-input" value={f.treeAge || ""} onChange={(e) => set("treeAge", e.target.value)} inputMode="numeric" placeholder="۱۰" /></div>
              <div className="form-group">
                <label>نوع آبیاری</label>
                <select className="form-select" value={f.irrigation || ""} onChange={(e) => set("irrigation", e.target.value)}>
                  <option value="">انتخاب کنید</option>
                  {IRRIGATION.map((o) => <option key={o} value={o}>{o}</option>)}
                </select>
              </div>
            </div>
            <div className="form-group">
              <label>آب ملکی</label>
              <div className="options-group">
                {["دارد", "ندارد"].map((c) => (
                  <button key={c} type="button" onClick={() => set("hasWater", f.hasWater === c ? "" : c)} className={cn("option-btn", f.hasWater === c && "selected")}>{c}</button>
                ))}
              </div>
            </div>
            {f.hasWater === "دارد" && (
              <div className="row-half">
                <div className="form-group"><label>مقدار ساعت آب</label><input className="form-input" value={f.waterHours || ""} onChange={(e) => set("waterHours", e.target.value)} inputMode="numeric" placeholder="۲" /></div>
                <div className="form-group"><label>نام چاه آب</label><input className="form-input" value={f.wellName || ""} onChange={(e) => set("wellName", e.target.value)} placeholder="—" /></div>
              </div>
            )}
            <div className="form-group">
              <label>استخر ذخیره آب</label>
              <div className="options-group">
                {["دارد", "ندارد"].map((c) => (
                  <button key={c} type="button" onClick={() => set("hasPond", f.hasPond === c ? "" : c)} className={cn("option-btn", f.hasPond === c && "selected")}>{c}</button>
                ))}
              </div>
            </div>
            <div className="form-group">
              <label>بنا / خانه باغ</label>
              <div className="options-group">
                {["دارد", "ندارد"].map((c) => (
                  <button key={c} type="button" onClick={() => set("hasBuilding", f.hasBuilding === c ? "" : c)} className={cn("option-btn", f.hasBuilding === c && "selected")}>{c}</button>
                ))}
              </div>
            </div>
            {f.hasBuilding === "دارد" && (
              <div className="form-group"><label>متراژ بنا (متر مربع)</label><input className="form-input" value={f.buildingArea || ""} onChange={(e) => set("buildingArea", e.target.value)} inputMode="numeric" placeholder="۶۰" /></div>
            )}
          </div>
        )}

        {/* ============ STEP 2: commercial specs ============ */}
        {step === 2 && type === "commercial" && (
          <div className="animate-fade-up">
            <h2 className="step-title mb-1">🏪 {meta.stepTitles[1]}</h2>
            <p className="step-subtitle mb-4">مشخصات ملک تجاری را کامل کنید</p>
            <div className="row-half">
              <div className="form-group">
                <label>پوشش کف</label>
                <select className="form-select" value={f.flooring || "سرامیک"} onChange={(e) => set("flooring", e.target.value)}>
                  {["سرامیک", "موکت", "سنگ", "موزاییک", "سیمان", "کفپوش"].map((o) => <option key={o} value={o}>{o}</option>)}
                </select>
              </div>
              <div className="form-group">
                <label>پوشش دیوارها</label>
                <select className="form-select" value={f.wall || "رنگ"} onChange={(e) => set("wall", e.target.value)}>
                  {WALL_COVER.map((o) => <option key={o} value={o}>{o}</option>)}
                </select>
              </div>
            </div>
            <div className="row-half">
              <div className="form-group">
                <label>نوع کابینت</label>
                <select className="form-select" value={f.cabinet || CABINET_OPTIONS[0]} onChange={(e) => set("cabinet", e.target.value)}>
                  {CABINET_OPTIONS.map((o) => <option key={o} value={o}>{o}</option>)}
                </select>
              </div>
              <div className="form-group">
                <label>سیستم سرمایش</label>
                <select className="form-select" value={f.cooling || COOLING_OPTIONS[0]} onChange={(e) => set("cooling", e.target.value)}>
                  {COOLING_OPTIONS.map((o) => <option key={o} value={o}>{o}</option>)}
                </select>
              </div>
            </div>
            <div className="form-group">
              <label>سیستم گرمایش</label>
              <select className="form-select" value={f.heating || HEATING_OPTIONS[0]} onChange={(e) => set("heating", e.target.value)}>
                {HEATING_OPTIONS.map((o) => <option key={o} value={o}>{o}</option>)}
              </select>
            </div>
          </div>
        )}

        {/* ============ STEP 3 (or 2 for land): amenities ============ */}
        {(step === (type === "land" ? 2 : 3)) && (
          <div className="animate-fade-up">
            <h2 className="step-title mb-1">✨ {meta.stepTitles[type === "land" ? 1 : 2]}</h2>
            <p className="step-subtitle mb-4">امکانات موجود در ملک را تیک بزنید</p>
            <div className="grid grid-cols-2 gap-2">
              {AMENITIES[type].map((a) => (
                <label key={a} className="amen-check">
                  <input type="checkbox" checked={amens.includes(a)} onChange={() => toggleAmen(a)} />
                  {a}
                </label>
              ))}
            </div>
          </div>
        )}

        {/* ============ PRICE STEP ============ */}
        {step === priceStepIdx && (
          <div className="animate-fade-up">
            <h2 className="step-title mb-1">💰 قیمت</h2>
            <p className="step-subtitle mb-4">
              {dealType === "sale" ? "قیمت ملک خود را به تومان وارد کنید" : dealType === "rent" ? "مبالغ ودیعه و اجاره را وارد کنید" : "شرایط پرداخت پیش‌فروش را مشخص کنید"}
            </p>
            {dealType === "sale" && (
              <>
                <div className="form-group">
                  <label>قیمت (تومان)</label>
                  <input className="form-input" value={f.price || ""} onChange={(e) => set("price", e.target.value)} inputMode="numeric" placeholder="۲,۸۰۰,۰۰۰,۰۰۰" />
                </div>
                <div className="form-group">
                  <label>شرط قیمت</label>
                  <div className="options-group">
                    <button type="button" onClick={() => set("negotiable", f.negotiable === "1" ? "" : "1")} className={cn("option-btn", f.negotiable === "1" && "selected")}>قابل مذاکره</button>
                    <button type="button" onClick={() => set("fixed", f.fixed === "1" ? "" : "1")} className={cn("option-btn", f.fixed === "1" && "selected")}>مقطوع</button>
                  </div>
                </div>
                <label className="amen-check mb-2"><input type="checkbox" checked={f.exchange === "1"} onChange={(e) => set("exchange", e.target.checked ? "1" : "")} /> مایل به معاوضه هستم</label>
                {f.exchange === "1" && (
                  <div className="form-group">
                    <label>معاوضه با:</label>
                    <textarea className="form-textarea" rows={3} value={f.exchangeWith || ""} onChange={(e) => set("exchangeWith", e.target.value)} placeholder="مثلاً: معاوضه با آپارتمان بزرگ‌تر یا معاوضه با ویلا یا ... شرایط خود را توضیح دهید." />
                  </div>
                )}
              </>
            )}
            {dealType === "rent" && (
              <>
                <div className="form-group"><label>ودیعه (تومان)</label><input className="form-input" value={f.deposit || ""} onChange={(e) => set("deposit", e.target.value)} inputMode="numeric" placeholder="۵۰۰,۰۰,۰۰۰" /></div>
                <div className="form-group"><label>اجاره ماهانه (تومان)</label><input className="form-input" value={f.rentMonthly || ""} onChange={(e) => set("rentMonthly", e.target.value)} inputMode="numeric" placeholder="۳۰,۰۰۰,۰۰۰" /></div>
                <label className="amen-check"><input type="checkbox" checked={f.fullRent === "1"} onChange={(e) => set("fullRent", e.target.checked ? "1" : "")} /> ️ رهن کامل</label>
                {f.fullRent === "1" && (
                  <div className="form-group mt-3"><label>مبلغ رهن کامل (تومان)</label><input className="form-input" value={f.fullRentAmount || ""} onChange={(e) => set("fullRentAmount", e.target.value)} inputMode="numeric" placeholder="۱,۰۰,۰۰۰,۰۰۰" /></div>
                )}
              </>
            )}
            {dealType === "presale" && (
              <>
                <div className="form-group"><label>قیمت کل (تومان)</label><input className="form-input" value={f.totalPrice || ""} onChange={(e) => set("totalPrice", e.target.value)} inputMode="numeric" placeholder="۳,۰۰۰,۰۰,۰۰۰" /></div>
                <div className="form-group"><label>پیش‌پرداخت (تومان)</label><input className="form-input" value={f.downPayment || ""} onChange={(e) => set("downPayment", e.target.value)} inputMode="numeric" placeholder="۹۰۰,۰۰۰,۰۰" /></div>
                <div className="form-group">
                  <label>شرایط پرداخت</label>
                  <textarea className="form-textarea" rows={3} value={f.paymentTerms || ""} onChange={(e) => set("paymentTerms", e.target.value)} placeholder="مثال: ۳۰٪ قرارداد، ۲۰٪ اسکلت..." />
                </div>
              </>
            )}
          </div>
        )}

        {/* ============ FINAL STEP ============ */}
        {step === meta.totalSteps && (
          <div className="animate-fade-up">
            <h2 className="step-title mb-1">📸 تصاویر، توضیحات و ثبت نهایی</h2>
            <p className="step-subtitle mb-4">آخرین قدم؛ آگهی شما آماده انتشار است</p>

            <div className="form-group">
              <label>
                آپلود تصاویر (حداکثر ۵ مگابایت، فرمت JPG, PNG, WEBP)
                <span className="float-left text-[11px] font-normal" style={{ color: "var(--text-muted)" }}>{toFaDigits(images.length)} / {toFaDigits(MAX_IMAGES)}</span>
              </label>
              <div className="grid grid-cols-3 gap-2">
                {images.map((img, i) => (
                  <div key={img} className="relative rounded-2xl overflow-hidden h-24" style={{ border: i === 0 ? "2px solid var(--gold)" : "1px solid var(--border)" }}>
                    <img src={img} alt="" className="w-full h-full object-cover" />
                    {i === 0 && <span className="absolute bottom-1 right-1 text-[9px] font-black px-1.5 py-0.5 rounded-md" style={{ background: "var(--gold)", color: "#1a1405" }}>اصلی</span>}
                    <button type="button" onClick={() => setImages(images.filter((_, x) => x !== i))} className="absolute top-1 left-1 w-6 h-6 rounded-full flex items-center justify-center" style={{ background: "var(--danger)", color: "#fff" }}>
                      <Trash2 size={12} />
                    </button>
                    {i > 0 && (
                      <button type="button" title="انتخاب به‌عنوان تصویر اصلی" onClick={() => setImages([img, ...images.filter((_, x) => x !== i)])} className="absolute top-1 right-1 w-6 h-6 rounded-full flex items-center justify-center text-[11px]" style={{ background: "rgba(0,0,0,.55)", color: "#fff" }}>★</button>
                    )}
                  </div>
                ))}
                {images.length < MAX_IMAGES && (
                  <label className="h-24 rounded-2xl flex flex-col items-center justify-center gap-1 cursor-pointer transition-all" style={{ border: "1.5px dashed var(--border-strong)", color: "var(--text-muted)", opacity: uploading ? 0.6 : 1 }}>
                    {uploading ? <span className="text-[11px] font-bold">در حال آپلود...</span> : <><ImagePlus size={20} /><span className="text-[11px] font-bold">افزودن</span></>}
                    <input type="file" accept="image/jpeg,image/png,image/webp" multiple className="hidden" disabled={uploading} onChange={(e) => { handleFiles(e.target.files); e.target.value = ""; }} />
                  </label>
                )}
              </div>
              <p className="text-[11px] mt-2 leading-5" style={{ color: "var(--text-muted)" }}>
                💡 تصاویر همان لحظه فشرده و آپلود می‌شوند. اولین تصویر به‌عنوان عکس اصلی آگهی نمایش داده می‌شود؛ با ★ می‌توانید تصویر اصلی را تغییر دهید.
              </p>
            </div>

            <div className="form-group">
              <label>انتخاب حالت انتشار تصاویر</label>
              <div className="options-group">
                <button type="button" onClick={() => setPublishPhotos("yes")} className={cn("option-btn", publishPhotos === "yes" && "selected")}>مایل به انتشار عکس‌ها در آگهی هستم</button>
                <button type="button" onClick={() => setPublishPhotos("no")} className={cn("option-btn", publishPhotos === "no" && "selected")}>مایل به انتشار عکس‌ها نیستم</button>
              </div>
            </div>

            <div className="form-group">
              <label>
                توضیحات تکمیلی (حداکثر ۱۰۰ کاراکتر)
                <span className="float-left text-[11px] font-normal" style={{ color: "var(--text-muted)" }}>{toFaDigits(fullDesc.length)} / ۱۰۰۰</span>
              </label>
              <textarea className="form-textarea" rows={4} maxLength={1000} value={fullDesc} onChange={(e) => setFullDesc(e.target.value)} placeholder="شرح کامل امکانات و شرایط ملک..." />
            </div>

            <div className="form-group">
              <label>چه زمان‌هایی میشه بازدید کرد؟</label>
              <textarea className="form-textarea" rows={2} value={visitHours} onChange={(e) => setVisitHours(e.target.value)} placeholder="مثال: فقط عصرها میشه بازدید کرد یا همیشه با هماهنگی قبلی..." />
            </div>

            {/* summary */}
            <div className="rounded-2xl p-4 mt-2" style={{ background: "var(--surface-soft)", border: "1px solid var(--border-light)" }}>
              <div className="font-black text-[13px] mb-2" style={{ color: "var(--text-primary)" }}>📋 خلاصه آگهی</div>
              <div className="text-[12px] leading-6" style={{ color: "var(--text-secondary)" }}>
                <div><b>مالک:</b> {lastName || "—"} • <span dir="ltr">{toFaDigits(phone) || "—"}</span></div>
                <div><b>معامله:</b> {dealType === "sale" ? "خرید و فروش" : dealType === "rent" ? "اجاره" : "پیش فروش"} • <b>نوع:</b> {meta.label}</div>
                <div><b>عنوان:</b> {f.title || "—"}</div>
                <div><b>موقعیت:</b> {f.location || "—"}، {f.address || "—"}</div>
                <div><b>امکانات:</b> {amens.length ? amens.join("، ") : "—"}</div>
              </div>
            </div>
          </div>
        )}

        {/* bottom actions */}
        <div className="bottom-actions">
          <button type="button" onClick={prev} className="btn-secondary px-6 rounded-2xl text-sm">
            مرحله قبل
          </button>
          {step < meta.totalSteps ? (
            <button type="button" onClick={next} className="btn-primary btn-primary-full flex items-center justify-center gap-1.5 py-3.5 rounded-2xl text-sm">
              مرحله بعد <ArrowLeft size={16} />
            </button>
          ) : (
            <button type="button" onClick={submit} disabled={submitting} className="btn-primary btn-primary-full flex items-center justify-center gap-1.5 py-3.5 rounded-2xl text-sm disabled:opacity-60">
              {submitting ? "در حال ثبت..." : "📩 ثبت نهایی آگهی"}
            </button>
          )}
        </div>
        <div className="text-center text-[11px] mt-3 flex items-center justify-center gap-1" style={{ color: "var(--text-muted)" }}>
          <Camera size={12} /> پس از ثبت، آگهی شما توسط تیم ملکینو بررسی و منتشر می‌شود
        </div>
      </div>
    </div>
  );
}
